package com.isban.cms.service;

import java.util.List;

import com.isban.cms.model.Card;

public interface FileLoadService {
    public List<Card> loadFile();
}
