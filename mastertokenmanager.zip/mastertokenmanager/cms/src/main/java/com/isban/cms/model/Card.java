package com.isban.cms.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;


public class Card {
    private Integer id;
    private String pan;
    private String issuerId;
    private String customer;
    private String product;
    private String cardStatusCode;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date lastMovementDate;
    private List<String> blockCodes;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date expirationDate;
    private String accountNum;
    private String cardArt;
    
    public Card(Integer id, String pan, String issuerid, String customer, String product, String sittarcode,
            Date lastmovementdate, List<String> blockcodes, Date expirationdate, String accountnum) {
        super();
        this.id = id;
        this.pan = pan;
        this.issuerId = issuerid;
        this.customer = customer;
        this.product = product;
        this.cardStatusCode = sittarcode;
        this.lastMovementDate = lastmovementdate;
        this.blockCodes = blockcodes;
        this.expirationDate = expirationdate;
        this.accountNum = accountnum;
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getCustomer() {
        return customer;
    }
    public void setCustomer(String customer) {
        this.customer = customer;
    }
    public String getProduct() {
        return product;
    }
    public void setProduct(String product) {
        this.product = product;
    }
    public String getCardStatusCode() {
        return cardStatusCode;
    }
    public void setCardStatusCode(String sittarcode) {
        this.cardStatusCode = sittarcode;
    }
    public Date getLastMovementDate() {
        return lastMovementDate;
    }
    public void setLastMovementDate(Date lastmovementdate) {
        this.lastMovementDate = lastmovementdate;
    }
    
    public List<String> getBlockCodes() {
        return blockCodes;
    }
    public void setBlockCodes(List<String> blockcodes) {
        this.blockCodes = blockcodes;
    }
    public Date getExpirationDate() {
        return expirationDate;
    }
    public void setExpirationDate(Date expirationdate) {
        this.expirationDate = expirationdate;
    }
    
    public String getPan() {
        return pan;
    }
    public void setPan(String pan) {
        this.pan = pan;
    }
    
    public String getIssuerId() {
        return issuerId;
    }
    public void setIssuerId(String issuerid) {
        this.issuerId = issuerid;
    }
    public String getAccountNum() {
        return accountNum;
    }
    public void setAccountNum(String accountnum) {
        this.accountNum = accountnum;
    }
    public String getCardArt() {
        return cardArt;
    }
    public void setCardArt(String cardArt) {
        this.cardArt = cardArt;
    }
    
    
}