package com.isban.cms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.isban.cms.model.Card;
import com.isban.cms.service.FileLoadService;
import com.isban.tokenmanager.util.CommonUtil;
import com.isban.tokenmanager.util.TcpUtil;

import es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.internet.acmpmwestitulares.v1.ACMPMWESTitularesPortTypeHTTP;
import es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.internet.acmpmwestitulares.v1.ConsultaTjtTokenRedsysNew;
import es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.internet.acmpmwestitulares.v1.ConsultaTjtTokenRedsysNewComIsbAlMpmwesTitularesEFExcGeneralTitularesEFault;
import es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.internet.acmpmwestitulares.v1.ConsultaTjtTokenRedsysNewFault;
import es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.internet.acmpmwestitulares.v1.ConsultaTjtTokenRedsysNewResponse;
import es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.openbank.internet.cbtypes.v1.ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewEType;
import es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.openbank.internet.cbtypes.v1.ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewKLSType;
import es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.openbank.internet.cbtypes.v1.ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewLSType;
import es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.openbank.internet.cbtypes.v1.ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewReposType;
import es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.openbank.internet.cbtypes.v1.ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewSType;
import es.isban.webservices.tdcc.BLOQUEOCONTRATOTARJETAType;
import es.isban.webservices.tdcc.CENTRODECONTRATOType;
import es.isban.webservices.tdcc.CONTRATOType;
import es.isban.webservices.tdcc.ESTANDARDEREFERENCIAType;
import es.isban.webservices.tdcc.NUMPERSONACLIENTEType;
import es.isban.webservices.tdcc.SUBTIPODEPRODUCTOType;
import es.isban.webservices.tdcc.TIPODEPRODUCTOType;

@Component
@WebService(endpointInterface = "es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.internet.acmpmwestitulares.v1.ACMPMWESTitularesPortTypeHTTP")
public class CmsControllerWS implements ACMPMWESTitularesPortTypeHTTP {
    TcpUtil tcpUtil = TcpUtil.getInstance();

    @Autowired
    CommonUtil commonUtil;
    @Autowired
    FileLoadService fileLoad;

    @Override
    public ConsultaTjtTokenRedsysNewResponse consultaTjtTokenRedsysNew(ConsultaTjtTokenRedsysNew consultaTjtTokenRedsysInputPart)
            throws ConsultaTjtTokenRedsysNewComIsbAlMpmwesTitularesEFExcGeneralTitularesEFault,
            ConsultaTjtTokenRedsysNewFault {
        ConsultaTjtTokenRedsysNewResponse ret = null;

        try {
            // get/create pagination info
            ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewEType requestEntrada = consultaTjtTokenRedsysInputPart
                    .getEntrada();
            Pagination pagination = new Pagination();
            pagination.selectorM0R0 = requestEntrada.getSelectorM0R0();
            if (!Pagination.SELECTORM0R0_1rst_call.equals(pagination.selectorM0R0)) {
                pagination.numeroTarjeta = consultaTjtTokenRedsysInputPart.getRepos().getCodAplicacionRepo();
            }

            // get/create idIssuer and cliente values
            Query query = new Query();
            query.idIssuer = requestEntrada.getEmpresa();
            NUMPERSONACLIENTEType requestEntradaCliente = requestEntrada.getCliente();
            String clientePart0 = "" + requestEntrada.getCliente().getTIPODEPERSONA();
            String clientePart1 = tcpUtil.leftPadding("" + requestEntradaCliente.getCODIGODEPERSONA(), 9, "0");
            query.cliente = clientePart0 + clientePart1;
            System.out.println("Entrada /api/cards :: cliente=" + query.cliente + " - idIssuer=" + query.idIssuer);

            // get cards
            CardsPagination carPag = this.getCardsByCustomerAndIssuer(query, pagination);

            // create ret
            ret = createResponse(query, carPag.pagination, carPag.cards);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ret;
    }

    private ConsultaTjtTokenRedsysNewResponse createResponse(Query query, Pagination pagination,
            List<ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewKLSType> retCards) {
        ConsultaTjtTokenRedsysNewResponse ret = new ConsultaTjtTokenRedsysNewResponse();

        // methodResult
        ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewSType ret0 = new ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewSType();
        ret.setMethodResult(ret0);
        ret0.setCodUsuarioRedsys("" + commonUtil.randInt(1000001, 9999998));
        ret0.setFinLista(pagination.finLista);

        // methodResult.repos
        ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewReposType ret0repos = new ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewReposType();
        ret0.setRepos(ret0repos);
        ret0repos.setCodAplicacionRepo(pagination.numeroTarjeta);
        CONTRATOType ret0reposContrato = new CONTRATOType();
        ret0repos.setContratoRepo(ret0reposContrato);
        CENTRODECONTRATOType ret0reposContratoCentro = new CENTRODECONTRATOType();
        ret0reposContrato.setCENTRO(ret0reposContratoCentro);
        ret0reposContratoCentro.setEMPRESA(query.idIssuer);

        ret0repos.setNumBeneficiarioRepo(commonUtil.randInt(1000001, 9999998));
        ret0repos.setNumTarjBeneficiarioRepo(commonUtil.randInt(1000001, 9999998));
        ret0repos.setTipoIntervRepo("R");

        // methodResult.datos
        ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewLSType ret0datos = new ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewLSType();
        ret0.setDatos(ret0datos);
        ret0datos.getDato().addAll(retCards);

        return ret;
    }

    private ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewKLSType createResponseCardItem(Card card) {
        ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewKLSType ret = new ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewKLSType();

        ret.setNumeroTarjeta(card.getPan());
        ret.setFechaCaducidad(commonUtil.parseDateToStr(card.getExpirationDate(), "yyMM"));
        ret.setCodPVV(commonUtil.randInt(1001, 99998));
        ret.setIndTokenizable("S");
        ret.setTipoSituacion(card.getCardStatusCode());
        //
        BLOQUEOCONTRATOTARJETAType retBloTar = new BLOQUEOCONTRATOTARJETAType();
        ret.setBloqueoTjta(retBloTar);
        retBloTar.setEMPRESA(card.getIssuerId());
        retBloTar.setCODBLOQUEOCONTRATOTJTA(Integer.parseInt(card.getBlockCodes().get(0)));
        //
        String product = card.getProduct();
        String productPart[] = product.split("-");
        ESTANDARDEREFERENCIAType retEstref = new ESTANDARDEREFERENCIAType();
        ret.setEstandarReferencia(retEstref);
        retEstref.setCODIGODEESTANDAR(productPart[2]);
        SUBTIPODEPRODUCTOType retEstrefSubtip = new SUBTIPODEPRODUCTOType();
        retEstref.setSUBTIPODEPRODUCTO(retEstrefSubtip);
        retEstrefSubtip.setSUBTIPODEPRODUCTO(productPart[1]);
        TIPODEPRODUCTOType retEstrefSubtipTip = new TIPODEPRODUCTOType();
        retEstrefSubtip.setTIPODEPRODUCTO(retEstrefSubtipTip);
        retEstrefSubtipTip.setEMPRESA(card.getIssuerId());
        retEstrefSubtipTip.setTIPODEPRODUCTO(productPart[0]);

        return ret;
    }

    private CardsPagination getCardsByCustomerAndIssuer(Query query, Pagination pag) {
        CardsPagination ret = new CardsPagination();
        ret.cards = new ArrayList<>();
        ret.pagination = pag;
        int itemsToAdd = Pagination.PAGE_SIZE;
        boolean isFirstCall = Pagination.SELECTORM0R0_1rst_call.equals(ret.pagination.selectorM0R0);
        boolean positioned = false;

        // adds cards page
        ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewKLSType responseCard = null;
        for (Card card : fileLoad.loadFile()) {
            if (query.cliente.equals(card.getCustomer()) && query.idIssuer.equals(card.getIssuerId())) { // matches
                                                                                                         // customer
                                                                                                         // AND
                                                                                                         // userId
                if (itemsToAdd > 0) {
                    if (isFirstCall || positioned) {
                        responseCard = createResponseCardItem(card);
                        ret.cards.add(responseCard);
                        itemsToAdd--;

                    } else {
                        if (ret.pagination.numeroTarjeta.equals(card.getPan())) {
                            positioned = true;
                        }
                    }
                }
            }
        }

        // set pagination values
        if (itemsToAdd > 0) { // calculate pagination.finLista
            ret.pagination.finLista = Pagination.FINLISTA_SI;
        } else {

            ret.pagination.finLista = Pagination.FINLISTA_NO;
        }
        if (responseCard != null) {
            ret.pagination.numeroTarjeta = responseCard.getNumeroTarjeta();// reset
                                                                           // pagination.numeroTarjeta
        }

        return ret;
    }

    class Query {
        String idIssuer;
        String cliente;
    }

    class Pagination {
        static final int PAGE_SIZE = 2;
        static final String SELECTORM0R0_1rst_call = "L"; // R for next calls
        static final String FINLISTA_SI = "S";
        static final String FINLISTA_NO = "N";

        String selectorM0R0 = SELECTORM0R0_1rst_call;
        String numeroTarjeta = "RANDOM::64f60a318b2340f0aa8ce67aa1c8eb5a";
        String finLista = FINLISTA_NO;
    }

    class CardsPagination {
        List<ComIsbAlMpmwesTitularesEFCbConsultaTjtTokenRedsysNewKLSType> cards;
        Pagination pagination;
    }
}
