package com.isban.cms.config.ws;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.server.EndpointInterceptor;

import com.isban.cms.util.SecurityWSInterceptor;

@Configuration
public class WebServiceConfig extends WsConfigurerAdapter {

    @Override
    public void addInterceptors(List<EndpointInterceptor> interceptors) {
        // register token security interceptor
        interceptors.add(new SecurityWSInterceptor());
    }

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPaths(
                "es.gruposantander.webservices.genericfault",
                "es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.internet.acmpmwestitulares.v1",
                "es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.openbank.internet.cbtypes.v1",
                "es.isban.webservices.mpmwes.titulares_e.f_mpmwes_titulares_e.openbank.internet.functionalfaults.v1",
                "es.isban.webservices.tdcc");
        return marshaller;
    }
}