package com.isban.cms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.isban.cms.model.Card;
import com.isban.cms.model.CardCmsResponse;
import com.isban.cms.model.CmsConstants;
import com.isban.cms.model.ListCardsCmsResponse;
import com.isban.cms.service.FileLoadService;

@RestController
public class CmsController {
    @Autowired
    FileLoadService fileLoad = null;

    private List<Card> getCardsByCustomerAndIssuer(String customerid, String issuerid) {
        List<Card> ret = new ArrayList<>();
        for (Card card : fileLoad.loadFile()) {
            if (customerid.equals(card.getCustomer()) && issuerid.equals(card.getIssuerId())) {
                ret.add(card);
            }
        }
        return ret;
    }

    /**
     * Para pruebas. En futuras versiones habra que quitarlo
     */
    @RequestMapping(value = "/api/card", method = RequestMethod.GET)
    @Deprecated
    public @ResponseBody ListCardsCmsResponse getCardsByIdCustomer(@RequestParam(value = "issuerid") String issuerid,
            @RequestParam(value = "customerid") String customerid) {
        ListCardsCmsResponse ret = new ListCardsCmsResponse(CmsConstants.OK_CODE, CmsConstants.OK_DESC);

        System.out.println("Entrada /api/cards :: " + customerid + "- IssuerId:" + issuerid);
        List<Card> cards = new ArrayList<>();
        try {
            cards = this.getCardsByCustomerAndIssuer(customerid, issuerid);
        } catch (Exception e) {
            ret.setCodRes(CmsConstants.KO_CODE);
            ret.setDesRes(CmsConstants.KO_DESC);
        }

        if (cards == null || cards.size() < 1) {
            ret.setCodRes(CmsConstants.KO_CARDS_EMPTY_CLIENT_CODE);
            ret.setDesRes(CmsConstants.KO_CARDS_EMPTY_CLIENT_DESC);
        }
        ret.setCards(cards);

        System.out.println("Peticion /api/cards :: " + ret.toString());
        return ret;
    }

    /**
     * Para pruebas. En futuras versiones habra que quitarlo
     */
    @RequestMapping(value = "/api/card/pan", method = RequestMethod.GET)
    @Deprecated
    public @ResponseBody CardCmsResponse getCardAndClientByPan(@RequestParam(value = "pan") String pan) {
        System.out.println("Entrada /api/card/pan :: " + pan);
        Card card = null;
        CardCmsResponse ret = new CardCmsResponse(CmsConstants.OK_CODE, CmsConstants.OK_DESC, card);
        try {
            List<Card> listcard = this.getCardByPan(pan);
            if (listcard != null && listcard.size() > 0)
                card = listcard.get(0);
        } catch (Exception e) {
            e.printStackTrace();
            ret.setCodRes(CmsConstants.KO_CODE);
            ret.setDesRes(CmsConstants.KO_DESC);
            return ret;
        }

        if (card == null) {
            ret.setCodRes(CmsConstants.KO_PAN_NO_EXIST_CODE);
            ret.setDesRes(CmsConstants.KO_PAN_NO_EXIST_DESC);
        }
        ret.setCard(card);
        System.out.println("Peticion /api/card/pan :: " + ret.toString());
        return ret;
    }

    private List<Card> getCardByPan(String pan) {
        List<Card> ret = new ArrayList<>();
        for (Card card : fileLoad.loadFile()) {
            //if (pan.equals(card.getItem())) { 
            if (pan.equals(card.getPan())) { 
                ret.add(card);
                break;
            }
        }
        return ret;
    }

}