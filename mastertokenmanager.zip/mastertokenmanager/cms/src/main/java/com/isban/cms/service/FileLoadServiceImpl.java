package com.isban.cms.service;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.csvreader.CsvReader;
import com.isban.cms.model.Card;
import com.isban.tokenmanager.util.FileLoadBase;

@Component
public class FileLoadServiceImpl extends FileLoadBase implements FileLoadService {
    public static final String FILE_CARDS_CMS = "CARDS_CMS_3.csv";

    @Override
    public List<Card> loadFile() {
        return createCardsCms();
    }

    public List<Card> createCardsCms() {
        List<Card> ret = null;

        CsvReader reader = getReader(FILE_CARDS_CMS);
        Map<String, Card> cardsCms = new HashMap<>();
        Integer count = 1;
        try {
            SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
            while (reader.readRecord()) {
                String blockId = reader.get("ID_BLK").toString();
                String pan = reader.get("PAN").toString();
                String dateExpiration = reader.get("Expiry_date").toString();

                Card card = null;

                if (!cardsCms.containsKey(pan + dateExpiration)) {
                    List<String> blockIds = new ArrayList<>();
                    blockIds.add(blockId);
                    card = new Card(count, pan, reader.get("ID_Issuer").toString(), reader.get("Cliente").toString(),
                            reader.get("ID_PROD").toString(), reader.get("ID_SITTAR").toString(),
                            formatDate.parse(reader.get("Last_transaction").toString()), blockIds,
                            formatDate.parse(reader.get("Expiry_date").toString()),
                            reader.get("accountnum").toString());
                } else {
                    card = cardsCms.get(pan + dateExpiration);
                    card.getBlockCodes().add(blockId);
                }

                cardsCms.put(pan + dateExpiration, card);
                System.out.println("AÃ±adida tareta  :: " + pan + " :: Issuer :: " + reader.get("ID_Issuer").toString() + " :: Cliente ::"  + reader.get("Cliente").toString());
                count++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } finally {
            reader.close();
        }

        ret = new ArrayList<>(cardsCms.values());
        return ret;
    }


}