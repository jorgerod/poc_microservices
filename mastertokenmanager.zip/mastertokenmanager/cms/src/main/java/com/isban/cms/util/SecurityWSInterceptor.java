package com.isban.cms.util;

import org.springframework.stereotype.Component;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.interceptor.EndpointInterceptorAdapter;

@Component
public class SecurityWSInterceptor extends EndpointInterceptorAdapter {

    public boolean handleRequest(MessageContext messageContext, Object endpoint) throws Exception {
        return true;
    }

}
