package com.isban.cms.model;


public class CardCmsResponse {

    String codRes;
    String desRes;
    Card card;
    
	public CardCmsResponse() {
	        
	}

	public CardCmsResponse(String codRes, String desRes) {
        this.codRes = codRes;
        this.desRes = desRes;
    }   
    	
	
    public CardCmsResponse(String codRes, String desRes, Card card) {
        this.codRes = codRes;
        this.desRes = desRes;
        this.card =  card;
    }

    public String getCodRes() {
        return codRes;
    }

    public void setCodRes(String codRes) {
        this.codRes = codRes;
    }

    public String getDesRes() {
        return desRes;
    }

    public void setDesRes(String desRes) {
        this.desRes = desRes;
    }

    public Card getCard() {
        return card;
    }

    public void setCard(Card card) {
        this.card = card;
    }

    @Override
    public String toString() {
        return "CardCmsResponse [codRes=" + codRes + ", desRes=" + desRes
                + ", card=" + card + "]";
    }

    
	

}
