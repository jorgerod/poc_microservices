package com.isban.cms.model;

public class CmsConstants {
    public static final String OK_CODE = "0000";
    public static final String OK_DESC = "OK (Operación realizada con éxito)";
    public static final String KO_CODE = "0001";
    public static final String KO_DESC = "KO (Error del sistema).";
    public static final String KO_CARDS_EMPTY_CLIENT_CODE = "0004";
    public static final String KO_CARDS_EMPTY_CLIENT_DESC = "KO (Cliente sin tarjetas)";
    
    public static final String KO_PAN_NO_EXIST_CODE = "0003";
    public static final String KO_PAN_NO_EXIST_DESC = "KO (Pan no existente)";
}
