package com.isban.cms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeader;

import com.isban.cms.model.Card;
import com.isban.cms.model.CmsConstants;
import com.isban.tokenmanager.util.CommonUtil;
import com.isban.cms.util.StmSecurityWS;
import com.isban.cms.ws.model.CardType;
import com.isban.cms.ws.model.GetCardsRequest;
import com.isban.cms.ws.model.GetCardsResponse;
import com.isban.cms.ws.model.ListCardType;

@Endpoint
public class CmsEndpoint {
    private static final String NAMESPACE_URI = "http://www.isban.com/cms/ws/model";

    @Autowired
    FileLoadService fileLoad = null;

    @Autowired
    CommonUtil commonUtil;

    @StmSecurityWS
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCardsRequest")
    @ResponsePayload
    public GetCardsResponse getCountry(@RequestPayload GetCardsRequest request, SoapHeader soapHeader) {
        GetCardsResponse ret = new GetCardsResponse();

        ret.setCodResponse(CmsConstants.OK_CODE);
        ret.setDescResponse(CmsConstants.OK_DESC);

        String clientId = request.getClientId();
        String issuerId = request.getIssuerId();
        System.out.println("Entrada /api/cards :: " + clientId + "- IssuerId:" + issuerId);

        List<Card> cards = new ArrayList<>();
        try {
            cards = this.getCardsByCustomerAndIssuer(clientId, issuerId);
        } catch (Exception e) {
            ret.setCodResponse(CmsConstants.KO_CODE);
            ret.setDescResponse(CmsConstants.KO_DESC);
        }

        if (cards == null || cards.size() < 1) {
            ret.setCodResponse(CmsConstants.KO_CARDS_EMPTY_CLIENT_CODE);
            ret.setDescResponse(CmsConstants.KO_CARDS_EMPTY_CLIENT_DESC);
        }

        ListCardType lct = new ListCardType();

        lct.getCard().addAll(convertCards2CardsType(cards));
        ret.setCards(lct);

        System.out.println("Peticion /api/cards :: " + ret.toString());
        return ret;

    }

    private List<Card> getCardsByCustomerAndIssuer(String customerid, String issuerid) {
        List<Card> ret = new ArrayList<>();
        for (Card card : fileLoad.loadFile()) {
            if (customerid.equals(card.getCustomer()) && issuerid.equals(card.getIssuerId())) {
                ret.add(card);
            }
        }
        return ret;
    }

    private List<CardType> convertCards2CardsType(List<Card> cards) {
        List<CardType> ret = new ArrayList<>();

        for (Card card : cards) {
            CardType cardType = new CardType();

            cardType.setPan(card.getPan());
            cardType.setProduct(card.getProduct());
            cardType.setSittarcode(card.getCardStatusCode());
            cardType.setLastmovedate(commonUtil.parseDateToStr(card.getLastMovementDate(), "yyyyMMdd"));
            cardType.getBlocks().addAll(card.getBlockCodes());
            cardType.setExpirationdate(commonUtil.parseDateToStr(card.getExpirationDate(), "yyMM"));
            cardType.setAccountnum(card.getAccountNum());

            ret.add(cardType);
        }
        return ret;
    }
}