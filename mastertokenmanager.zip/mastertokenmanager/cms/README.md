
## cms

**Simulador cms**

Incorpora un servidor embebido jetty

Para lanzar el servidor:

`mvn -pl cms/ jetty:run`


Prueba desde curl

`curl http://localhost:9091/cms/api/card?customerid=000000004`

`curl http://localhost:9091/cms/api/card/pan?pan=5188012754279517`

Spring WS:
    `https://spring.io/guides/gs/producing-web-service/`
    `http://localhost:9091/cms/ws/countries.wsdl`