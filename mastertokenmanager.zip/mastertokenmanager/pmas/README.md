Url's utiles
===
local
---
- http://localhost:9283/pmas/ws/pmas?wsdl