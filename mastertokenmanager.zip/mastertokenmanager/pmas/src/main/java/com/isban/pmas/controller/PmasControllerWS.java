package com.isban.pmas.controller;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import es.isban.webservices.redint.redes_m.f_redint_redes_m.ccbank.intranet.cbtypes.v1.ComIsbAlRedintRedesMFCbImputarReintegroSinTarjetaSType;
import es.isban.webservices.redint.redes_m.f_redint_redes_m.intranet.acredintredes.v1.ACREDINTRedesPortTypeHTTP;
import es.isban.webservices.redint.redes_m.f_redint_redes_m.intranet.acredintredes.v1.ImputarReintegroSinTarjeta;
import es.isban.webservices.redint.redes_m.f_redint_redes_m.intranet.acredintredes.v1.ImputarReintegroSinTarjetaComIsbAlRedintRedesMFExcExceptionVerificarFirmaFault;
import es.isban.webservices.redint.redes_m.f_redint_redes_m.intranet.acredintredes.v1.ImputarReintegroSinTarjetaComIsbAlRedintRedesMFExcGeneralExceptionImputarFault;
import es.isban.webservices.redint.redes_m.f_redint_redes_m.intranet.acredintredes.v1.ImputarReintegroSinTarjetaFault;
import es.isban.webservices.redint.redes_m.f_redint_redes_m.intranet.acredintredes.v1.ImputarReintegroSinTarjetaResponse;

//@Component
//@WebService(endpointInterface = "es.isban.webservices.redint.redes_m.f_redint_redes_m.intranet.acredintredes.v1.ACREDINTRedesPortTypeHTTP")
@Endpoint
public class PmasControllerWS implements ACREDINTRedesPortTypeHTTP {
    
    private static final String NAMESPACE_URI = "http://www.isban.es/webservices/REDINT/Redes_m/F_redint_redes_m/intranet/ACREDINTRedes/v1";

    private static final String WITHDRAWAL_OK_CODE = "0100";
    private static final String CONFIRMATION_REVERSAL_CODE = "0420";
    private static final int COD_AUTH_LENGHT = 16;
    private static final int RESPONSE_OK = 0;

    // imputarReintegroSinTarjeta_InputPart
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "imputarReintegroSinTarjeta")
    @ResponsePayload
    public ImputarReintegroSinTarjetaResponse imputarReintegroSinTarjeta(@RequestPayload ImputarReintegroSinTarjeta request)
            throws ImputarReintegroSinTarjetaComIsbAlRedintRedesMFExcExceptionVerificarFirmaFault,
            ImputarReintegroSinTarjetaComIsbAlRedintRedesMFExcGeneralExceptionImputarFault,
            ImputarReintegroSinTarjetaFault {
        ImputarReintegroSinTarjetaResponse ret = new ImputarReintegroSinTarjetaResponse();

        if (isWithdrawalConfirmation(request)) {
            ComIsbAlRedintRedesMFCbImputarReintegroSinTarjetaSType obj = new ComIsbAlRedintRedesMFCbImputarReintegroSinTarjetaSType();
            obj.setCODRESPU(RESPONSE_OK);
            obj.setCDAUTOR(RandomStringUtils.randomNumeric(COD_AUTH_LENGHT));
            obj.setIDAUTOZ(request.getEntrada().getCODENTI());
            ret.setMethodResult(obj);
        } else if (isConfirmationReversal(request)) {
            ComIsbAlRedintRedesMFCbImputarReintegroSinTarjetaSType obj = new ComIsbAlRedintRedesMFCbImputarReintegroSinTarjetaSType();
            obj.setCODRESPU(RESPONSE_OK);
            obj.setCDAUTOR(RandomStringUtils.randomNumeric(COD_AUTH_LENGHT));
            obj.setIDAUTOZ(request.getEntrada().getCODENTI());
            ret.setMethodResult(obj);
        }

        return ret;
    }

    private boolean isConfirmationReversal(ImputarReintegroSinTarjeta request) {
        return CONFIRMATION_REVERSAL_CODE.equals(request.getEntrada().getTIOPEEM());
    }

    private boolean isWithdrawalConfirmation(ImputarReintegroSinTarjeta request) {
        return WITHDRAWAL_OK_CODE.equals(request.getEntrada().getTIOPEEM());
    }

}
