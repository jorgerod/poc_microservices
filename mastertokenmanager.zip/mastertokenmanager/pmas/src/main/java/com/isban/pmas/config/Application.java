package com.isban.pmas.config;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.isban.pmas.controller.PmasControllerWS;
import com.isban.tokenmanager.config.StmCryptoProperties;

@SpringBootApplication
@ComponentScan(basePackages = { "com.isban.tokenmanager", "com.isban.pmas", "com.isban.pms"} )
@EnableConfigurationProperties({ StmCryptoProperties.class })
public class Application implements CommandLineRunner {
    private static final Logger logger = Logger.getLogger(Application.class);
    
    
    @Value("${pmas.ws.protocol}")
    public String pmasWsProtocol;
    @Value("${pmas.ws.host}")
    public String pmasWsHost;
    @Value("${pmas.ws.port}")
    public String pmasWsPort;
    @Value("${pmas.ws.url.base}")
    public String pmasWsUrlbase;
    @Autowired
    PmasControllerWS pmasControllerWS;
    
    public static void main(String[] args) {
        logger.info("***************************************************");
        logger.info("Starting PMAS");
        
        SpringApplication.run(Application.class, args);
        
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("");
        logger.info("Started PMAS");
        logger.info("");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
    }
    
    @Override
    public void run(String... args) throws Exception {
//        String address = "" + pmasWsProtocol + "://" + pmasWsHost+ ":" + pmasWsPort + "/" + pmasWsUrlbase+ "";
        //Endpoint.publish(address, pmasControllerWS);
    }
    
    @Bean
    public JaxbJacksonObjectMapper jaxbJacksonObjectMapper() {
        return new JaxbJacksonObjectMapper();
    }
}