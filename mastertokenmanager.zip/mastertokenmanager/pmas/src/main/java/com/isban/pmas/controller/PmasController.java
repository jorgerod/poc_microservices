package com.isban.pmas.controller;

import java.io.IOException;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.csvreader.CsvReader;
import com.isban.tokenmanager.integration.pmas.ConfirmationHttpRequest;
import com.isban.tokenmanager.integration.pmas.ConfirmationHttpResponse;
import com.isban.tokenmanager.integration.pmas.ConfirmationReversalHttpRequest;
import com.isban.tokenmanager.integration.ppaa.CommonHttpResponse;
import com.isban.tokenmanager.util.FileLoadBase;

@RestController
public class PmasController {

    private static final String FILE_ACCOUNTS = "ACCOUNTS.csv";
    private static final String CODE_MESSAGE_FORMAT_UNKNOWN_ERROR = "901";
    private static final String CODE_INTERNAL_SYSTEM_ERROR = "909";
    //private static final String ACCOUNT_ERROR = "904";
    private static final String CODE_OK = "000";
    
    @RequestMapping(value = "/api/${majorVer}/${minorVer}/withDrawalConfirmation", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public @ResponseBody <T extends CommonHttpResponse> ConfirmationHttpResponse withDrawalConfirmation(@RequestBody ConfirmationHttpRequest request) {
         String contract = request.getContract();
         return doSomething(contract, null);
     }

    @RequestMapping(value = "/api/${majorVer}/${minorVer}/confirmationReversal", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public @ResponseBody ConfirmationHttpResponse confirmationReversal(@RequestBody ConfirmationReversalHttpRequest request) {
         String contract = request.getContract();
         //String retentionId = request.getRetentionId();
         return doSomething(contract, null);
     }
    
//    @RequestMapping(value = "/api/${majorVer}/${minorVer}/testString", produces = MediaType.TEXT_PLAIN_VALUE, method = RequestMethod.GET)
//    public @ResponseBody String testRest( @RequestParam(value="name", defaultValue="World") String name) {
//         System.out.println(name);
//         //String retentionId = request.getRetentionId();
//         return "Hola";
//     }    
    
    

    private ConfirmationHttpResponse doSomething(String contract, String retentionId) {
        ConfirmationHttpResponse response = new ConfirmationHttpResponse();
        response.setCode(CODE_MESSAGE_FORMAT_UNKNOWN_ERROR);
        
        FileLoadBase fileLoad = new FileLoadBase();
        CsvReader reader = fileLoad.getReader(FILE_ACCOUNTS);
        try
        {
            while (reader.readRecord()) {
                String account = reader.get("AccountNumber").toString();
                if(account.equals(contract))
                {
                    response.setCode(CODE_OK);
                    if(retentionId == null)
                    {
                       // SimpleDateFormat sdfDate = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSSSSS");
                        response.setAuthorizationCode("9998887770");
                        response.setAuthorizerId("0309");
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            response.setCode(CODE_INTERNAL_SYSTEM_ERROR);
        } catch (Exception e) {
            response.setCode(CODE_INTERNAL_SYSTEM_ERROR);
            e.printStackTrace();
        } finally {
            reader.close();
        }
        return response;
    }
}
