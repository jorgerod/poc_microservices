package com.isban.tokenmanager.dto;

import java.util.Date;

public class ProductCardArtDto extends LifeTimeDto {

    private String productId;
    private String cardArt;
    private String cardArtTag;

    public ProductCardArtDto() {
    }

    public ProductCardArtDto(String issuerId, String tokenTypeId, String productId, Date date, String cardart, String cardArtTag) {
        this.issuerId = issuerId;
        this.tokenTypeId = tokenTypeId;
        this.productId = productId;
        this.setStartDate(date);
        this.cardArt = cardart;
        this.cardArtTag = cardArtTag;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getCardArt() {
        return cardArt;
    }

    public void setCardArt(String cardArt) {
        this.cardArt = cardArt;
    }

    public String getCardArtTag() {
        return cardArtTag;
    }

    public void setCardArtTag(String cardArtTag) {
        this.cardArtTag = cardArtTag;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((cardArt == null) ? 0 : cardArt.hashCode());
        result = prime * result + ((cardArtTag == null) ? 0 : cardArtTag.hashCode());
        result = prime * result + ((productId == null) ? 0 : productId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ProductCardArtDto other = (ProductCardArtDto) obj;
        if (cardArt == null) {
            if (other.cardArt != null)
                return false;
        } else if (!cardArt.equals(other.cardArt))
            return false;
        if (cardArtTag == null) {
            if (other.cardArtTag != null)
                return false;
        } else if (!cardArtTag.equals(other.cardArtTag))
            return false;
        if (productId == null) {
            if (other.productId != null)
                return false;
        } else if (!productId.equals(other.productId))
            return false;
        if (issuerId == null) {
            if (other.issuerId != null)
                return false;
        } else if (!issuerId.equals(other.issuerId))
            return false;
        if (tokenTypeId == null) {
            if (other.tokenTypeId != null)
                return false;
        } else if (!tokenTypeId.equals(other.tokenTypeId))
            return false;
        if (getStartDate() == null) {
            if (other.getStartDate() != null)
                return false;
        } else if (!getStartDate().equals(other.getStartDate()))
            return false;

        return true;
    }
    
}
