package com.isban.tokenmanager.dto;

import java.util.List;

public class TypeBinResponse extends ResponseBase {

    private List<TypeBinDto> typeBins;

    public TypeBinResponse(String code, String description) {
        super(code, description);
    }

    public TypeBinResponse() {
    }

    public List<TypeBinDto> getTypeBins() {
        return typeBins;
    }

    public void setTypeBins(List<TypeBinDto> typeBins) {
        this.typeBins = typeBins;
    }

}   
