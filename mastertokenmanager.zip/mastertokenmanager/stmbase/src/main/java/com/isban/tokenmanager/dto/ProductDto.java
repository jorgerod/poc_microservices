package com.isban.tokenmanager.dto;

public class ProductDto extends LifeTimeDto {

    private String issuerId;
    private String productId;
    private String name;
    private String description;
    private String cartArtDefault;
    private Integer maxTokens;
    private String tokenTypeId;

    public ProductDto() {
    }

    public ProductDto(String issuerId, String tokenTypeId, String productId, String name) {
        this.issuerId = issuerId;
        this.productId = productId;
        this.name = name;
        this.tokenTypeId = tokenTypeId;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCartArtDefault() {
        return cartArtDefault;
    }

    public void setCartArtDefault(String cartArtDefault) {
        this.cartArtDefault = cartArtDefault;
    }

    public Integer getMaxTokens() {
        return maxTokens;
    }

    public void setMaxTokens(Integer maxTokens) {
        this.maxTokens = maxTokens;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }
}
