package com.isban.tokenmanager.dto;

public class CardLessSMSResponse extends CardLessResponseBase{
    
    
}
