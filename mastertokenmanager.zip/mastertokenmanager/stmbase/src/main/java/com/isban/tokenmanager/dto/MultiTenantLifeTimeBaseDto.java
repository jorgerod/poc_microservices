package com.isban.tokenmanager.dto;

public class MultiTenantLifeTimeBaseDto extends LifeTimeDto {

    private String tokenRequestorId;

    public MultiTenantLifeTimeBaseDto(String issuerId, String tokenTypeId, String tokenRequestId) {
        super();
        this.issuerId = issuerId;
        this.tokenRequestorId = tokenRequestId;
        this.tokenTypeId = tokenTypeId;
    }

    public String getTokenRequestId() {
        return tokenRequestorId;
    }

    public void setTokenRequestId(String tokenRequestId) {
        this.tokenRequestorId = tokenRequestId;
    }
}
