package com.isban.tokenmanager.integration.cardless;

import java.util.List;

import com.isban.tokenmanager.dto.ResponseBase;

public class ReportResponse  extends ResponseBase {

    private List<ReportItem> items;

    public ReportResponse(String code, String description) {
        super(code, description);
    }

    public List<ReportItem> getItems() {
        return items;
    }

    public void setItems(List<ReportItem> items) {
        this.items = items;
    }
}
