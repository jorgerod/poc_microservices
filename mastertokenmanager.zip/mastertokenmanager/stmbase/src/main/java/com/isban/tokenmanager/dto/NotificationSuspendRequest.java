package com.isban.tokenmanager.dto;

public class NotificationSuspendRequest extends NotificationTokenizationBaseRequest {

    public NotificationSuspendRequest() {
    }
}
