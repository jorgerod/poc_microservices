package com.isban.tokenmanager.integration.tsp;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.isban.tokenmanager.dto.ResponseBase;
import com.isban.tokenmanager.model.enm.ResponseStateEnum;

public class InformationHttpResponse extends ResponseBase {

    private Integer expiration;
    private String unitExpiration;
    
    public InformationHttpResponse(ResponseStateEnum state) {
        super(state);
    }
    public Integer getExpiration() {
        return expiration;
    }
    public void setExpiration(Integer expiration) {
        this.expiration = expiration;
    }
    public String getUnitExpiration() {
        return unitExpiration;
    }
    public void setUnitExpiration(String unitExpiration) {
        this.unitExpiration = unitExpiration;
    }
    
    @JsonProperty(value = "codeResponse")
    public String getCode() {
        return super.getCode();
    }

    @JsonProperty(value = "desResponse")
    public String getDescription() {
        return super.getDescription();
    }


}
