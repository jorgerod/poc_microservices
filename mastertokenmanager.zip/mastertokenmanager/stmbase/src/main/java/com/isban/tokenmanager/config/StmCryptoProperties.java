package com.isban.tokenmanager.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "stmcrypto", ignoreUnknownFields = false)
public class StmCryptoProperties {

    private String host = "";
    private String path = "";

    private String encryptEndpointUrl = "";
    private String decryptEndpointUrl = "";
    private String macEndpointUrl = "";

    public String getDecryptEndpointUrl() {
        return decryptEndpointUrl;
    }

    public String getHost() {
        return host;
    }

    public String getMacEndpointUrl() {
        return macEndpointUrl;
    }

    public void setDecryptEndpointUrl(String decryptEndpointUrl) {
        this.decryptEndpointUrl = decryptEndpointUrl;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public void setMacEndpointUrl(String macEndpointUrl) {
        this.macEndpointUrl = macEndpointUrl;
    }

    public String getEncryptEndpointUrl() {
        return encryptEndpointUrl;
    }

    public void setEncryptEndpointUrl(String encryptEndpointUrl) {
        this.encryptEndpointUrl = encryptEndpointUrl;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

}
