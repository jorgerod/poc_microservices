package com.isban.tokenmanager.integration.tsp;

import java.util.Date;

import com.isban.tokenmanager.dto.ResponseBase;
import com.isban.tokenmanager.model.enm.ResponseStateEnum;

public class ProvisioningHttpResponse extends ResponseBase {

    private String tokenReferenceId;
    private String ditem;
    private Date expirationDitem;

    
    public ProvisioningHttpResponse(ResponseStateEnum responseStateEnum) {
        super(responseStateEnum);
    }
    
    public ProvisioningHttpResponse() {
        super();
    }

    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    public Date getExpirationDitem() {
        return expirationDitem;
    }

    public void setExpirationDitem(Date expirationDitem) {
        this.expirationDitem = expirationDitem;
    }

}
