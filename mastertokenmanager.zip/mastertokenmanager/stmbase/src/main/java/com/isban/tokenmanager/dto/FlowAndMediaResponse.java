package com.isban.tokenmanager.dto;

import java.util.List;

import com.isban.tokenmanager.integration.dto.DeliveryMethodResponse;

public class FlowAndMediaResponse extends ResponseBase {

    private String flowDecision;

    private List<DeliveryMethodResponse> media;

    private String productId;
    private String tycId;
    private String cardArtId;

    public FlowAndMediaResponse() {
    }

    public FlowAndMediaResponse(String code, String description) {
        super(code, description);
    }

    public String getFlowDecision() {
        return flowDecision;
    }

    public void setFlowDecision(String flowDecision) {
        this.flowDecision = flowDecision;
    }

    public List<DeliveryMethodResponse> getMedia() {
        return media;
    }

    public void setMedia(List<DeliveryMethodResponse> media) {
        this.media = media;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getTycId() {
        return tycId;
    }

    public void setTycId(String tycId) {
        this.tycId = tycId;
    }

    public String getCardArtId() {
        return cardArtId;
    }

    public void setCardArtId(String cardArtId) {
        this.cardArtId = cardArtId;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("FlowAndMediaResponse [flowDecision=").append(flowDecision).append(", media=").append(media)
                .append(", productId=").append(productId).append(", tycId=").append(tycId).append(", cardArtId=")
                .append(cardArtId).append("]");
        return builder.toString();
    }

}
