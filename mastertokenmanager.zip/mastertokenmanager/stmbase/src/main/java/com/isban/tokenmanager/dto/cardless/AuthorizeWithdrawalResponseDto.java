package com.isban.tokenmanager.dto.cardless;

import com.isban.tokenmanager.dto.ResponseBase;

public class AuthorizeWithdrawalResponseDto  extends ResponseBase {

    private String amount;
    private String currency;
    private String authorizationCode;
    private String authorizerId;
    
    private String issuerId;
    private String tokenTypeId;
    private String tokenRequestorId;
    
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public AuthorizeWithdrawalResponseDto(String code, String description) {
        super(code, description);
    }
    
    public String getAuthorizationCode() {
        return authorizationCode;
    }
    public void setAuthorizationCode(String authorizationCode) {
        this.authorizationCode = authorizationCode;
    }
    public String getAuthorizerId() {
        return authorizerId;
    }
    public void setAuthorizerId(String authorizerId) {
        this.authorizerId = authorizerId;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    @Override
    public String toString() {
        return "AuthorizeWithdrawalResponseDto [amount=" + amount + ", currency=" + currency + ", authorizationCode="
                + authorizationCode + ", authorizerId=" + authorizerId + ", issuerId=" + issuerId + ", tokenTypeId="
                + tokenTypeId + ", tokenRequestorId=" + tokenRequestorId + "]";
    }

    
}
