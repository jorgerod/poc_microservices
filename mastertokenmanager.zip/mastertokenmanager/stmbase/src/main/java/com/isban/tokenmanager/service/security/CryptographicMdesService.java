package com.isban.tokenmanager.service.security;

import java.security.PrivateKey;
import java.security.PublicKey;

public interface CryptographicMdesService extends CryptographicService {
    // ///////////////////////////////////////////////////////////////////////
    //CryptographicMdesService - > SKC + PKC
    public MdesEncOutput encrypt( EncSkcInput input4encSkc, EncPkcOaepInput input4encPkcOaep );  //USES:: public byte[] encrypt( EncSkcInput input4enc )  +++  public byte[] encryptOtpSecretKey( EncPkcOaepInput input4enc ) 
    public byte[] decrypt( DecPkcOaepInput input4decPkcOaep, DecSkcInput input4decSkc );  //USES:: public byte[] decryptOtpSecretKey( DecPkcOaepInput input4dec )   +++   public byte[] decrypt( DecSkcInput input4dec ) 
    //
    public class MdesEncOutput{
        public EncSkcInput input4encSkc;
        public EncPkcOaepInput input4encPkcOaep;
        public byte[] encryptedOtpSecretKey;
        public byte[] encryptedMsg;
    }
    
    
    
    
    
    // ///////////////////////////////////////////////////////////////////////
    //SKC = https://en.wikipedia.org/wiki/Cryptography#Symmetric-key_cryptography
    public byte[] generateOtpSecretKey();
    public byte[] generateIv();
    public byte[] encrypt( EncSkcInput input4enc );
    public byte[] decrypt( DecSkcInput input4dec );
    //
    public class EncSkcInput{
        public byte[] msg;
        public byte[] otpSecretKey;
        public byte[] iv;
    }
    public class DecSkcInput{
        public byte[] encryptedMsg;
        public byte[] otpSecretKey;
        public byte[] iv;
    }
    
    
    
    
    
    // ///////////////////////////////////////////////////////////////////////
    //PKC = https://en.wikipedia.org/wiki/Cryptography#Public-key_cryptography
    public byte[] encryptOtpSecretKey( EncPkcOaepInput input4enc );
    public byte[] decryptOtpSecretKey( DecPkcOaepInput input4dec );
    //
    public class EncPkcOaepInput{
        public byte[] msg;
        public PublicKey publicKey;
        public String oaepHashingAlgorithm;
    }
    public class DecPkcOaepInput{
        public byte[] encryptedMsg;
        public PrivateKey privateKey;
        public String oaepHashingAlgorithm;
    }
    public class PreDecPkcOaepInput{
        byte[] encryptedMsg;
        byte[] publicKeyFingerPrintUsed;
        String oaepHashingAlgorithm;
    }
    /*
    TOD0 Service INPUT PreDecPkcOaepInput  ->  CREATES  ->  DecPkcOaepInput 
    TOD0 Service INPUT    EncPkcOaepInput  ->  CREATES  ->  PreDecPkcOaepInput 
    */
}
