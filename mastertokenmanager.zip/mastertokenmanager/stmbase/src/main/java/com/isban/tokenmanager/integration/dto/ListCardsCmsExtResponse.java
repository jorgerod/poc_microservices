package com.isban.tokenmanager.integration.dto;

import java.util.List;

public class ListCardsCmsExtResponse {

    private String codRes;
    private List<CardCms> cards;

    public ListCardsCmsExtResponse() {

    }

    public ListCardsCmsExtResponse(String codRes, String desRes) {
        this.codRes = codRes;
    }


    public ListCardsCmsExtResponse(String codRes, String desRes, List<CardCms> cards) {
        this.codRes = codRes;
        this.cards = cards;
    }

    public String getCodRes() {
        return codRes;
    }

    public void setCodRes(String codRes) {
        this.codRes = codRes;
    }

    public List<CardCms> getCards() {
        return cards;
    }

    public void setCards(List<CardCms> cards) {
        this.cards = cards;
    }

    @Override
    public String toString() {
        return "ListCardsResponse [codRes=" + codRes + ", cards=" + cards + "]";
    }


}
