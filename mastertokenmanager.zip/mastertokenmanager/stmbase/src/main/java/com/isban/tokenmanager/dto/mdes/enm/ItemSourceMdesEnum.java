package com.isban.tokenmanager.dto.mdes.enm;

public enum ItemSourceMdesEnum {
    CARD_ON_FILE,
    CARD_ADDED_MANUALLY,
    CARD_ADDED_VIA_APPLICATION;
}
