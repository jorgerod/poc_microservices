package com.isban.tokenmanager.stmcrypto.dto;

public class DecryptDataOutput {

    /* 
     * Properties
     */
    private Integer errorCode = 0;
    private String errorDescription = "No error";
    private String iv;
    private Integer decryptedDataLength;
    private String decryptedData;
    
    /*
     * Getters and setters
     */
    public Integer getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }
    public String getErrorDescription() {
        return errorDescription;
    }
    public void setErrorDescription(String value) {
        this.errorDescription = value;
    }
    public String getIv() {
        return iv;
    }
    public void setIv(String iv) {
        this.iv = iv;
    }
    public Integer getDecryptedDataLength() {
        return decryptedDataLength;
    }
    public void setDecryptedDataLength(Integer encryptedDataLength) {
        this.decryptedDataLength = encryptedDataLength;
    }
    public String getDecryptedData() {
        return decryptedData;
    }
    public void setDecryptedData(String encryptedData) {
        this.decryptedData = encryptedData;
    }

}
