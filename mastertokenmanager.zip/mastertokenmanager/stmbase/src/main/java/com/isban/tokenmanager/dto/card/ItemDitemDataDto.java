package com.isban.tokenmanager.dto.card;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isban.tokenmanager.dto.DitemDataDto;
import com.isban.tokenmanager.dto.ItemDataDto;

/**
 * Object that represents the request of the Pan-DPan dupla.
 *  
 * @author realsec
 */
public class ItemDitemDataDto {

    private ItemDataDto itemData;
    private DitemDataDto ditemData;
    private String tokenReferenceId;


    private String tokenAssuranceLevel = null;
    private String tokenTypeExt = null;
    private Integer numberActiveTokensPan = 0;
    private Integer numberInactiveTokens = 0;
    private Integer numberSuspendedTokens = 0;
    private Integer numberActivationAttemps = 0;
    private String termAndConditions = null;

    @JsonFormat(pattern = "yyyyMMdd")
    private Date termAndConditionsDate;

  

    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    public ItemDataDto getItemData() {
        return itemData;
    }

    public void setItemData(ItemDataDto itemData) {
        this.itemData = itemData;
    }

    public DitemDataDto getDitemData() {
        return ditemData;
    }

    public void setDitemData(DitemDataDto ditemData) {
        this.ditemData = ditemData;
    }

    public String getTokenAssuranceLevel() {
        return tokenAssuranceLevel;
    }

    public void setTokenAssuranceLevel(String tokenAssuranceLevel) {
        this.tokenAssuranceLevel = tokenAssuranceLevel;
    }


    
    public String getTokenTypeExt() {
        return tokenTypeExt;
    }

    public void setTokenTypeExt(String tokenTypeExt) {
        this.tokenTypeExt = tokenTypeExt;
    }

    public Integer getNumberActiveTokensPan() {
        return numberActiveTokensPan;
    }

    public void setNumberActiveTokensPan(Integer numberActiveTokensPan) {
        this.numberActiveTokensPan = numberActiveTokensPan;
    }

    public Integer getNumberInactiveTokens() {
        return numberInactiveTokens;
    }

    public void setNumberInactiveTokens(Integer numberInactiveTokens) {
        this.numberInactiveTokens = numberInactiveTokens;
    }

    public Integer getNumberSuspendedTokens() {
        return numberSuspendedTokens;
    }

    public void setNumberSuspendedTokens(Integer numberSuspendedTokens) {
        this.numberSuspendedTokens = numberSuspendedTokens;
    }

    public String getTermAndConditions() {
        return termAndConditions;
    }

    public void setTermAndConditions(String termAndConditions) {
        this.termAndConditions = termAndConditions;
    }

    public Date getTermAndConditionsDate() {
        return termAndConditionsDate;
    }

    public void setTermAndConditionsDate(Date termAndConditionsDate) {
        this.termAndConditionsDate = termAndConditionsDate;
    }

    public Integer getNumberActivationAttemps() {
        return numberActivationAttemps;
    }

    public void setNumberActivationAttemps(Integer numberActivationAttemps) {
        this.numberActivationAttemps = numberActivationAttemps;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ItemDitemDataDto [itemData=").append(itemData).append(", ditemData=").append(ditemData)
                .append(", tokenReferenceId=").append(tokenReferenceId).append(", tokenAssuranceLevel=")
                .append(tokenAssuranceLevel).append(", tokenTypeExt=").append(tokenTypeExt)
                .append(", numberActiveTokensPan=").append(numberActiveTokensPan).append(", numberInactiveTokens=")
                .append(numberInactiveTokens).append(", numberSuspendedTokens=").append(numberSuspendedTokens)
                .append(", numberActivationAttemps=").append(numberActivationAttemps).append(", termAndConditions=")
                .append(termAndConditions).append(", termAndConditionsDate=").append(termAndConditionsDate).append("]");
        return builder.toString();
    }

}