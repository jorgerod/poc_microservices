package com.isban.tokenmanager.integration.dto;

public class NotificationCreatedTokenDataTcpResponse extends TcpCommonDataResponse {

    public NotificationCreatedTokenDataTcpResponse() {
        super();
    }

    public NotificationCreatedTokenDataTcpResponse(NotificationCreatedTokenDataTcpRequest request) {
        super(request.getOperationId(), request.getOperationDateTime());
    }

    @Override
    public String toString() {
        return "NotificationCreatedTokenDataTcpResponse [getOperationId()=" + getOperationId() + ", getOperationDate()="
                + getOperationDateTime() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
                + ", hashCode()=" + hashCode() + "]";
    }
}
