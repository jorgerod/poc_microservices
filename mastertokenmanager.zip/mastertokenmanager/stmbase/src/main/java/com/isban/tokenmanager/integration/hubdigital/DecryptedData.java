package com.isban.tokenmanager.integration.hubdigital;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class DecryptedData {
    
    @ApiModelProperty(required = true, value = "Primary Account Number")
    @NotNull
    @Size(min = 16, max = 28)
    private String pan;
    
    @ApiModelProperty(required = true, value = "Expiration Date")
    @NotNull
    private String expDate;
    
    @ApiModelProperty(required = false, value = "Name of owner")
    private String cardholderName;
    
    @ApiModelProperty(required = false, value = "CVV of the card. It will only be present in payment applications that support it.")
    @Size(min = 3, max = 3)
    private String cvv;

    @ApiModelProperty(required = false, value = "Deployed token.")
    @Size(min = 12, max = 19)
    private String token;
    
    @ApiModelProperty(required = false, value = "Token expiration date (Format: YYMM).")
    @Size(min = 4, max = 4)
    private String tokenExpDate;
    
    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    public String getCardholderName() {
        return cardholderName;
    }

    public void setCardholderName(String cardholderName) {
        this.cardholderName = cardholderName;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getTokenExpDate() {
        return tokenExpDate;
    }

    public void setTokenExpDate(String tokenExpDate) {
        this.tokenExpDate = tokenExpDate;
    }

}
