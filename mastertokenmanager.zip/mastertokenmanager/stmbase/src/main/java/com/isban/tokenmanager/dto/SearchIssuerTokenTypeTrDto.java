package com.isban.tokenmanager.dto;

public class SearchIssuerTokenTypeTrDto {

    private String issuerId;
    private String tokenRequestorId;
    private String issuerName;
    private String walletName;
    private String termsAndConditions;
    private Boolean allowActivationSelectionByClient;

    private Integer numDaysValidity; // numero de dias que la tarjeta tiene que
    // ser valido antes de expirar para ser
    // elegible
    private Integer numDaysUsage; // maximo numero de dias que la tarjeta tiene
    // que haber sido usada

    private Integer issuerWalletBlockSize;
    private Integer issuerWalletSitCardSize;
    private Integer issuerWalletProductSize;
    private Integer walletBinSize;
    private Integer issuerWalletActMethodSize;

    private Boolean activeBinRule = true;
    private Boolean activeProductRule = true;
    private Boolean activeSitCardRule = true;
    private Boolean activeBlockRule = true;
    private Boolean activeValidityRule = true;
    private Boolean activeUsageRule = true;

    private WalletDto wallet;

    public SearchIssuerTokenTypeTrDto() {

    }

    public SearchIssuerTokenTypeTrDto(String issuerId, String tokenRequestorId) {
        super();
        this.issuerId = issuerId;
        this.tokenRequestorId = tokenRequestorId;
    }

    public SearchIssuerTokenTypeTrDto(String issuerId, String tokenRequestorId, String termsAndConditions,
            Boolean allowActivationSelectionByClient) {
        super();
        this.issuerId = issuerId;
        this.tokenRequestorId = tokenRequestorId;
        this.termsAndConditions = termsAndConditions;
        this.allowActivationSelectionByClient = allowActivationSelectionByClient;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getIssuerName() {
        return issuerName;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public String getWalletName() {
        return walletName;
    }

    public void setWalletName(String walletName) {
        this.walletName = walletName;
    }

    public String getTermsAndConditions() {
        return termsAndConditions;
    }

    public void setTermsAndConditions(String termsAndConditions) {
        this.termsAndConditions = termsAndConditions;
    }

    public Boolean getAllowActivationSelectionByClient() {
        return allowActivationSelectionByClient;
    }

    public void setAllowActivationSelectionByClient(Boolean allowActivationSelectionByClient) {
        this.allowActivationSelectionByClient = allowActivationSelectionByClient;
    }

    public Integer getIssuerWalletBlockSize() {
        return issuerWalletBlockSize;
    }

    public void setIssuerWalletBlockSize(Integer issuerWalletBlockSize) {
        this.issuerWalletBlockSize = issuerWalletBlockSize;
    }

    public Integer getIssuerWalletSitCardSize() {
        return issuerWalletSitCardSize;
    }

    public void setIssuerWalletSitCardSize(Integer issuerWalletSitCardSize) {
        this.issuerWalletSitCardSize = issuerWalletSitCardSize;
    }

    public Integer getIssuerWalletProductSize() {
        return issuerWalletProductSize;
    }

    public void setIssuerWalletProductSize(Integer issuerWalletProductSize) {
        this.issuerWalletProductSize = issuerWalletProductSize;
    }

    public Integer getWalletBinSize() {
        return walletBinSize;
    }

    public void setWalletBinSize(Integer walletBinSize) {
        this.walletBinSize = walletBinSize;
    }

    public Integer getIssuerWalletActMethodSize() {
        return issuerWalletActMethodSize;
    }

    public void setIssuerWalletActMethodSize(Integer issuerWalletActMethodSize) {
        this.issuerWalletActMethodSize = issuerWalletActMethodSize;
    }

    public WalletDto getWallet() {
        return wallet;
    }

    public void setWallet(WalletDto wallet) {
        this.wallet = wallet;
    }

    public Integer getNumDaysValidity() {
        return numDaysValidity;
    }

    public void setNumDaysValidity(Integer numDaysValidity) {
        this.numDaysValidity = numDaysValidity;
    }

    public Integer getNumDaysUsage() {
        return numDaysUsage;
    }

    public void setNumDaysUsage(Integer numDaysUsage) {
        this.numDaysUsage = numDaysUsage;
    }

    public Boolean getActiveBinRule() {
        return activeBinRule;
    }

    public void setActiveBinRule(Boolean activeBinRule) {
        this.activeBinRule = activeBinRule;
    }

    public Boolean getActiveProductRule() {
        return activeProductRule;
    }

    public void setActiveProductRule(Boolean activeProductRule) {
        this.activeProductRule = activeProductRule;
    }

    public Boolean getActiveSitCardRule() {
        return activeSitCardRule;
    }

    public void setActiveSitCardRule(Boolean activeSitCardRule) {
        this.activeSitCardRule = activeSitCardRule;
    }

    public Boolean getActiveBlockRule() {
        return activeBlockRule;
    }

    public void setActiveBlockRule(Boolean activeBlockRule) {
        this.activeBlockRule = activeBlockRule;
    }

    public Boolean getActiveValidityRule() {
        return activeValidityRule;
    }

    public void setActiveValidityRule(Boolean activeValidityRule) {
        this.activeValidityRule = activeValidityRule;
    }

    public Boolean getActiveUsageRule() {
        return activeUsageRule;
    }

    public void setActiveUsageRule(Boolean activeUsageRule) {
        this.activeUsageRule = activeUsageRule;
    }

}
