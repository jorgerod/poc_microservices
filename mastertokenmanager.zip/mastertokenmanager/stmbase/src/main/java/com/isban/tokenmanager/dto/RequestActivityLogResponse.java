package com.isban.tokenmanager.dto;

public class RequestActivityLogResponse {

    private String ticketStm = null;
    private Boolean res = null;

    public RequestActivityLogResponse() {

    }

    public RequestActivityLogResponse(String ticketStm, Boolean res) {
        this.ticketStm = ticketStm;
        this.res = res;
    }

    public String getTicketStm() {
        return ticketStm;
    }

    public void setTicketStm(String ticketStm) {
        this.ticketStm = ticketStm;
    }

    public Boolean getRes() {
        return res;
    }

    public void setRes(Boolean res) {
        this.res = res;
    }

}
