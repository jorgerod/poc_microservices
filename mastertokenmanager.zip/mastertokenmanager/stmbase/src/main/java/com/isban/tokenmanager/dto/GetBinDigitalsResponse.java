package com.isban.tokenmanager.dto;

import java.util.List;

public class GetBinDigitalsResponse extends ResponseBase {

    private List<BinDigitalDto> binDigitals;

    private List<TspDto> tsps;

    public GetBinDigitalsResponse() {
    }

    public GetBinDigitalsResponse(String code, String description) {
        super(code, description);
    }

    public List<BinDigitalDto> getBinDigitals() {
        return binDigitals;
    }

    public void setBinDigitals(List<BinDigitalDto> binDigitals) {
        this.binDigitals = binDigitals;
    }

    public List<TspDto> getTsps() {
        return tsps;
    }

    public void setTsps(List<TspDto> tsps) {
        this.tsps = tsps;
    }

    @Override
    public String toString() {
        return "GetBinDigitalsResponse [binDigitals=" + binDigitals + ", tsps=" + tsps + "]";
    }

}
