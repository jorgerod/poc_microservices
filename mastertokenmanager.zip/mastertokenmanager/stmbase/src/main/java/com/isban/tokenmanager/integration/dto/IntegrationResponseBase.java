package com.isban.tokenmanager.integration.dto;

import com.isban.tokenmanager.dto.ResponseBase;

/**
 * Base class for the rest response methods.
 * @author realsec
 */
public class IntegrationResponseBase<T> {
    private String codeResponse;
    private String desResponse;
    private T data;

    public IntegrationResponseBase() {
        super();
    }

    /**
     * Constructor.
     *
     * @param code
     *            String param with the code state.
     * @param description
     *            String param with the response code description.
     */
    public IntegrationResponseBase(String code, String description) {
        super();
        codeResponse = code;
        desResponse = description;
    }
    
    public IntegrationResponseBase(ResponseBase responseBase) {
        super();
        setResponse(responseBase);
    }

    public void setResponse(ResponseBase responseBase){
        if(responseBase == null){ return; }
        codeResponse = responseBase.getCode();
        desResponse = responseBase.getDescription();
    }
    
    public String getCodeResponse() {
        return codeResponse;
    }

    public void setCodeResponse(String c) {
        codeResponse = c;
    }

    public String getDesResponse() {
        return desResponse;
    }

    public void setDesResponse(String r) {
        desResponse = r;
    }

    public T getData() {
        return data;
    }

    public void setData(T d) {
        data = d;
    }
}
