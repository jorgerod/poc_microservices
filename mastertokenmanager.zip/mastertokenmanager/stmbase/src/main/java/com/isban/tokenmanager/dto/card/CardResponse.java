/**
 *
 */
package com.isban.tokenmanager.dto.card;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author realsec
 */
@JsonInclude(Include.NON_NULL)
public class CardResponse {
    private String pan;
    private String tyc;
    private String cardArt;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyMM")
    private Date expirationdate;
    private String pvv;
    private String ticketref;
    private Boolean isregister;

    private String typeBin;
    private String productName;
    private String tokenStatus;
    private String tokenReferenceId;

    /**
     * @return the pan
     */
    public String getItem() {
        return pan;
    }

    /**
     * @param pan
     *            the pan to set
     */
    public void setPan(String pan) {
        this.pan = pan;
    }

    /**
     * @return the tyc
     */
    public String getTyc() {
        return tyc;
    }

    /**
     * @param tyc
     *            the tyc to set
     */
    public void setTyc(String tyc) {
        this.tyc = tyc;
    }

    /**
     * @return the cardArt
     */
    public String getCardArt() {
        return cardArt;
    }

    /**
     * @param cardArt
     *            the cardArt to set
     */
    public void setCardArt(String cardArt) {
        this.cardArt = cardArt;
    }

    public Date getExpirationdate() {
        return expirationdate;
    }

    public void setExpirationdate(Date expirationdate) {
        this.expirationdate = expirationdate;
    }

    public String getPvv() {
        return pvv;
    }

    public void setPvv(String pvv) {
        this.pvv = pvv;
    }

    public String getTicketref() {
        return ticketref;
    }

    public void setTicketref(String ticketref) {
        this.ticketref = ticketref;
    }

    public Boolean getIsregister() {
        return isregister;
    }

    public void setIsregister(Boolean isregister) {
        this.isregister = isregister;
    }

    public String getTypeBin() {
        return typeBin;
    }

    public void setTypeBin(String typeBin) {
        this.typeBin = typeBin;
    }

    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    public String getTokenStatus() {
        return tokenStatus;
    }

    public void setTokenStatus(String tokenStatus) {
        this.tokenStatus = tokenStatus;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

}
