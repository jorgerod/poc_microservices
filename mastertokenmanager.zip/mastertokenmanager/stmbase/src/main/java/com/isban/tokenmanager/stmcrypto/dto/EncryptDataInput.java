package com.isban.tokenmanager.stmcrypto.dto;

public class EncryptDataInput {

    /*
     * Properties
     */
    private KeyData keyData;
    
    /* 
     * Allowed values for encryption mode:
     * '0': ECB
     * '1': CBC (IV Required)
     * '2': CFB8 (IV Required)
     * '3': CFB64 (IV Required)
     */
    private String encryptionMode;

    /*
     * Allowed values for Input-Output Format
     * '0': Binary
     * '1': Hex-Encoded Binary
     * Output Format = Input Format
     */
    private String inputFormat = "1";
        
    /* 
     * Allowed values for padding method:
     * 0: No padding
     * 1: PKCS#5
     */
    private String paddingMethod;    
    
    private String iv;
    private String message;
    
    /*
     * Getters and setters
     */
    public KeyData getKeyData() {
        return keyData;
    }
    public void setKeyData(KeyData keyData) {
        this.keyData = keyData;
    }

    public String getEncryptionMode() {
        return encryptionMode;
    }
    public void setEncryptionMode(String encryptionMode) {
        this.encryptionMode = encryptionMode;
    }

    public String getInputFormat() {
        return inputFormat;
    }
    public void setInputFormat(String inputFormat) {
        this.inputFormat = inputFormat;
    }
    
    public String getPaddingMethod() {
        return paddingMethod;
    }
    public void setPaddingMethod(String paddingMethod) {
        this.paddingMethod = paddingMethod;
    }

    public String getIv() {
        return iv;
    }
    public void setIv(String iv) {
        this.iv = iv;
    }

    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
}
