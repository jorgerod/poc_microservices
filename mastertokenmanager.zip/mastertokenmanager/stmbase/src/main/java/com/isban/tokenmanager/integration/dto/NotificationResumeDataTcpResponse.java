package com.isban.tokenmanager.integration.dto;

public class NotificationResumeDataTcpResponse extends TcpCommonDataResponse {

    public NotificationResumeDataTcpResponse() {
        super();
    }

    public NotificationResumeDataTcpResponse(NotificationResumeDataTcpRequest request) {
        super(request.getOperationId(), request.getOperationDateTime());
    }

    @Override
    public String toString() {
        return "NotificationResumeDataTcpResponse [getOperationId()=" + getOperationId() + ", getOperationDate()="
                + getOperationDateTime() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
                + ", hashCode()=" + hashCode() + "]";
    }
}
