package com.isban.tokenmanager.integration.batch;

import java.util.List;

import com.isban.tokenmanager.dto.ModelBaseDto;

public class BatchRemoteRequestBase<T> extends ModelBaseDto {
    public List<T> data;
    //
    public String name;
    public int index = 0;
    public int sz = 1;
    //
    public String issuerid;
    
    public List<T> getData() {
        return data;
    }
    public void setData(List<T> d) {
        data = d;
    }
    public String getName() {
        return name;
    }
    public void setName(String n) {
        name = n;
    }
    public int getIndex() {
        return index;
    }
    public void setIndex(int i) {
        index = i;
    }
    public int getSz() {
        return sz;
    }
    public void setSz(int s) {
        sz = s;
    }
    public String getIssuerid() {
        return issuerid;
    }
    public void setIssuerid(String ii) {
        issuerid = ii;
    }
}
