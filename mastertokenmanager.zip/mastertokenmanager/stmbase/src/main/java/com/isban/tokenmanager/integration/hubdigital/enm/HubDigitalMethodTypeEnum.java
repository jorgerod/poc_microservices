package com.isban.tokenmanager.integration.hubdigital.enm;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum HubDigitalMethodTypeEnum {
    
    OTP_SMS("otp-sms"), 
    OTP_EMAIL("otp-email"),
    CALL_CENTER("call center"),
    URL("url");

    private static Map<String, HubDigitalMethodTypeEnum> FORMAT_MAP = Stream.of(HubDigitalMethodTypeEnum.values())
            .collect(Collectors.toMap(s -> s.formatted, Function.identity()));
    
    private static Map<String, HubDigitalMethodTypeEnum> KEY_MAP = Stream.of(HubDigitalMethodTypeEnum.values())
            .collect(Collectors.toMap(s -> s.name(), Function.identity()));

    private final String formatted;

    HubDigitalMethodTypeEnum(String formatted) {
        this.formatted = formatted;
    }
    
    public String getFormatted() {
        return formatted;
    }

    @JsonCreator // This is the factory method and must be static
    public static HubDigitalMethodTypeEnum fromString(String value) {
        HubDigitalMethodTypeEnum HubDigitalMethodTypeEnum = FORMAT_MAP.get(value) != null ? FORMAT_MAP.get(value) : KEY_MAP.get(value);
        if (HubDigitalMethodTypeEnum == null) {
            throw new IllegalArgumentException(value + " has no corresponding value");
        }
        return HubDigitalMethodTypeEnum;
    }
}
