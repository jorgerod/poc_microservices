package com.isban.tokenmanager.service.security;

public interface CryptographicService {
    public String describeSecuritySystem();
    
    public byte[] createRandomBytes( int length );
    
    public String bytesToBase64( byte[] bytes );
    public byte[] base64ToBytes( String base64 );
    public String stringToBase64( String value );
    public String base64ToString( String base64 );
    
    public String bytesToBase58( byte[] bytes );
    public byte[] base58ToBytes( String base58 );
    public String stringToBase58( String value );
    public String base58ToString( String base58 );
    public String createBase58RandomId( int length );
    
    public String bytesToHex( byte[] bytes );
    public String bytesToHexUpperCase( byte[] bytes );
    public byte[] hexToBytes( String hex );
    public String stringToHex( String value );
    public String stringToHexUpperCase( String value );
    public String hexToString( String hex );
  
}
