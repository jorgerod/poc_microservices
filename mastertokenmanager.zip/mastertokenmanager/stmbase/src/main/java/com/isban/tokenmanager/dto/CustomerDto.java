package com.isban.tokenmanager.dto;

import java.util.Date;


public class CustomerDto {

    private String id;
    private String clientId;

    // OPENBANK
    private String doc;
    private String typedoc;

    private Date dateStart;
    private String name;
    private String surname;
    private String customerExt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getDoc() {
        return doc;
    }

    public void setDoc(String doc) {
        this.doc = doc;
    }

    public String getTypedoc() {
        return typedoc;
    }

    public void setTypedoc(String typedoc) {
        this.typedoc = typedoc;
    }

    public Date getDateStart() {
        return dateStart;
    }

    public void setDateStart(Date dateStart) {
        this.dateStart = dateStart;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getCustomerExt() {
        return customerExt;
    }

    public void setCustomerExt(String customerExt) {
        this.customerExt = customerExt;
    }

}
