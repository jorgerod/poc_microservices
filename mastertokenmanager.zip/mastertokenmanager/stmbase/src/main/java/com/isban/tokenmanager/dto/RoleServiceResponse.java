package com.isban.tokenmanager.dto;

import java.util.List;

public class RoleServiceResponse extends ResponseBase {

    private List<RoleServiceDto> roleServices;

    public RoleServiceResponse(String code, String description) {
        super(code, description);
    }

    public RoleServiceResponse() {
    }

    public List<RoleServiceDto> getRoleServices() {
        return roleServices;
    }

    public void setRoleServices(List<RoleServiceDto> roleServices) {
        this.roleServices = roleServices;
    }
}
