package com.isban.tokenmanager.integration.pmas;

public class ConfirmationReversalHttpResponse {

}
