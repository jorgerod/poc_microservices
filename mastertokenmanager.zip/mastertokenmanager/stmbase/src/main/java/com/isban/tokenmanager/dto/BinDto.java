package com.isban.tokenmanager.dto;

import java.math.BigInteger;

public class BinDto extends LifeTimeDto {
    private String binId;
    private String tokenTypeId;
    private String issuerId;
    private String maxPan;
    private String minPan;
    private String typeBinId;
    private String brandBinId;

    public BinDto() {
    }

    public BinDto(String issuerId, String tokenTypeId, String binId, BigInteger minPan, BigInteger maxPan,
            String typeBinId, String brandBinId) {
        this.issuerId = issuerId;
        this.tokenTypeId = tokenTypeId;
        this.binId = binId;
        this.maxPan = maxPan + "";
        this.minPan = minPan + "";
        this.typeBinId = typeBinId;
        this.brandBinId = brandBinId;

    }

    public String getBinId() {
        return binId;
    }

    public void setBinId(String binId) {
        this.binId = binId;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getMaxPan() {
        return maxPan;
    }

    public void setMaxPan(String maxPan) {
        this.maxPan = maxPan;
    }

    public String getMinPan() {
        return minPan;
    }

    public void setMinPan(String minPan) {
        this.minPan = minPan;
    }

    public String getTypeBinId() {
        return typeBinId;
    }

    public void setTypeBinId(String typeBinId) {
        this.typeBinId = typeBinId;
    }

    public String getBrandBinId() {
        return brandBinId;
    }

    public void setBrandBinId(String brandBinId) {
        this.brandBinId = brandBinId;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    @Override
    public String toString() {
        return "BinDto [binId=" + binId + ", issuerId=" + issuerId + ", maxPan=" + maxPan + ", minPan=" + minPan
                + ", typeBinId=" + typeBinId + ", brandBinId=" + brandBinId + "]";
    }

}
