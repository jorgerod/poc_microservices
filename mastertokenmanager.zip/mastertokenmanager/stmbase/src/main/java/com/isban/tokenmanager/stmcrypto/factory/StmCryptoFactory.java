package com.isban.tokenmanager.stmcrypto.factory;

import com.isban.tokenmanager.dto.FlowAndMediaResponse;
import com.isban.tokenmanager.integration.hubdigital.EligibitityHttpRequest;
import com.isban.tokenmanager.integration.hubdigital.HubdigitalCommonRequest;
import com.isban.tokenmanager.stmcrypto.dto.DecryptDataInput;
import com.isban.tokenmanager.stmcrypto.dto.EncryptDataInput;
import com.isban.tokenmanager.stmcrypto.dto.GenerateMacInput;

public interface StmCryptoFactory {

    GenerateMacInput createMac(EligibitityHttpRequest request);

    EncryptDataInput create(EligibitityHttpRequest request);
    
    DecryptDataInput createDecryptInput(HubdigitalCommonRequest request);

    EncryptDataInput createEncryptInput(EligibitityHttpRequest request, FlowAndMediaResponse flowAndMediaResponse);

}
