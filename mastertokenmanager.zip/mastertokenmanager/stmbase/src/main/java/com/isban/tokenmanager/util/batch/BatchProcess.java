package com.isban.tokenmanager.util.batch;

import java.io.IOException;
import java.nio.file.Path;

import com.isban.tokenmanager.dto.IssuerDto;
import com.isban.tokenmanager.dto.ResponseEvent;

public interface BatchProcess {
    public ResponseEvent processFile(IssuerDto issuerDto, Path file) throws IOException;
}
