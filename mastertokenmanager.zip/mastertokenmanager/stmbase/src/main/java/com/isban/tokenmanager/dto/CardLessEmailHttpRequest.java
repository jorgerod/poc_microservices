package com.isban.tokenmanager.dto;

public class CardLessEmailHttpRequest extends CardLessSMSHttpRequestBase {
    
    CardLessEmailRecipient recipient;

    public CardLessEmailRecipient getRecipient() {
        return recipient;
    }

    public void setRecipient(CardLessEmailRecipient recipient) {
        this.recipient = recipient;
    }

    @Override
    public String toString() {
        
        StringBuilder builder = new StringBuilder();
        builder.append("CardLessEmailHttpRequest [recipient=");
        builder.append(recipient);
        builder.append("]");
        return builder.toString();
    }
    
    
    
}
