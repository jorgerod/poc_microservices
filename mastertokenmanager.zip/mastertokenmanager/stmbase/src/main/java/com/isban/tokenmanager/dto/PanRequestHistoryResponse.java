package com.isban.tokenmanager.dto;

import java.util.List;

public class PanRequestHistoryResponse extends ResponseBase {

    private List<TokenHistoryDto> panRequestHistory;

    public PanRequestHistoryResponse(String code, String description) {
        super(code, description);
    }

    public PanRequestHistoryResponse() {
    }

    public List<TokenHistoryDto> getTokenHistory() {
        return panRequestHistory;
    }

    public void setPanRequestHistory(List<TokenHistoryDto> panRequestHistory) {
        this.panRequestHistory = panRequestHistory;
    }
}
