package com.isban.tokenmanager.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import com.isban.tokenmanager.util.Constants;

@MappedSuperclass
public class TspBase extends LifeTime {

    private String shortDescription = null;
    private String description = null;

    @Column(name = "NAME_TSP", length = 10)
    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    @Column(name = "DESC_TSP", length = Constants.DESCRIPTION_LENGTH)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
