package com.isban.tokenmanager.util.metrics;

import org.springframework.boot.actuate.metrics.CounterService;
import org.springframework.boot.actuate.metrics.GaugeService;

import com.isban.tokenmanager.dto.ResponseEvent;
import com.isban.tokenmanager.model.enm.ResponseStateEnum;

public class ResponseEventMetricWatchWrapper<T extends ResponseEvent>  extends MetricWatchWrapperBase<T> {
    public ResponseEventMetricWatchWrapper(CounterService cS, GaugeService gS, String s) {
        super( cS, gS, s );
    }

    @Override
    public String selectStatus(ResponseEvent wrapped) {
        String ret = getKoStatus();
        if( wrapped == null ){ return ret; }
        ResponseStateEnum responseState = wrapped.getResponseState();
        if( responseState == null ){ return ret; }
        if( !ResponseStateEnum.OK.equals(responseState) ){ return ret; }
        
        ret = getOkStatus();
        return ret;
    }
}
