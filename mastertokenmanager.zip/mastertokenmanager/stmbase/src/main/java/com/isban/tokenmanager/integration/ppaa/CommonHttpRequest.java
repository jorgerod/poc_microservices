package com.isban.tokenmanager.integration.ppaa;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class CommonHttpRequest {
    
    private String contract;
    private String amount;
    private String currency;
    
    @ApiModelProperty(value = "Partenon Contract Number. (Numeric format)", required = true)
    @Size(max = 20)
    public String getContract() {
        return contract;
    }
    
    public void setContract(String contract) {
        this.contract = contract;
    }
    
    @ApiModelProperty(value = "Amount to withdrawal. (Numeric format)", required = true)
    @Size(max = 12)
    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    @ApiModelProperty(value = "Currency of the amount to withdrawal. (ISO 4217 format)", required = true)
    @Size(max = 3)
    public String getCurrency() {
        return currency;
    }
    
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    

}