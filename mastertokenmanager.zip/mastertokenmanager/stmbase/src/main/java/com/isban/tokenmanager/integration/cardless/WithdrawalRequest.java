package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class WithdrawalRequest {

    private String opTime;
    private String contract;
    private String tokenKey;
    private String amount;
    private String currency;

    @ApiModelProperty(value = "Date and time of operation", required = true)
    @Pattern(regexp = "^(-?(?:[1-9][0-9]*)?[0-9]{4})-(1[0-2]|0[1-9])-(3[01]|0[1-9]|[12][0-9])T(2[0-3]|[01][0-9]):([0-5][0-9]):([0-5][0-9])(\\.[0-9]+)?(Z|[+-](?:2[0-3]|[01][0-9]):[0-5][0-9])?$")
    @Size(max = 19)
    public String getOpTime() {
        return opTime;
    }

    public void setOpTime(String opTime) {
        this.opTime = opTime;
    }

    @ApiModelProperty(value = "Partenon contract number", required = false)
    @Pattern(regexp = "\\d+")
    @Size(max = 18)
    public String getContract() {
        return contract;
    }

    public void setContract(String contract) {
        this.contract = contract;
    }

    @ApiModelProperty(value = "sTM token", required = true)
    @Size(max = 16)
    public String getTokenKey() {
        return tokenKey;
    }

    public void setTokenKey(String tokenKey) {
        this.tokenKey = tokenKey;
    }

    @ApiModelProperty(value = "Amount to withdrawal", required = false)
    @Size(max = 12)
    @Min(0)
    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    @ApiModelProperty(value = "Currency of the amount to withdrawal. (ISO 4217)", required = false)
    @Size(max = 3)
    @Min(0)
    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}

