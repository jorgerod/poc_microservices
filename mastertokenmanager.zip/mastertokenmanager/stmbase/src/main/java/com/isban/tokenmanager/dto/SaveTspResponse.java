package com.isban.tokenmanager.dto;

public class SaveTspResponse extends ResponseBase {

    private TspDto TspDto;

    public SaveTspResponse() {
    }

    public SaveTspResponse(String code, String description) {
        super(code, description);
    }

    public TspDto getTspDto() {
        return TspDto;
    }

    public void setTspDto(TspDto tspDto) {
        TspDto = tspDto;
    }

    @Override
    public String toString() {
        return "SaveTspResponse [TspDto=" + TspDto + "]";
    }

}
