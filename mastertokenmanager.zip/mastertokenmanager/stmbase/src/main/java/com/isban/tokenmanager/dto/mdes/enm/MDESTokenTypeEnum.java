package com.isban.tokenmanager.dto.mdes.enm;

public enum MDESTokenTypeEnum {
    EMBEDDED_SE, 
    CLOUD, 
    STATIC;
}
