package com.isban.tokenmanager.dto;

import java.io.Serializable;

public class SearchFilterDto extends ModelBaseDto implements Serializable {

    private static final long serialVersionUID = 1L;
    private String item;
    private String accountNumber;
    private String clientId;
    private String userId;

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

}
