package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class NotificationTokenHttpRequest extends CardlessCommonHttpRequest {

    @ApiModelProperty(notes = "Branch Office that asks the change", required = true)
    @Size(max = 4)
    private String branchOffice;

    @ApiModelProperty(notes = "Unique Id of the token", required = true)
    @Size(max = 32)
    private String tokenReferenceId;

    @ApiModelProperty(notes = "User Id who asks the change", required = true)
    @Size(max = 32)
    private String user;

    @ApiModelProperty(notes = "Comment associates to the change", required = false)
    @Size(max = 30)
    private String comment;
    

    public String getBranchOffice() {
        return branchOffice;
    }

    public void setBranchOffice(String branchOffice) {
        this.branchOffice = branchOffice;
    }

    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

}
