package com.isban.tokenmanager.dto.enm;

public enum UnitTimeEnum {
    
    MILISECONDS("ML"),
    SECONDS("SS"),
    MINUTES("MM"),
    HOURS("HH"),
    DAYS("DD"),
    YEARS("YY");
    
    private String code;
    
    UnitTimeEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
    
    public static UnitTimeEnum get(String n) {
        for (UnitTimeEnum c : values()) {
          if (c.code.equals(n)) {
            return c;
          }
        }
        // either throw the IAE or return null, your choice.
        throw new IllegalArgumentException(String.valueOf(n));
    }
}
