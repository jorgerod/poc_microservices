package com.isban.tokenmanager.dto;

public class SaveIssuerRequest extends ProfileRequest {

    private IssuerDto issuerDto;

    public IssuerDto getIssuerDto() {
        return issuerDto;
    }

    public void setIssuerDto(IssuerDto issuerDto) {
        this.issuerDto = issuerDto;
    }
}
