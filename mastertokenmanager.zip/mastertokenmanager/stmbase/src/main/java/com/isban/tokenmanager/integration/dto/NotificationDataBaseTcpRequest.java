package com.isban.tokenmanager.integration.dto;

public class NotificationDataBaseTcpRequest extends TcpCommonDataRequest {
    private String tokenReferenceId;
    private String ditem;

    public NotificationDataBaseTcpRequest() {
        super();
    }

    public NotificationDataBaseTcpRequest(TcpCommonDataRequest requestBase,
                                          String tokenReferenceId, String ditem) {
        super(requestBase.getOperationId(), requestBase.getOperationDateTime(), requestBase.getIssuerId(), 
                requestBase.getTokenTypeId(), requestBase.getTokenRequestorId(),
                requestBase.getItem(), requestBase.getExpirationDatePan(), requestBase.getDataEntryMode());
        this.tokenReferenceId = tokenReferenceId;
        this.ditem = ditem;
    }

    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    @Override
    public String toString() {
        return "NotificationDataBaseTcpRequest [ticketRef=," + tokenReferenceId
                + ", dpan=" + ditem+ ", getOperationId()=" + getOperationId()
                + ", getOperationDate()=" + getOperationDateTime()
                + ", getIssuerId()=" + getIssuerId() + ", getTokenRequestorId()="
                + getTokenRequestorId() + ", getItem()=" + getItem()
                + ", getExpirationDatePan()=" + getExpirationDatePan()
                + ", getDataEntryMode()=" + getDataEntryMode()
                + ", toString()=" + super.toString() + ", getClass()="
                + getClass() + ", hashCode()=" + hashCode() + "]";
    }
}
