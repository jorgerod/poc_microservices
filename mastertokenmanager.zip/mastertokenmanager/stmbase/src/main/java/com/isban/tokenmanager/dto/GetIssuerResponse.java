package com.isban.tokenmanager.dto;

import com.isban.tokenmanager.model.enm.ResponseStateEnum;

public class GetIssuerResponse extends ResponseBase {
    private IssuerDto issuer;

    public GetIssuerResponse(){}

    public GetIssuerResponse(String code, String description) {
        super(code, description);
    }
    
    public GetIssuerResponse(ResponseStateEnum responseState) {
        super(responseState);
    }

    public IssuerDto getIssuer() {
        return issuer;
    }
    public void setIssuer(IssuerDto issuer) {
        this.issuer = issuer;
    }

    @Override
    public String toString() {
        return "GetIssuerResponse [issuers=" + issuer + "]";
    }
}
