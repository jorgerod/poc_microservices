//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.7 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2016.02.02 a las 10:40:55 AM CET 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.isban.com/cms/ws/model", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.isban.cms.ws.model;
