package com.isban.tokenmanager.dto;

public class BlockDto extends LifeTimeDto {

    private String blockId;
    private String description;

    public BlockDto() {
        
    }
    
    public BlockDto(String issuerId, String tokenTypeId, String blockId, String description) {
        this.issuerId = issuerId;
        this.tokenTypeId = tokenTypeId;
        this.blockId = blockId;
        this.description = description;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    public String getBlockId() {
        return blockId;
    }

    public void setBlockId(String blockId) {
        this.blockId = blockId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "IssuerBlockDto [blockId=" + blockId + ", description=" + description + "]";
    }

}
