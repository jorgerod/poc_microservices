package com.isban.tokenmanager.dto;



public class PaymentCancellationResponse extends ResponseBase {

    public PaymentCancellationResponse() {
        super();
    }

    public PaymentCancellationResponse(String code, String description) {
        super(code, description);
    }

    @Override
    public String toString() {
        return "PaymentCancellationResponse [getCode()=" + getCode()
                + ", getDescription()=" + getDescription() + "]";
    }
}
