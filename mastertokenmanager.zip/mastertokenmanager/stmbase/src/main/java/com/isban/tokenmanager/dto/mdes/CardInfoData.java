package com.isban.tokenmanager.dto.mdes;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isban.tokenmanager.dto.mdes.enm.ItemSourceMdesEnum;

public class CardInfoData {

    private String accountNumber;
    private String expiryMonth;
    private String expiryYear;
    private ItemSourceMdesEnum source;
    private String cardholderName;
    private String securityCode;
    private String dataValidUntilTimestamp;
    private BillingAddress billingAddress = new BillingAddress();
    private CardholderData cardholderData = new CardholderData();
    @JsonIgnore
    private String panUniqueReference;

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getExpiryMonth() {
        return expiryMonth;
    }

    public void setExpiryMonth(String expiryMonth) {
        this.expiryMonth = expiryMonth;
    }

    public String getExpiryYear() {
        return expiryYear;
    }

    public void setExpiryYear(String expiryYear) {
        this.expiryYear = expiryYear;
    }

    public ItemSourceMdesEnum getSource() {
        return source;
    }

    public void setSource(ItemSourceMdesEnum source) {
        this.source = source;
    }

    public String getCardholderName() {
        return cardholderName;
    }

    public void setCardholderName(String cardholderName) {
        this.cardholderName = cardholderName;
    }

    public String getSecurityCode() {
        return securityCode;
    }

    public void setSecurityCode(String securityCode) {
        this.securityCode = securityCode;
    }

    public CardholderData getCardholderData() {
        return cardholderData;
    }

    public void setCardholderData(CardholderData cardholderData) {
        this.cardholderData = cardholderData;
    }

    public String getDataValidUntilTimestamp() {
        return dataValidUntilTimestamp;
    }

    public void setDataValidUntilTimestamp(String dataValidUntilTimestamp) {
        this.dataValidUntilTimestamp = dataValidUntilTimestamp;
    }

    public BillingAddress getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(BillingAddress billingAddress) {
        this.billingAddress = billingAddress;
    }

    public String getPanUniqueReference() {
        return panUniqueReference;
    }

    public void setPanUniqueReference(String panUniqueReference) {
        this.panUniqueReference = panUniqueReference;
    }

}
