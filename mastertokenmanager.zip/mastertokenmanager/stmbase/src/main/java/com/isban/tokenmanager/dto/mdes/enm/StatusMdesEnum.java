package com.isban.tokenmanager.dto.mdes.enm;

public enum StatusMdesEnum {
    
    INACTIVE, 
    ACTIVE, 
    SUSPENDED,
    UNSUSPENDED,
    DEACTIVATED;
}
