package com.isban.tokenmanager.dto;

import java.util.ArrayList;
import java.util.List;

import com.isban.tokenmanager.model.enm.ResponseStateEnum;

public class ResponseEvent {

    private ResponseStateEnum responseState;
    private List<EventDto> eventsDto = new ArrayList<>();

    public ResponseEvent(ResponseStateEnum responseStateEnum) {
        this.responseState = responseStateEnum;
    }

    public ResponseStateEnum getResponseState() {
        return responseState;
    }

    public void setResponseState(ResponseStateEnum responseState) {
        this.responseState = responseState;
    }

    public List<EventDto> getEventsDto() {
        return eventsDto;
    }

    public void setEventsDto(List<EventDto> alertsDto) {
        this.eventsDto = alertsDto;
    }

}
