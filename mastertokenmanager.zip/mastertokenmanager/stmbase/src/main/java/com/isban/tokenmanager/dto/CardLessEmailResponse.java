package com.isban.tokenmanager.dto;

public class CardLessEmailResponse extends CardLessResponseBase{
    
    
}
