package com.isban.tokenmanager.integration.dto;

public class NotificationCreatedTokenDataTcpRequest extends NotificationDataBaseTcpRequest {

    private String expirationDateDpan;
    private String tokenType;
    private String deviceType;
    private String deviceLanguageCode;
    private String deviceName;
    private String termsAndConditionsData;
    private String termsAndConditionsDateAndTime;

    public NotificationCreatedTokenDataTcpRequest() {
        super();
    }

    public NotificationCreatedTokenDataTcpRequest(TcpCommonDataRequest requestBase, String ticketRef, String ditem,
            String dateexpirationdpan, String tokenType, String deviceType, String deviceLanguageCode,
            String deviceName, String termsAndConditionsData, String termsAndConditionsDateAndTime) {
        super(requestBase, ticketRef, ditem);
        this.expirationDateDpan = dateexpirationdpan;
        this.tokenType = tokenType;
        this.deviceType = deviceType;
        this.deviceLanguageCode = deviceLanguageCode;
        this.deviceName = deviceName;
        this.termsAndConditionsData = termsAndConditionsData;
        this.termsAndConditionsDateAndTime = termsAndConditionsDateAndTime;
    }

    public String getExpirationDateDpan() {
        return expirationDateDpan;
    }

    public void setExpirationDateDpan(String expirationDateDpan) {
        this.expirationDateDpan = expirationDateDpan;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceLanguageCode() {
        return deviceLanguageCode;
    }

    public void setDeviceLanguageCode(String deviceLanguageCode) {
        this.deviceLanguageCode = deviceLanguageCode;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getTermsAndConditionsData() {
        return termsAndConditionsData;
    }

    public void setTermsAndConditionsData(String termsAndConditionsData) {
        this.termsAndConditionsData = termsAndConditionsData;
    }

    public String getTermsAndConditionsDateAndTime() {
        return termsAndConditionsDateAndTime;
    }

    public void setTermsAndConditionsDateAndTime(String termsAndConditionsDateAndTime) {
        this.termsAndConditionsDateAndTime = termsAndConditionsDateAndTime;
    }

    @Override
    public String toString() {
        return "NotificationCreatedTokenDataTcpRequest [expirationDateDpan=" + expirationDateDpan + ", tokenType="
                + tokenType + ", deviceType=" + deviceType + ", deviceLanguageCode=" + deviceLanguageCode
                + ", deviceName=" + deviceName + ", termsAndConditionsData=" + termsAndConditionsData
                + ", termsAndConditionsDateAndTime=" + termsAndConditionsDateAndTime + ", getTicketRef()="
                + getTokenReferenceId() + ", getDitem()=" + getDitem() + ", toString()=" + super.toString()
                + ", getOperationId()=" + getOperationId() + ", getOperationDate()=" + getOperationDateTime()
                + ", getIssuerId()=" + getIssuerId() + ", getTokenRequestorId()=" + getTokenRequestorId() + ", getItem()=" + getItem()
                + ", getExpirationDatePan()=" + getExpirationDatePan() + ", getDataEntryMode()=" + getDataEntryMode()
                + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
    }
}
