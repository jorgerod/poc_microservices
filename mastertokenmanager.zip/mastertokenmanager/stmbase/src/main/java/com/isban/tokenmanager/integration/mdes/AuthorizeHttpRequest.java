package com.isban.tokenmanager.integration.mdes;

import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.isban.tokenmanager.dto.mdes.CardInfoData;
import com.isban.tokenmanager.dto.mdes.CardInfoDto;
import com.isban.tokenmanager.dto.mdes.DecisioningInfoDto;
import com.isban.tokenmanager.dto.mdes.DeviceInfoDto;
import com.isban.tokenmanager.dto.mdes.enm.MDESServiceEnum;
import com.isban.tokenmanager.dto.mdes.enm.MDESTokenTypeEnum;

import io.swagger.annotations.ApiModelProperty;

public class AuthorizeHttpRequest extends MdesApiCommonRequest {

    @ApiModelProperty(required = true)
    @NotNull
    private List<MDESServiceEnum> services = null;

    @ApiModelProperty(required = true)
    @NotNull
    private CardInfoDto cardInfo = null;

    @ApiModelProperty(required = true)
    private CardInfoData cardInfoData = null;

    @ApiModelProperty(required = true)
    @NotNull
    @Size(max = 14)
    private String correlationId = "";

    @ApiModelProperty(required = true)
    @NotNull
    @Size(max = 11)
    private String tokenRequestorId = "";

    @Size(max = 3)
    private String walletId = null;

    @Size(max = 48)
    private String paymentAppInstanceId = null;

    @Size(max = 64)
    private String accountIdHash = null;

    @Size(max = 32)
    private String mobileNumberSuffix = null;

    private DeviceInfoDto deviceInfo = null;

    private DecisioningInfoDto walletProviderDecisioningInfo = null;

    @Min(0)
    private String activeTokenCount = null;

    @ApiModelProperty(required = true)
    @NotNull
    private MDESTokenTypeEnum tokenType = null;

    public List<MDESServiceEnum> getServices() {
        return services;
    }

    public void setServices(List<MDESServiceEnum> services) {
        this.services = services;
    }

    public CardInfoDto getCardInfo() {
        return cardInfo;
    }

    public void setCardInfo(CardInfoDto cardInfo) {
        this.cardInfo = cardInfo;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getWalletId() {
        return walletId;
    }

    public void setWalletId(String walletId) {
        this.walletId = walletId;
    }

    public String getPaymentAppInstanceId() {
        return paymentAppInstanceId;
    }

    public void setPaymentAppInstanceId(String paymentAppInstanceId) {
        this.paymentAppInstanceId = paymentAppInstanceId;
    }

    public String getAccountIdHash() {
        return accountIdHash;
    }

    public void setAccountIdHash(String accountIdHash) {
        this.accountIdHash = accountIdHash;
    }

    public String getMobileNumberSuffix() {
        return mobileNumberSuffix;
    }

    public void setMobileNumberSuffix(String mobileNumberSuffix) {
        this.mobileNumberSuffix = mobileNumberSuffix;
    }

    public DeviceInfoDto getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(DeviceInfoDto deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    public DecisioningInfoDto getWalletProviderDecisioningInfo() {
        return walletProviderDecisioningInfo;
    }

    public void setWalletProviderDecisioningInfo(DecisioningInfoDto walletProviderDecisioningInfo) {
        this.walletProviderDecisioningInfo = walletProviderDecisioningInfo;
    }

    public String getActiveTokenCount() {
        return activeTokenCount;
    }

    public void setActiveTokenCount(String activeTokenCount) {
        this.activeTokenCount = activeTokenCount;
    }

    public MDESTokenTypeEnum getTokenType() {
        return tokenType;
    }

    public void setTokenType(MDESTokenTypeEnum tokenType) {
        this.tokenType = tokenType;
    }

    public CardInfoData getCardInfoData() {
        return cardInfoData;
    }

    public void setCardInfoData(CardInfoData cardInfoData) {
        this.cardInfoData = cardInfoData;
    }

}
