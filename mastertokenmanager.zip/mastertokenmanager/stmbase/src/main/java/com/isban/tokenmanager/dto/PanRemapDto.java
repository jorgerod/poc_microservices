package com.isban.tokenmanager.dto;

import java.util.Date;

public class PanRemapDto {
    
    private String panOld = null;
    private String requestId = null;
    private Date operationDate = null;
    private String panNew = null;
    private String panRequestStateId = null;
    private String panRequestStateName = null;

    public String getItemOld() {
        return panOld;
    }

    public void setPanOld(String panOld) {
        this.panOld = panOld;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String ticketTmId) {
        this.requestId = ticketTmId;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public String getItemNew() {
        return panNew;
    }

    public void setPanNew(String panNew) {
        this.panNew = panNew;
    }

    public String getTokenStateId() {
        return panRequestStateId;
    }

    public void setPanRequestStateId(String panRequestStateId) {
        this.panRequestStateId = panRequestStateId;
    }

    public String getTokenStateName() {
        return panRequestStateName;
    }

    public void setPanRequestStateName(String panRequestStateName) {
        this.panRequestStateName = panRequestStateName;
    }
}
