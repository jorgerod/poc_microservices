package com.isban.tokenmanager.dto;

public class TokenRequestorSitCardDto extends LifeTimeDto {

    private String tokenTypeId = null;
    private String tokenRequestorId = null;
    private String sitCardId;

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getSitCardId() {
        return sitCardId;
    }

    public void setSitCardId(String sitCardId) {
        this.sitCardId = sitCardId;
    }

}
