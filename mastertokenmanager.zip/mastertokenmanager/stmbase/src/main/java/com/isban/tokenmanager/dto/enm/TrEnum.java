package com.isban.tokenmanager.dto.enm;

public enum TrEnum {
    
    APPLE_PAY("0001"),
    SANTANDER_CH("0002"),
    SANTANDER_SP("0003"),
    SANTANDER_UK("0004"),
    SANTANDER_USA("0005"),
    SAMSUNG_PAY("0006"),
    OPENBANK("0007"),
    MDES("0008"),
    SANTANDER_CONSUMER_BANK("0009"),
    ANDROID_PAY("0010");

    private String code;
    
    TrEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public static TrEnum get(String n) {
        for (TrEnum c : values()) {
            if (c.code.equals(n)) {
                return c;
            }
        }
        // either throw the IAE or return null, your choice.
        throw new IllegalArgumentException(String.valueOf(n));
    }
}
