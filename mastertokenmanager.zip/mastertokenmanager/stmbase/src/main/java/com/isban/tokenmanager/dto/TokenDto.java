package com.isban.tokenmanager.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class TokenDto extends ModelBaseDto {

    private String tokenId = null;
    private String item = null;
    private String itemReferenceId = null;
    private String requestId = null;
    private String tspSyncStateId = null;
    private String tspSyncStateName = null;
    private String ditem;
    private Date expirationDitem = null;
    private Date expirationPan = null;
    private String accountNumber = null;

    private ProductDto product = null;
    private BinDto bin = null;

    public String ticketExt = null;
    private String correlationId = null;
    private String tspId = null;

    protected String tokenRequestorId = null;
    protected String tokenRequestorName = null;
    private String deviceId = null;
    private String deviceType = null;
    private String deviceName = null;
    private String typeBin = null;

    private String tokenAssuranceLevel = null;
    private String tokenType = null;
    private Integer numberActiveTokensPan = 0;
    private Integer numberInactiveTokens = 0;
    private Integer numberSuspendedTokens = 0;
    private String termAndConditions = null;
    private Date termAndConditionsDate = null;

    private Date operationDate = null;
    private String tokenStateId = null;
    private String tokenStateName = null;
    private String pvv = null;

    private Integer numberActivationAttemps = 0;
    // cardless info
    private Date requestDate = null;
    private String activationMethodClient = null;
    private String amount;
    private String branchOffice;
    private String currency;
    private String customerId;
    private Boolean smsSend;
    private String retentionId = null;
    private String externalTransactionId;

    private Date smsDelay;
    private String terminalId;

    private String tokenReferenceId;
    
    //Cardless status change info
    private String statusChangeBranchOffice;
    private String statusChangeUserId;
    private String statusChangeComments;

    // Withdrawall Info
    private String commerceId;
    private String commerceName;
    private String commerceAddress;
    private String commerceCity;
    private String commerceState;
    private String commerceCountry;
    private String commercePostalCode;
    private String acquirerId;
    private String forwardingId;

    // Reversal withdrawall Info
    private String reversalWithdrawalReasonCode;
    private Date withdrawalOpTime;
    private String withdrawalAuthCode;

    @JsonIgnore
    private String tokenBase64 = null;

    private List<String> actions = new ArrayList<>();

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getTspSyncStateId() {
        return tspSyncStateId;
    }

    public void setTspSyncStateId(String tspSyncStateId) {
        this.tspSyncStateId = tspSyncStateId;
    }

    public String getTspSyncStateName() {
        return tspSyncStateName;
    }

    public void setTspSyncStateName(String tspSyncStateName) {
        this.tspSyncStateName = tspSyncStateName;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    public Date getExpirationDitem() {
        return expirationDitem;
    }

    public void setExpirationDitem(Date expirationDitem) {
        this.expirationDitem = expirationDitem;
    }

    public Date getExpirationPan() {
        return expirationPan;
    }

    public void setExpirationPan(Date expirationPan) {
        this.expirationPan = expirationPan;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getTicketExt() {
        return ticketExt;
    }

    public void setTicketExt(String ticketExt) {
        this.ticketExt = ticketExt;
    }

    public String getTspId() {
        return tspId;
    }

    public void setTspId(String tspId) {
        this.tspId = tspId;
    }

    public List<String> getActions() {
        return actions;
    }

    public void setActions(List<String> actions) {
        this.actions = actions;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getTokenRequestorName() {
        return tokenRequestorName;
    }

    public void setTokenRequestorName(String tokenRequestorName) {
        this.tokenRequestorName = tokenRequestorName;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getTypeBin() {
        return typeBin;
    }

    public void setTypeBin(String typeBin) {
        this.typeBin = typeBin;
    }

    public ProductDto getProduct() {
        return product;
    }

    public void setProduct(ProductDto product) {
        this.product = product;
    }

    public BinDto getBin() {
        return bin;
    }

    public void setBin(BinDto bin) {
        this.bin = bin;
    }

    public String getTokenAssuranceLevel() {
        return tokenAssuranceLevel;
    }

    public void setTokenAssuranceLevel(String tokenAssuranceLevel) {
        this.tokenAssuranceLevel = tokenAssuranceLevel;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public Integer getNumberActiveTokensPan() {
        return numberActiveTokensPan;
    }

    public void setNumberActiveTokensPan(Integer numberActiveTokensPan) {
        this.numberActiveTokensPan = numberActiveTokensPan;
    }

    public Integer getNumberInactiveTokens() {
        return numberInactiveTokens;
    }

    public void setNumberInactiveTokens(Integer numberInactiveTokens) {
        this.numberInactiveTokens = numberInactiveTokens;
    }

    public Integer getNumberSuspendedTokens() {
        return numberSuspendedTokens;
    }

    public void setNumberSuspendedTokens(Integer numberSuspendedTokens) {
        this.numberSuspendedTokens = numberSuspendedTokens;
    }

    public String getTermAndConditions() {
        return termAndConditions;
    }

    public void setTermAndConditions(String termAndConditions) {
        this.termAndConditions = termAndConditions;
    }

    public Date getTermAndConditionsDate() {
        return termAndConditionsDate;
    }

    public void setTermAndConditionsDate(Date termAndConditionsDate) {
        this.termAndConditionsDate = termAndConditionsDate;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public String getTokenStateId() {
        return tokenStateId;
    }

    public void setTokenStateId(String tokenStateId) {
        this.tokenStateId = tokenStateId;
    }

    public String getTokenStateName() {
        return tokenStateName;
    }

    public void setTokenStateName(String tokenStateName) {
        this.tokenStateName = tokenStateName;
    }

    public String getPvv() {
        return pvv;
    }

    public void setPvv(String pvv) {
        this.pvv = pvv;
    }

    public String getTokenBase64() {
        return tokenBase64;
    }

    public void setTokenBase64(String tokenBase64) {
        this.tokenBase64 = tokenBase64;
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public String getItemReferenceId() {
        return itemReferenceId;
    }

    public void setItemReferenceId(String itemReferenceId) {
        this.itemReferenceId = itemReferenceId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getActivationMethodClient() {
        return activationMethodClient;
    }

    public void setActivationMethodClient(String activationMethodClient) {
        this.activationMethodClient = activationMethodClient;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBranchOffice() {
        return branchOffice;
    }

    public void setBranchOffice(String branchOffice) {
        this.branchOffice = branchOffice;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public Boolean getSmsSend() {
        return smsSend;
    }

    public void setSmsSend(Boolean smsSend) {
        this.smsSend = smsSend;
    }

    public String getRetentionId() {
        return retentionId;
    }

    public void setRetentionId(String retentionId) {
        this.retentionId = retentionId;
    }

    public Date getSmsDelay() {
        return smsDelay;
    }

    public void setSmsDelay(Date smsDelay) {
        this.smsDelay = smsDelay;
    }

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public String getCommerceId() {
        return commerceId;
    }

    public void setCommerceId(String commerceId) {
        this.commerceId = commerceId;
    }

    public String getCommerceName() {
        return commerceName;
    }

    public void setCommerceName(String commerceName) {
        this.commerceName = commerceName;
    }

    public String getCommerceAddress() {
        return commerceAddress;
    }

    public void setCommerceAddress(String commerceAddress) {
        this.commerceAddress = commerceAddress;
    }

    public String getCommerceCity() {
        return commerceCity;
    }

    public void setCommerceCity(String commerceCity) {
        this.commerceCity = commerceCity;
    }

    public String getCommerceState() {
        return commerceState;
    }

    public void setCommerceState(String commerceState) {
        this.commerceState = commerceState;
    }

    public String getCommerceCountry() {
        return commerceCountry;
    }

    public void setCommerceCountry(String commerceCountry) {
        this.commerceCountry = commerceCountry;
    }

    public String getCommercePostalCode() {
        return commercePostalCode;
    }

    public void setCommercePostalCode(String commercePostalCode) {
        this.commercePostalCode = commercePostalCode;
    }

    public String getAcquirerId() {
        return acquirerId;
    }

    public void setAcquirerId(String acquirerId) {
        this.acquirerId = acquirerId;
    }

    public String getForwardingId() {
        return forwardingId;
    }

    public void setForwardingId(String forwardingId) {
        this.forwardingId = forwardingId;
    }

    public String getReversalWithdrawalReasonCode() {
        return reversalWithdrawalReasonCode;
    }

    public void setReversalWithdrawalReasonCode(String reversalWithdrawalReasonCode) {
        this.reversalWithdrawalReasonCode = reversalWithdrawalReasonCode;
    }

    public Date getWithdrawalOpTime() {
        return withdrawalOpTime;
    }

    public void setWithdrawalOpTime(Date withdrawalOpTime) {
        this.withdrawalOpTime = withdrawalOpTime;
    }

    public String getWithdrawalAuthCode() {
        return withdrawalAuthCode;
    }

    public void setWithdrawalAuthCode(String withdrawalAuthCode) {
        this.withdrawalAuthCode = withdrawalAuthCode;
    }

    public Integer getNumberActivationAttemps() {
        return numberActivationAttemps;
    }

    public void setNumberActivationAttemps(Integer numberActivationAttemps) {
        this.numberActivationAttemps = numberActivationAttemps;
    }

    public String getStatusChangeBranchOffice() {
        return statusChangeBranchOffice;
    }

    public void setStatusChangeBranchOffice(String statusChangeBranchOffice) {
        this.statusChangeBranchOffice = statusChangeBranchOffice;
    }

    public String getStatusChangeUserId() {
        return statusChangeUserId;
    }

    public void setStatusChangeUserId(String statusChangeUserId) {
        this.statusChangeUserId = statusChangeUserId;
    }

    public String getStatusChangeComments() {
        return statusChangeComments;
    }

    public void setStatusChangeComments(String statusChangeComments) {
        this.statusChangeComments = statusChangeComments;
    }

    public String getExternalTransactionId() {
        return externalTransactionId;
    }

    public void setExternalTransactionId(String externalTransactionId) {
        this.externalTransactionId = externalTransactionId;
    }

    @Override
    public String toString() {
        return "TokenDto [tokenId=" + tokenId + ", item=" + item + ", itemReferenceId=" + itemReferenceId
                + ", requestId=" + requestId + ", tspSyncStateId=" + tspSyncStateId + ", tspSyncStateName="
                + tspSyncStateName + ", ditem=" + ditem + ", expirationDitem=" + expirationDitem + ", expirationPan="
                + expirationPan + ", accountNumber=" + accountNumber + ", product=" + product + ", bin=" + bin
                + ", ticketExt=" + ticketExt + ", correlationId=" + correlationId + ", tspId=" + tspId
                + ", tokenRequestorId=" + tokenRequestorId + ", tokenRequestorName=" + tokenRequestorName
                + ", deviceId=" + deviceId + ", deviceType=" + deviceType + ", deviceName=" + deviceName + ", typeBin="
                + typeBin + ", tokenAssuranceLevel=" + tokenAssuranceLevel + ", tokenType=" + tokenType
                + ", numberActiveTokensPan=" + numberActiveTokensPan + ", numberInactiveTokens=" + numberInactiveTokens
                + ", numberSuspendedTokens=" + numberSuspendedTokens + ", termAndConditions=" + termAndConditions
                + ", termAndConditionsDate=" + termAndConditionsDate + ", operationDate=" + operationDate
                + ", tokenStateId=" + tokenStateId + ", tokenStateName=" + tokenStateName + ", pvv=" + pvv
                + ", numberActivationAttemps=" + numberActivationAttemps + ", requestDate=" + requestDate
                + ", activationMethodClient=" + activationMethodClient + ", amount=" + amount + ", branchOffice="
                + branchOffice + ", currency=" + currency + ", customerId=" + customerId + ", smsSend=" + smsSend
                + ", retentionId=" + retentionId + ", externalTransactionId=" + externalTransactionId + ", smsDelay="
                + smsDelay + ", terminalId=" + terminalId + ", tokenReferenceId=" + tokenReferenceId
                + ", statusChangeBranchOffice=" + statusChangeBranchOffice + ", statusChangeUserId="
                + statusChangeUserId + ", statusChangeComments=" + statusChangeComments + ", commerceId=" + commerceId
                + ", commerceName=" + commerceName + ", commerceAddress=" + commerceAddress + ", commerceCity="
                + commerceCity + ", commerceState=" + commerceState + ", commerceCountry=" + commerceCountry
                + ", commercePostalCode=" + commercePostalCode + ", acquirerId=" + acquirerId + ", forwardingId="
                + forwardingId + ", reversalWithdrawalReasonCode=" + reversalWithdrawalReasonCode
                + ", withdrawalOpTime=" + withdrawalOpTime + ", withdrawalAuthCode=" + withdrawalAuthCode
                + ", tokenBase64=" + tokenBase64 + ", actions=" + actions + ", issuerId=" + issuerId + ", tokenTypeId="
                + tokenTypeId + "]";
    }


}
