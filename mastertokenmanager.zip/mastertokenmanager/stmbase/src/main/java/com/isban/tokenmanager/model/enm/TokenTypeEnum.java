package com.isban.tokenmanager.model.enm;

public enum TokenTypeEnum {
    WALLET(TokenTypeId.WALLET, "WALLET"), 
    OTP(TokenTypeId.OTP, "OTP");
    // nombres no definitivos

    private String code;
    private String name;

    TokenTypeEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public class TokenTypeId {

        public static final String WALLET = "0";
        public static final String OTP = "1";
    }
}
