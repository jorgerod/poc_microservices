
package com.isban.tokenmanager.ws.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CardType complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CardType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="pan" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="expirationdate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pvv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cardart" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isregister" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ticketref" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardType", propOrder = {
    "pan",
    "expirationdate",
    "pvv",
    "cardart",
    "isregister",
    "ticketref"
})
public class CardType {

    @XmlElement(required = true)
    protected String pan;
    @XmlElement(required = true)
    protected String expirationdate;
    protected String pvv;
    protected String cardart;
    @XmlElement(required = true)
    protected String isregister;
    protected String ticketref;

    /**
     * Obtiene el valor de la propiedad pan.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPan() {
        return pan;
    }

    /**
     * Define el valor de la propiedad pan.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPan(String value) {
        this.pan = value;
    }

    /**
     * Obtiene el valor de la propiedad expirationdate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpirationdate() {
        return expirationdate;
    }

    /**
     * Define el valor de la propiedad expirationdate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpirationdate(String value) {
        this.expirationdate = value;
    }

    /**
     * Obtiene el valor de la propiedad pvv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPvv() {
        return pvv;
    }

    /**
     * Define el valor de la propiedad pvv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPvv(String value) {
        this.pvv = value;
    }

    /**
     * Obtiene el valor de la propiedad cardart.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardart() {
        return cardart;
    }

    /**
     * Define el valor de la propiedad cardart.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardart(String value) {
        this.cardart = value;
    }

    /**
     * Obtiene el valor de la propiedad isregister.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsregister() {
        return isregister;
    }

    /**
     * Define el valor de la propiedad isregister.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsregister(String value) {
        this.isregister = value;
    }

    /**
     * Obtiene el valor de la propiedad ticketref.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTicketref() {
        return ticketref;
    }

    /**
     * Define el valor de la propiedad ticketref.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTicketref(String value) {
        this.ticketref = value;
    }

}
