package com.isban.tokenmanager.integration.tsp;

public class ProvisioningHttpRequest extends TspHttpRequest {

    protected String tokenTypeId;
    private String tspId;

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    public String getTspId() {
        return tspId;
    }

    public void setTspId(String tspId) {
        this.tspId = tspId;
    }
}
