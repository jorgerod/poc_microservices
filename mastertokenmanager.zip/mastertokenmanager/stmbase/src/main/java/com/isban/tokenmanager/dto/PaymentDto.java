package com.isban.tokenmanager.dto;

import java.util.Date;

public class PaymentDto extends ModelBaseDto {

    private String ticketTmId;
    private String pan;

    private String ditem;

    private String commerceId;
    private String authId;
    private Date transactionDate;
    // private Date operationDate;// aaaammdd
    private Date operationDate; // operationDay + operationHour
    private String operationDay;// aaaammdd
    private String operationHour;// HHmmss
    private String operationId;
    private String resolutorOperation;
    private String resolverCode;
    private String amount;
    private String currency;
    private String town;
    private String countryId;
    private String deviceType;
    private String paymentType;

    public PaymentDto() {
    }

    public String getRequestId() {
        return ticketTmId;
    }

    public void setRequestId(String ticketTmId) {
        this.ticketTmId = ticketTmId;
    }

    public String getItem() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    public String getCommerceId() {
        return commerceId;
    }

    public void setCommerceId(String commerceId) {
        this.commerceId = commerceId;
    }

    public String getAuthId() {
        return authId;
    }

    public void setAuthId(String authId) {
        this.authId = authId;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getOperationDay() {
        return operationDay;
    }

    public void setOperationDay(String operationDay) {
        this.operationDay = operationDay;
    }

    public String getOperationHour() {
        return operationHour;
    }

    public void setOperationHour(String operationHour) {
        this.operationHour = operationHour;
    }

    public String getOperationId() {
        return operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }

    public String getResolutorOperation() {
        return resolutorOperation;
    }

    public void setResolutorOperation(String resolutorOperation) {
        this.resolutorOperation = resolutorOperation;
    }

    public String getResolverCode() {
        return resolverCode;
    }

    public void setResolverCode(String resolverCode) {
        this.resolverCode = resolverCode;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getCountryId() {
        return countryId;
    }

    public void setCountryId(String countryId) {
        this.countryId = countryId;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    @Override
    public String toString() {
        return "PaymentDto [ticketTmId=" + ticketTmId + ", pan=" + pan + ", dpan=" + ditem+ ", commerceId=" + commerceId
                + ", authId=" + authId + ", transactionDate=" + transactionDate + ", operationDate=" + operationDate
                + ", operationDay=" + operationDay + ", operationHour=" + operationHour + ", operationId=" + operationId
                + ", resolutorOperation=" + resolutorOperation + ", resolverCode=" + resolverCode + ", amount=" + amount
                + ", currency=" + currency + ", town=" + town + ", countryId=" + countryId + ", deviceType="
                + deviceType + ", paymentType=" + paymentType + ", issuerId=" + issuerId + ", getRequestId()="
                + getRequestId() + ", getItem()=" + getItem() + ", getDitem()=" + getDitem() + ", getCommerceId()="
                + getCommerceId() + ", getAuthId()=" + getAuthId() + ", getTransactionDate()=" + getTransactionDate()
                + ", getOperationDay()=" + getOperationDay() + ", getOperationHour()=" + getOperationHour()
                + ", getOperationId()=" + getOperationId() + ", getResolutorOperation()=" + getResolutorOperation()
                + ", getResolverCode()=" + getResolverCode() + ", getAmount()=" + getAmount() + ", getCurrency()="
                + getCurrency() + ", getTown()=" + getTown() + ", getCountryId()=" + getCountryId()
                + ", getDeviceType()=" + getDeviceType() + ", getPaymentType()=" + getPaymentType()
                + ", getOperationDate()=" + getOperationDate() + ", getIssuerId()=" + getIssuerId() + ", getClass()="
                + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
    }
}
