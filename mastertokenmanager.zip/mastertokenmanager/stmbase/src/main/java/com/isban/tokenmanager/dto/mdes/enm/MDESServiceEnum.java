package com.isban.tokenmanager.dto.mdes.enm;

public enum MDESServiceEnum {
    DIGITIZATION("DIGITIZATION");

    private String code;

    MDESServiceEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
