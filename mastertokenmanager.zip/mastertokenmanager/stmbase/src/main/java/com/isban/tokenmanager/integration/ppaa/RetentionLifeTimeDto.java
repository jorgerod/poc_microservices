package com.isban.tokenmanager.integration.ppaa;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class RetentionLifeTimeDto {

    private String lifeTimeStart;
    private String lifeTimeEnd;

    @ApiModelProperty(value = "Start Date and Time of validity of the retention. (CCYY-MM-DDThh:mm:ss format)", required = true)
    @Size(max = 19)
    public String getLifeTimeStart() {
        return lifeTimeStart;
    }

    public void setLifeTimeStart(String lifeTimeStart) {
        this.lifeTimeStart = lifeTimeStart;
    }

    @ApiModelProperty(value = "End Date and Time of validity of the retention. (CCYY-MM-DDThh:mm:ss format)", required = true)
    @Size(max = 19)
    public String getLifeTimeEnd() {
        return lifeTimeEnd;
    }

    public void setLifeTimeEnd(String lifeTimeEnd) {
        this.lifeTimeEnd = lifeTimeEnd;
    }

}