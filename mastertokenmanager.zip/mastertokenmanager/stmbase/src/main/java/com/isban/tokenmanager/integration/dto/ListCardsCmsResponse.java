package com.isban.tokenmanager.integration.dto;

import java.util.List;

public class ListCardsCmsResponse {

    private String codRes;
    private String desRes;
    private List<Card> cards;

    public ListCardsCmsResponse() {

    }

    public ListCardsCmsResponse(String codRes, String desRes) {
        this.codRes = codRes;
        this.desRes = desRes;
    }


    public ListCardsCmsResponse(String codRes, String desRes, List<Card> cards) {
        this.codRes = codRes;
        this.desRes = desRes;
        this.cards = cards;
    }

    public String getCodRes() {
        return codRes;
    }

    public void setCodRes(String codRes) {
        this.codRes = codRes;
    }

    public String getDesRes() {
        return desRes;
    }

    public void setDesRes(String desRes) {
        this.desRes = desRes;
    }

    public List<Card> getCards() {
        return cards;
    }

    public void setCards(List<Card> cards) {
        this.cards = cards;
    }

    @Override
    public String toString() {
        return "ListCardsResponse [codRes=" + codRes + ", desRes=" + desRes
                + ", cards=" + cards + "]";
    }


}
