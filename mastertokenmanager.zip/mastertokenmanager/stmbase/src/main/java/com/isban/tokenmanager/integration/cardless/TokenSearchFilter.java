package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.isban.tokenmanager.util.Constants;

import io.swagger.annotations.ApiModelProperty;
import springfox.documentation.annotations.ApiIgnore;

public class TokenSearchFilter {

    private String nrbe;
    private String branchOffice;
    private String customerId;
    private String startTime;
    private String endTime;
    private String contract;
    private String state;
    private String tokenReferenceId;
    private String accountNumber;

    @ApiModelProperty(value = "Entity Code", required = true)
    @Size(max = 4)
    public String getNrbe() {
        return nrbe;
    }

    public void setNrbe(String nrbe) {
        this.nrbe = nrbe;
    }

    @ApiModelProperty(value = "Branch Office", required = false)
    @Size(max = 4)
    public String getBranchOffice() {
        return branchOffice;
    }

    public void setBranchOffice(String branchOffice) {
        this.branchOffice = branchOffice;
    }

    @ApiModelProperty(value = "ID of the customer", required = false)
    @Size(max = 10)
    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    @ApiModelProperty(value = "Start time", required = false)
    @Pattern(regexp = Constants.PATTERN_DATETIME)
    @Size(max = 19)
    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    @ApiModelProperty(value = "End time", required = false)
    @Pattern(regexp = Constants.PATTERN_DATETIME)
    @Size(max = 19)
    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    @ApiModelProperty(value = "Partenon contract number", required = false)
    @Pattern(regexp = "\\d+")
    @Size(max = 18)
    public String getContract() {
        return contract;
    }

    public void setContract(String contract) {
        this.contract = contract;
    }

    @ApiModelProperty(value = "State of the token", required = false)
    @Size(max = 2)
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @ApiModelProperty(value = "Unique ID of the token", required = false)
    @Size(max = 32)
    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenId) {
        this.tokenReferenceId = tokenId;
    }

    @ApiIgnore
    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
}
