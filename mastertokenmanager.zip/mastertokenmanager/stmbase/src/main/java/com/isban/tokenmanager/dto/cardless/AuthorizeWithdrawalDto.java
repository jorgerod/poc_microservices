package com.isban.tokenmanager.dto.cardless;

import java.util.Date;

import com.isban.tokenmanager.dto.ModelBaseDto;

public class AuthorizeWithdrawalDto extends ModelBaseDto {

    private Date opTime;
    private String item;
    private String dItem;
    private String amount;
    private String currency;
    private String terminalId;
    private String commerceId;
    private String commerceName;
    private String commerceAddress;
    private String commerceCity;
    private String commerceState;
    private String commerceCountry;
    private String commercePostalCode;
    private String acquirerId;
    private String forwardingId;

    public Date getOpTime() {
        return opTime;
    }
    public void setOpTime(Date opTime) {
        this.opTime = opTime;
    }
    public String getItem() {
        return item;
    }
    public void setItem(String item) {
        this.item = item;
    }
    public String getDItem() {
        return dItem;
    }
    public void setDItem(String dItem) {
        this.dItem = dItem;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public String getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
    public String getCommerceId() {
        return commerceId;
    }
    public void setCommerceId(String commerceId) {
        this.commerceId = commerceId;
    }
    public String getCommerceName() {
        return commerceName;
    }
    public void setCommerceName(String commerceName) {
        this.commerceName = commerceName;
    }
    public String getCommerceAddress() {
        return commerceAddress;
    }
    public void setCommerceAddress(String commerceAddress) {
        this.commerceAddress = commerceAddress;
    }
    public String getCommerceCity() {
        return commerceCity;
    }
    public void setCommerceCity(String commerceCity) {
        this.commerceCity = commerceCity;
    }
    public String getCommerceState() {
        return commerceState;
    }
    public void setCommerceState(String commerceState) {
        this.commerceState = commerceState;
    }
    public String getCommerceCountry() {
        return commerceCountry;
    }
    public void setCommerceCountry(String commerceCountry) {
        this.commerceCountry = commerceCountry;
    }
    public String getCommercePostalCode() {
        return commercePostalCode;
    }
    public void setCommercePostalCode(String commercePostalCode) {
        this.commercePostalCode = commercePostalCode;
    }
    public String getAcquirerId() {
        return acquirerId;
    }
    public void setAcquirerId(String acquirerId) {
        this.acquirerId = acquirerId;
    }
    public String getForwardingId() {
        return forwardingId;
    }
    public void setForwardingId(String forwardingId) {
        this.forwardingId = forwardingId;
    }
    
    @Override
    public String toString() {
        return "AuthorizeWithdrawalDto [opTime=" + opTime + ", item=" + item + ", dItem=" + dItem + ", amount=" + amount
                + ", currency=" + currency + ", terminalId=" + terminalId + ", commerceId=" + commerceId
                + ", commerceName=" + commerceName + ", commerceAddress=" + commerceAddress + ", commerceCity="
                + commerceCity + ", commerceState=" + commerceState + ", commerceCountry=" + commerceCountry
                + ", commercePostalCode=" + commercePostalCode + ", acquirerId=" + acquirerId + ", forwardingId="
                + forwardingId + ", issuerId=" + issuerId + ", tokenTypeId=" + tokenTypeId + "]";
    }
    

}
