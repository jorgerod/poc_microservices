package com.isban.tokenmanager.model.enm;

public enum TagEventEnum {
    REQUEST_ID("00"),
    PAN_ID("01"),
    DPAN_ID("02"),
    PAYMENT_ID("03"),
    PAYMENT_ORIGIN_ID("04"),
    CLIENT_ID("05"),
    WALLET_ID("06"),
    DEVICE_ID("07"),
    TICKET_REF("08"),
    LOGIN("09"),
    COMPANYID("10"),
    ROLE_ID("11"),
    TSP_ID("12");

    private String code;

    TagEventEnum(String val) {
        this.code = val;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
