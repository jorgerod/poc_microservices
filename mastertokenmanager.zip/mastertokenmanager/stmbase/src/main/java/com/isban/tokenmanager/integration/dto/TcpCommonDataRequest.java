package com.isban.tokenmanager.integration.dto;

public class TcpCommonDataRequest {

    /* Common data */
    private String operationId;
    private String operationDateTime; // aaaammddHHmmssSSS
    private String issuerId;
    private String tokenTypeId;
    private String tokenRequestorId;
    private String item;
    private String expirationDatePan; // YYMM
    private String dataEntryMode;// modo de entrada de la operacion

    public TcpCommonDataRequest() {
    }

    public TcpCommonDataRequest(String operationId, String operationDateTime, String issuerId, String tokenTypeId, String tokenRequestorId,
            String pan, String expirationDatePan, String dataEntryMode) {
        super();
        this.operationId = operationId;
        this.operationDateTime = operationDateTime;
        this.issuerId = issuerId;
        this.tokenTypeId = tokenTypeId;
        this.tokenRequestorId = tokenRequestorId;
        this.item = pan;
        this.expirationDatePan = expirationDatePan;
        this.dataEntryMode = dataEntryMode;
    }

    public String getOperationId() {
        return operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }

    public String getOperationDateTime() {
        return operationDateTime;
    }

    public void setOperationDateTime(String operationDateTime) {
        this.operationDateTime = operationDateTime;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String pan) {
        this.item = pan;
    }

    public String getExpirationDatePan() {
        return expirationDatePan;
    }

    public void setExpirationDatePan(String expirationDatePan) {
        this.expirationDatePan = expirationDatePan;
    }

    public String getDataEntryMode() {
        return dataEntryMode;
    }

    public void setDataEntryMode(String dataEntryMode) {
        this.dataEntryMode = dataEntryMode;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("TcpCommonDataRequest [operationId=").append(operationId).append(", operationTime=")
                .append(operationDateTime).append(", issuerId=").append(issuerId).append(", tokenTypeId=").append(tokenTypeId).append(", tokenRequestorId=").append(tokenRequestorId)
                .append(", item=").append(item).append(", expirationDatePan=").append(expirationDatePan)
                .append(", dataEntryMode=").append(dataEntryMode).append("]");
        return builder.toString();
    }

}
