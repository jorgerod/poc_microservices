package com.isban.tokenmanager.dto;

import java.util.List;

public class GetWalletsResponse extends ResponseBase {

    private List<WalletDto> wallets;

    public GetWalletsResponse() {
    }

    public GetWalletsResponse(String code, String description) {
        super(code, description);
    }

    public List<WalletDto> getWallets() {
        return wallets;
    }

    public void setWallets(List<WalletDto> wallets) {
        this.wallets = wallets;
    }

    @Override
    public String toString() {
        return "GetWalletsResponse [wallets=" + wallets + "]";
    }

}
