package com.isban.tokenmanager.model.enm;

/**
 * Enumerate that defines the response code of the operations.
 *
 * @author realsec
 */
public enum ResponseStateEnum {

    OK("000", "Operation successfully completed"),
    KO("001", "Could not complete this operation. An unknown error has occurred."),
    KO_OTP_NOT_CONFIGURED("002", "User has not configured OTP in device"),
    KO_ERROR_ACTIVITY_LOG("003", "Error in the Activity Log"),
    KO_DEVICE_BLACK_LIST("004", "User device in Black List"),
    KO_LIST_CARD_EMPTY("005", "User card list is empty"),
    KO_ERROR_CHANNELS("006", "Error in the Channels Operation"),
    KO_ERROR_FTP("007", "Error in the FTP Ocaperation"),
    KO_ERROR_PAN_IS_NULL("008", "The PAN number is null"),
    KO_ERROR_OBTAINED_CARD_IS_NULL("009", "The obtained Card is null"),
    KO_ERROR_USER_HAS_NO_MEDIA("010", "User has not configured media"),
    KO_ERROR_CARD_DOESNT_EXIST("011", "The card doesn't exist"),
    OK_VISA_ACTION_CODE("00", "Success"),
    KO_VISA_ACTION_CODE("01", "Failed"),
    KO_ERROR_ITEM_NO_TOKENIZED("011", "Item not tokenized"),
    KO_ERROR_MASTERCARD_CONNECTION("012", "Error connection to the Mastercard API"),
    KO_ERROR_CANCELLATION_SOME_TOKEN("013", "Error cancelling some token"),
    KO_ERROR_REQUIRED_DATA_MISSING("014", "Required data is missing"),
    KO_ERROR_FILE_PAN_DPAN_SFTP("015", "Problem with SFTP"),
    KO_ERROR_FILE_PAN_DPAN_NO_TOKEN("016", "No Pan tokenized"),
    KO_ERROR_FILE_PAN_DPAN_NOT_ISSUER("017", "Issuer not found"),
    KO_ERROR_FILE_PAN_DPAN_NOT_GENERATED("018", "File Pan - DPan not generated"),
    KO_ERROR_FILE_PAN_DPAN_SFTP_NOT_FOUND("019", "File Pan - DPan not found in SFTP"),
    KO_ERROR_ISSUER_NOT_FOUND("020", "Issuer not found"),
    KO_ERROR_WALLET_NOT_FOUND("021", "Wallet not found"),
    KO_LIST_CARD_VALIDATION("022", "The list of validated cards is different from the selected cards"),
    KO_ERROR_NO_CREATED_TOKEN("023", "Error creating Token..."),
    KO_ERROR_TSP_NOT_FOUND("024", "TSP not found..."),
    KO_ERROR_CORRELATION_ID_EXIST_FOR_OTHER_PAN("025", "CorrelationId exist for other Pan..."),
    KO_ERROR_RETRIEVE_TOKEN("026", "Error retrieving Token..."),
    KO_ERROR_PROCESS_ACN("027", "Could not complete ACN process."),
    KO_ERROR_VISA_PARAM_NULL("028", "Mandatory Data Element missing in the request"), //ISE40000
    KO_ERROR_VISA_INVALID_FIELD_LENGTH("029", "Value populated in the data element in the request has an invalid length in the field"), //ISE40005
    KO_ERROR_VISA_INVALID_FIELD_TYPE("030", "Value populated in the data element in the request has an invalid type in the field"), //ISE40006
    KO_ERROR_VISA_UNABLE_TO_DECRYPT_INFORMATION_REQUEST("031", "Unable to decrypt the information received in the request"), //ISE40010
    KO_ERROR_VISA_INVALID_FIELD_VALUE("032", "Value populated in the data element in the request is not valid"), //ISE40011
    KO_ERROR_VISA_UNKNOWN_TOKEN_VALUE("033", "Token value populated in the request is not a known value for the Issuer"), //ISE40402
    KO_ERROR_VISA_UNKNOWN_TOKEN_REFERENCE_ID_VALUE("034", "Token Reference ID Value populated in the request is not a known value for the Issuer"), //ISE40500
    KO_ERROR_VISA_INTERNAL_SYSTEM_ERROR("035", "Any Internal system Error"), //ISE40504
    KO_ERROR_VISA_INVALID_RESOLUTION_METHOD_ID("036", "Resolution Method ID received in the request is not valid"), //ISE40501
    KO_ERROR_VISA_CHANNEL_UNAVAILABLE("037", "Communication via selected channel is currently not available"), //ISE40502
    KO_ERROR_VISA_INVALID_RECEIVED_RESOLUTION_METHOD_ID("038", "Resolution Method ID received in the request is not valid anymore"), //ISE40503
    KO_NOTIFICATION_TICKET_NOT_FOUND("039", "Ticket Ext. Not found"),
    KO_NOTIFICATION_REQUEST_NOT_FOUND("040", "Request. Not found"),
    KO_NOTIFICATION_TOKEN_DIFFERENT("041", "Token/s is different"),
    KO_ERROR_RETRIEVE_BIN("042", "Error retrieving Bin..."),
    KO_ERROR_RETRIEVE_WALLET("043", "Error retrieving Wallet..."),
    KO_ERROR_SELECTED_TSP("044", "Error selecting TSP..."),

    KO_PAYMENT_PAN_DPAN("045", "Payment Error: Invalidate data"),
    KO_PAYMENT_EXIST("046", "Payment Error: Repeated payment"),
    KO_PAYMENT_GENERIC("047", "Payment Error: Error to save the payment"),

    KO_USER_NOT_FOUND("048", "User not found"),
    KO_GET_PROFILE_USER_ROLE_NOT_FOUND("049", "User role not found"),
    KO_GET_COMPANIES_NOT_FOUND("050", "Companies not found"),
    KO_USER_ISSUER_RELATION_NOT_FOUND("051", "Issuers not found for this user id"),
    KO_REQUEST_HISTORY_NOT_FOUND("052", "No registration history available"),

    KO_NOTIFICATION_TO_MDES("053", "Error notification MDES"),

    KO_NOTIFICATION_TO_SEGLAN("054", "Error notification SEGLAN"),

    KO_STATUS_HISTORY_TO_MDES("055", "Error Status History MDES"),

    KO_CANCEL_REQUEST_PENDING("056", "Can not be canceled a request in this state"),

    KO_NOTIFICATION_NO_EXIST_TO_MDES("057", "Error notification MDES, no existe servicio (Refrescar para ver estado actualizado)"),

    KO_NOTIFICATION_NO_EXIST_TO_SEGLAN("058", "Error notification SEGLAN, no existe servicio (Refrescar para ver estado actualizado)"),

    KO_NOTIFICATION_VISA_SUSPEND("059", "Visa notification error - SUSPEND"),

    KO_NOTIFICATION_VISA_DELETE("060", "Visa notification error - DELETE"),

    KO_NOTIFICATION_VISA_RESUME("061", "Visa notification error - RESUME"),

    KO_NOTIFICATION_VISA_ACTIVATE("062", "Visa notification error - ACTIVATE"),

    KO_NOTIFICATION_URL_NOT_EXIST("063", "Not exist web service URL for this action method"),

    KO_NOTIFICATION_ERROR_RETRIVE_TOKEN("064", "Failed to get token"),

    KO_NOTIFICATION_FIELD_REQUIRED("065", "Error notification, missing required fields"),

    KO_NO_ACTIVATION_METHODS("066", "No activation methods"),

    KO_ERROR_VISA_INVALID_REQUEST("067", "Invalid Request: Mandatory Field Missing or Invalid Field Type, Field Value or Field Length"), //VSE40000
    KO_ERROR_VISA_INVALID_PAYMENT_INSTRUMENT("068", "Invalid Payment Instrument: Invalid PAN, Token, PAN Ref ID, Token Ref ID or Token Requestor ID"), //VSE40001
    KO_ERROR_VISA_TOKEN_ALEREADY_IN_REQUESTED_STATUS("069", "Token Already in Requested Status"), //VSE40002
    KO_ERROR_VISA_NO_TOKEN_FOUND_FOR_REQUEST_CRITERIA("070", "No Token found for the request criteria"), //VSE40003

    KO_CLIENT_OR_PAN_NOT_FOUND("071", "Client/Pan not found"),

    KO_REQUEST_DELETED("072", "Request has been deleted"),

    KO_ACT_METHOD_NOT_EXISTS("073", "Activation Method not exists"),

    KO_CLIENT_NOT_FOUND("074", "Client not found"),

    KO_FIELD_REQUIRED("075", "Missing required fields"),

    KO_ISSUER_ID_EXISTS("076", "Issuer Id already exists"),

    KO_NOT_AUTH_EDIT_ISSUER("077", "You are not authorized to edit this issuer"),

    KO_WALLET_ID_EXISTS("078", "Wallet Id already exists"),

    KO_VALIDATION_INCOMING("079", "Error Validation Incoming File line"),

    KO_PAYMENT_NO_EXIST("080", "Payment no exists"),

    KO_TOKEN_NO_EXIST("081", "Token no exists"),

    KO_TSP_ID_EXISTS("082", "Tsp Id already exists"),

    KO_ERROR_CREATE_SFTP_CREDENTIAL("083", "Error creating sftp credential"),

    KO_ERROR_ISSUER_SFTP_CREDENTIAL_EXISTS("084", "Issuer sftp credential already exists"),

    KO_ERROR_NO_ID_ISSUER_SFTP_CREDENTIAL_("085", "Issuer sftp credential incorrect"),
    
    KO_VALIDATE_FIELDS("086", "Error validating fields"),

    KO_ERROR_GET_ALL_USERS("086", "Error retrieving users"),
    
    KO_ERROR_UPDATE_ELIGIBILITY_RULES_REQUEST("087", "Error retrieving param to update eligibility rules"),
    
    KO_ERROR_GET_ALL_ISSUER_WALLET("088", "No Wallets for this Issuer"),
    
    KO_ERROR_GET_ALL_ROLES("089", "Error retrieving roles"),    

    KO_ERROR_USER_COMPANY_EXIST("090", "User for this company already exist"),

    KO_USER_SAVE_ERROR("091", "Unable to save in the database"),

    KO_COMPANY_NOT_FOUND("092", "Unable to save, company not found"),
    
    KO_PAYMENT_CANCELLATION_GENERIC("093", "Payment Cancellation Error: Error to save the payment cancellation"),
    
    KO_PAYMENT_EXIST_NO_ACCEPT("094", "Payment exists but not accepted"),
    
    KO_PAYMENT_CANCELLATION_EXIST("095", "Payment Cancellation Error: Repeated payment cancellation"),
    
    KO_ERROR_MANAGEMENT_BIN_DIGITAL_REQUEST("096", "Error retrieving param to management bin digital"),
    
    KO_ERROR_MANAGEMENT_BIN_DIGITAL_SAVE("097", "Error to save bin digital"),
    
    KO_ERROR_TYPE_BIN_NOT_FOUND("098", "Type Bin not Found"),
    
    KO_ERROR_BRAND_BIN_NOT_FOUND("099", "Brand Bin not found"),
    
    KO_ERROR_MANAGEMENT_BIN_BIN_PLASTIC_EXIST("100", "Bin Plastic exists with this Id"),
    KO_ERROR_MANAGEMENT_BIN_DIGITAL_EXIST("101", "Bin Digital exists in this/other issuer with this Id"),

    KO_NOTIFICATION_VISA_UPDATE("102", "Visa notification error - UPDATE"),
    
    KO_ERROR_COMMUNICATION("103", "Error commucation with others systems"),
    KO_ERROR_PARAMETERS_REQUEST("104", "Error in parameters request"),
    
    KO_VALIDATION_REMAP("105", "Error Validation Remap File line"),
    KO_BATCH("106", "Generic error of batch process"),
    
    KO_ISSUER_DIFFERENT("107", "Issuer is incorrect"),
    KO_WALLET_DIFFERENT("108", "Wallet is incorrect"),

    KO_STATE_SEQUENCE_ACTION("109", "Incorrect request from state " + ResponseStateEnumId.PARAM_INIT + " to " + ResponseStateEnumId.PARAM_FIN),
    KO_STATE_INVALID_ACTION("110", "Incorrect current state of request"),
    
    KO_TSP_NOT_SYNC("111", "Tsp is not sync"),
    
    OK_ALL_ACT_METHOD_NO_REQUIRED_DATA_CLIENT("112", "All activation methods not required client data."),
    
    KO_MAX_TOKENS_BY_CARD("113", "Card has been max number of tokens"),
    
    KO_SECURITY_CREDENTIAL_TOKEN_EXCEPTION("114", "Security credential token Exception"),
    KO_NOTIFICATION_TO_REDSYS("115", "Error notification REDSYS"),
    KO_CUSTOM_TOKEN_MANAGER_EXCEPTION("999", ""),
    KO_EXCEED_ACTIVE_TOKENS_LIMIT("103", ""),
    KO_EXCEED_AMOUNT_LIMIT("104", ""),
    KO_EXCEED_ACTIVATION_ATTEMPS_LIMIT("103", ""),
    KO_PPAA_DENIED("105", "Denied by issuer"),
    KO_REQUEST_LIMIT_HOUR_REACHED("106", "Hour limit to request a token reached"),
    KO_CARDLESS_PAYOUT_MESSAGE_FORMAT_UNKNOWN_ERROR("901", ""),
    KO_CARDLESS_PAYOUT_INTERNAL_SYSTEM_ERROR("909", ""),
    KO_TOKEN_EXPIRED("104",""),
    KO_DENIED_BY_ISSUER("100",""),
    KO_DENIED_ISSUER_NOT_AVAILABLE("101",""),
    KO_DENIED_INSUFFICIENT_FOUNDS("102",""),
    KO_DENIED_WITHDRAWAL_MESSAGE_NOT_RECEIVER("201",""),
    KO_DENIED_WITHDRAWAL_MESSAGE_WAS_DENIED("202",""),  
    KO_DENIED_INVALID_CONTRACT("108","Invalid Contract"),
    KO_DENIED_TOKEN_STATE_CHANGE_NOT_ALLOWED("110","Token state change not allowed"),
    
    KO_CARDART_ALREADY_EXISTS("200", "Already exists a card art in this date");

    
    
    /**
     * Code of the response state
     */
    private String code;

    /**
     * Description of the response state
     */
    private String description;

    /**
     * Constructor.
     *
     * @param code to set
     * @param description to set
     */
    ResponseStateEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public static ResponseStateEnum createCustomResponseStateEnum(String code, String description) {
        KO_CUSTOM_TOKEN_MANAGER_EXCEPTION.code = code;
        KO_CUSTOM_TOKEN_MANAGER_EXCEPTION.description = description;
        return KO_CUSTOM_TOKEN_MANAGER_EXCEPTION;
    }
    
    public static ResponseStateEnum responseStateEnum(String n) {
        for (ResponseStateEnum c : values()) {
          if (c.code.equals(n)) {
            return c;
          }
        }
        // either throw the IAE or return null, your choice.
        throw new IllegalArgumentException(String.valueOf(n));
    }
    
    public class ResponseStateEnumId {
        
        public static final String PARAM_INIT = "%INIT%";
        public static final String PARAM_FIN = "%FIN%";
    }
}
