package com.isban.tokenmanager.integration.dto;

/**
 * Contains the flow decision for MasterCard and the media to show the OTP.
 *
 * @author realsec
 */
public class FlowAndMedia {

    /**
     * Flow decision
     */
    private String flowDecision;

    /**
     * Media to transfer the OTP
     */
    private String media;

    /**
     * Constructor with parameters.
     *
     * @param flowDecision Flow decision obtained.
     * @param media        Media to transfer the OTP.
     */
    public FlowAndMedia(String flowDecision, String media) {
        super();
        this.flowDecision = flowDecision;
        this.media = media;
    }

    /**
     * @return the flowDecision
     */
    public String getFlowDecision() {
        return flowDecision;
    }

    /**
     * @param flowDecision the flowDecision to set
     */
    public void setFlowDecision(String flowDecision) {
        this.flowDecision = flowDecision;
    }

    /**
     * @return the media
     */
    public String getMedia() {
        return media;
    }

    /**
     * @param media the media to set
     */
    public void setMedia(String media) {
        this.media = media;
    }
}