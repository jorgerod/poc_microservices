package com.isban.tokenmanager.integration.mdes;

public class NotifyServiceActivatedHttpResponse extends MdesApiCommonResponse {

}
