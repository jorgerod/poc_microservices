package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class AuthorizeWithdrawalRequest extends WithdrawalRequest {

    private String terminalId;
    private String commerceId;
    private String commerceName;
    private String commerceAddress;
    private String commerceCity;
    private String commerceState;
    private String commerceCountry;
    private String commercePostalCode;
    private String acquirerId;
    private String forwardingId;
    
    @ApiModelProperty(value = "Identification of the terminal for withdrawal", required = true)
    @Size(max = 10)
    public String getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    @ApiModelProperty(value = "Identification of the commerce for withdrawal.", required = true)
    @Size(max = 15)
    public String getCommerceId() {
        return commerceId;
    }
    public void setCommerceId(String commerceId) {
        this.commerceId = commerceId;
    }

    @ApiModelProperty(value = "Name of the commerce", required = false)
    @Size(max = 15)
    public String getCommerceName() {
        return commerceName;
    }
    public void setCommerceName(String commerceName) {
        this.commerceName = commerceName;
    }

    @ApiModelProperty(value = "Address of the commerce", required = true)
    @Size(max = 25)
    public String getCommerceAddress() {
        return commerceAddress;
    }
    public void setCommerceAddress(String commerceAddress) {
        this.commerceAddress = commerceAddress;
    }

    @ApiModelProperty(value = "City of the commerce", required = false)
    @Size(max = 15)
    public String getCommerceCity() {
        return commerceCity;
    }
    public void setCommerceCity(String commerceCity) {
        this.commerceCity = commerceCity;
    }

    @ApiModelProperty(value = "State of the commerce", required = false)
    @Size(max = 2)    
    public String getCommerceState() {
        return commerceState;
    }
    public void setCommerceState(String commerceState) {
        this.commerceState = commerceState;
    }

    @ApiModelProperty(value = "Country of the commerce. (ISO 3166-1 format)", required = true)
    @Size(max = 3)
    public String getCommerceCountry() {
        return commerceCountry;
    }
    public void setCommerceCountry(String commerceCountry) {
        this.commerceCountry = commerceCountry;
    }

    @ApiModelProperty(value = "Postal code of the commerce", required = false)
    @Size(max = 10)    
    public String getCommercePostalCode() {
        return commercePostalCode;
    }
    public void setCommercePostalCode(String commercePostalCode) {
        this.commercePostalCode = commercePostalCode;
    }

    @ApiModelProperty(value = "Indentifies the acquiring institution", required = true)
    @Size(max = 12)
    public String getAcquirerId() {
        return acquirerId;
    }
    public void setAcquirerId(String acquirerId) {
        this.acquirerId = acquirerId;
    }

    @ApiModelProperty(value = "Identifies the institution fordwarding a request", required = false)
    @Size(max = 12)
    public String getForwardingId() {
        return forwardingId;
    }
    public void setForwardingId(String forwardingId) {
        this.forwardingId = forwardingId;
    }
}
