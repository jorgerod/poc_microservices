package com.isban.tokenmanager.dto.mdes;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class CardAndTokenInfoDto extends CardInfoCommonDto {

    @ApiModelProperty(value = "Globally unique identifier for the token, as assigned by MDES.", required = true)
    @Size(max = 64)
    private String tokenUniqueReference;

    public String getTokenUniqueReference() {
        return tokenUniqueReference;
    }

    public void setTokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
    }

//    {
//        "card" : {
//        "accountNumber" : "5123456789012345",
//        "expiryMonth" : "12",
//        "expiryYear" : "15",
//        "source" : "CARD_ON_FILE",
//        "cardholderName" : "John Doe",
//        "securityCode" : "123",
//        “cardholderData”: {
//            "sourceIp" : "127.0.0.1",
//            "deviceLocation" : "38.63, -90.2"
//            }
//        },
//        "token" : {
//            "token" : "5345678901234521",
//            "expiryMonth" : "10",
//            "expiryYear" : "17"
//        }
//   }
}
