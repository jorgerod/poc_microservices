package com.isban.tokenmanager.dto;

import java.util.List;

public class GetPanResponse extends ResponseBase {

    private List<TokenDto> panRequestDto;

    public GetPanResponse() {
    }

    public GetPanResponse(String code, String description) {
        super(code, description);
    }

    public List<TokenDto> getTokenDto() {
        return panRequestDto;
    }

    public void setPanRequestDto(List<TokenDto> panRequestDto) {
        this.panRequestDto = panRequestDto;
    }

    @Override
    public String toString() {
        return "GetPanResponse [panRequestDto=" + panRequestDto + "]";
    }
}
