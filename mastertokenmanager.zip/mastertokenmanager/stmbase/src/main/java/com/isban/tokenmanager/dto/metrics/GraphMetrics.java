package com.isban.tokenmanager.dto.metrics;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class GraphMetrics {
    public String nodebase;
    public String path;
    public String cron;
    public int size;
    public long starttime;
    public Map<String,GraphMetric> metricstable = new ConcurrentHashMap<String,GraphMetric>();
    
    
    
    public String getNodebase() {
        return nodebase;
    }
    public void setNodebase(String nodebase) {
        this.nodebase = nodebase;
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path;
    }
    public String getCron() {
        return cron;
    }
    public void setCron(String cron) {
        this.cron = cron;
    }
    public int getSize() {
        return size;
    }
    public void setSize(int size) {
        this.size = size;
    }
    public long getStarttime() {
        return starttime;
    }
    public void setStarttime(long starttime) {
        this.starttime = starttime;
    }
    public Map<String,GraphMetric> getMetricstable() {
        return metricstable;
    }
    public void setMetricstable(Map<String,GraphMetric> metricstable) {
        this.metricstable = metricstable;
    }
}
