package com.isban.tokenmanager.dto;

public class IssuerTokenTypeUserDto extends LifeTimeDto {

    private String userId;
    private String roleId;

    public IssuerTokenTypeUserDto(String issuerId, String tokenTypeId, String userId, String roleId) {
        this(issuerId, tokenTypeId);
        this.userId = userId;
        this.roleId = roleId;
    }

    public IssuerTokenTypeUserDto(String issuerId, String tokenTypeId) {
        this.issuerId = issuerId;
        this.tokenTypeId = tokenTypeId;
    }

    public IssuerTokenTypeUserDto() {
        super();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }
}