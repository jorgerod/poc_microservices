package com.isban.tokenmanager.dto;

import java.util.Date;

import com.isban.tokenmanager.dto.mdes.BillingAddress;
import com.isban.tokenmanager.dto.mdes.CardholderData;

public class ItemDataDto {

    private String item;
    private String itemReferenceId = null;
    private String itemSource;
    private Date expirationItem;
    private String source;
    private String cardholderName;
    private String securityCode;
    private Date dataValidUntilTimestamp;
    private BillingAddress billingAddress;
    private CardholderData cardholderData;

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public Date getExpirationItem() {
        return expirationItem;
    }

    public void setExpirationItem(Date expirationItem) {
        this.expirationItem = expirationItem;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCardholderName() {
        return cardholderName;
    }

    public void setCardholderName(String cardholderName) {
        this.cardholderName = cardholderName;
    }

    public String getSecurityCode() {
        return securityCode;
    }

    public void setSecurityCode(String securityCode) {
        this.securityCode = securityCode;
    }

    public String getItemSource() {
        return itemSource;
    }

    public void setItemSource(String itemSource) {
        this.itemSource = itemSource;
    }

    public Date getDataValidUntilTimestamp() {
        return dataValidUntilTimestamp;
    }

    public void setDataValidUntilTimestamp(Date dataValidUntilTimestamp) {
        this.dataValidUntilTimestamp = dataValidUntilTimestamp;
    }

    public BillingAddress getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(BillingAddress billingAddress) {
        this.billingAddress = billingAddress;
    }

    public CardholderData getCardholderData() {
        return cardholderData;
    }

    public void setCardholderData(CardholderData cardholderData) {
        this.cardholderData = cardholderData;
    }

    public String getItemReferenceId() {
        return itemReferenceId;
    }

    public void setItemReferenceId(String itemReferenceId) {
        this.itemReferenceId = itemReferenceId;
    }

}
