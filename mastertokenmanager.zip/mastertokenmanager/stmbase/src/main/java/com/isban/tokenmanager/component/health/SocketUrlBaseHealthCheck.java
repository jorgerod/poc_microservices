package com.isban.tokenmanager.component.health;

import java.util.Arrays;

abstract public class SocketUrlBaseHealthCheck extends SocketBaseHealthCheck {
    abstract public String getUrl();
    
    private HostPort hostPort;
    
    public HostPort getHostPort(){
        if( hostPort != null ){ return hostPort; }
        hostPort = new HostPort();
        
        if( getUrl() == null ){ return hostPort; }
        String parts[] = getUrl().split( "[:/]+" );
        
        if(parts.length < 2 ){ return hostPort; }
        if(parts.length < 3 ){
            parts = Arrays.copyOf(parts, 3);
            parts[2] = "nan";
        }
        
        hostPort.host = parts[1];
        try {
            hostPort.port = Integer.parseInt( parts[2] );
            
        } catch( NumberFormatException e ) {
            String protocol = parts[0].toLowerCase();
            if( "https".equals(protocol) ){
                hostPort.port = 443;
                
            } else if( "ldap".equals(protocol) ){
                hostPort.port = 389;
            }
        }

        return hostPort;
    }
    
    @Override
    public String getHost() {
        return getHostPort().host;
    }

    @Override
    public int getPort() {
        return getHostPort().port;
    }
    
    public class HostPort{
        public String host = "localhost";
        public int port = 80;
    }
}
