@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.isban.com/tokenmanager/ws/model", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.isban.tokenmanager.ws.model;
