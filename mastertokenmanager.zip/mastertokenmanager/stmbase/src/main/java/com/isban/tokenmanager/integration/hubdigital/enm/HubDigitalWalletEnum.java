package com.isban.tokenmanager.integration.hubdigital.enm;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum HubDigitalWalletEnum {
    
    SAMSUNG_PAY("Samsung Pay"), 
    APPLE_PAY("Apple Pay"), 
    ANDROID_PAY("Android Pay");

    private static Map<String, HubDigitalWalletEnum> FORMAT_MAP = Stream.of(HubDigitalWalletEnum.values())
            .collect(Collectors.toMap(s -> s.formatted, Function.identity()));
    
    private static Map<String, HubDigitalWalletEnum> KEY_MAP = Stream.of(HubDigitalWalletEnum.values())
            .collect(Collectors.toMap(s -> s.name(), Function.identity()));

    private final String formatted;

    HubDigitalWalletEnum(String formatted) {
        this.formatted = formatted;
    }
    
    public String getFormatted() {
        return formatted;
    }

    @JsonCreator // This is the factory method and must be static
    public static HubDigitalWalletEnum fromString(String value) {
        HubDigitalWalletEnum hubDigitalWalletEnum = FORMAT_MAP.get(value) != null ? FORMAT_MAP.get(value) : KEY_MAP.get(value);
        if (hubDigitalWalletEnum == null) {
            throw new IllegalArgumentException(value + " has no corresponding value");
        }
        return hubDigitalWalletEnum;
    }

}
