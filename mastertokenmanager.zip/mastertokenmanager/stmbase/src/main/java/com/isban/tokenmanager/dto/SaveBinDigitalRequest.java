package com.isban.tokenmanager.dto;

import java.util.List;

public class SaveBinDigitalRequest{

    private List<BinDigitalDto> binDigitals;

    public List<BinDigitalDto> getBinDigitals() {
        return binDigitals;
    }

    public void setBinDigitals(List<BinDigitalDto> binDigitals) {
        this.binDigitals = binDigitals;
    }


}
