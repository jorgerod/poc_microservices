package com.isban.tokenmanager.dto.cardless;

import java.util.ArrayList;
import java.util.List;

public class TokenStateDto {

    private String stateValue;
    private String stateDescription;
    private List<String> navigatesTo = new ArrayList<>();

    public String getStateValue() {
        return stateValue;
    }

    public void setStateValue(String stateValue) {
        this.stateValue = stateValue;
    }

    public String getStateDescription() {
        return stateDescription;
    }

    public void setStateDescription(String stateDescription) {
        this.stateDescription = stateDescription;
    }

    public List<String> getNavigatesTo() {
        return navigatesTo;
    }

    public void setNavigatesTo(List<String> navigatesTo) {
        this.navigatesTo = navigatesTo;
    }

}
