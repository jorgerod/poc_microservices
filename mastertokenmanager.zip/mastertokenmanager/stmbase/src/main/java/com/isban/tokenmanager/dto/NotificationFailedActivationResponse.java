package com.isban.tokenmanager.dto;

public class NotificationFailedActivationResponse extends ResponseBase {

    public NotificationFailedActivationResponse() {
    }

    public NotificationFailedActivationResponse(String code, String description) {
        super(code, description);
    }
}
