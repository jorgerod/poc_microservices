package com.isban.tokenmanager.integration.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Card {

    private Integer id;
    private String tokenId;

    private String item;
    private String issuerid;
    private String tokenTypeId;

    private String customer;
    private String product;
    private String productName;
    private String sittarcode;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date lastmovementdate;

    private List<String> blockcodes;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date expirationdate;
    private String cardArtWallet;
    private String cardArtDefault;

    private String ticketRef;
    private String tokenRequestorId;
    private String deviceType;
    private String deviceName;
    private String deviceId;
    private String deviceNumber;
    private String panSource;

    private String deviceLanguageCode = null;
    private String deviceLocation = null;
    private String ipAddress = null;
    private String cardHolderWalletAccount = null;
    private String walletRiskAssessment = null;
    private String walletRiskAssessmentVersion = null;
    private String walletDeviceScore = null;
    private String walletAccountScore = null;
    private String walletReasonCode = null;

    private String tokenAssuranceLevel = null;
    private String tokenType = null;
    private String numberActiveTokensPan = null;
    private String numberInactiveTokens = null;
    private String numberSuspendedTokens = null;
    private String termAndConditions = null;
    private String termAndConditionsDate = null;

    private String accountnum;
    private String pvv;

    private Date issueDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getSittarcode() {
        return sittarcode;
    }

    public void setSittarcode(String sittarcode) {
        this.sittarcode = sittarcode;
    }

    public Date getLastmovementdate() {
        return lastmovementdate;
    }

    public void setLastmovementdate(Date lastmovementdate) {
        this.lastmovementdate = lastmovementdate;
    }

    public Date getExpirationdate() {
        return expirationdate;
    }

    public void setExpirationdate(Date expirationdate) {
        this.expirationdate = expirationdate;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getIssuerid() {
        return issuerid;
    }

    public void setIssuerid(String issuerid) {
        this.issuerid = issuerid;
    }

    public List<String> getBlockcodes() {
        return blockcodes;
    }

    public void setBlockcodes(List<String> blockcodes) {
        this.blockcodes = blockcodes;
    }

    public String getCardArtWallet() {
        return cardArtWallet;
    }

    public void setCardArtWallet(String cardArtWallet) {
        this.cardArtWallet = cardArtWallet;
    }

    public String getCardArtDefault() {
        return cardArtDefault;
    }

    public void setCardArtDefault(String cardArtDefault) {
        this.cardArtDefault = cardArtDefault;
    }

    public String getAccountnum() {
        return accountnum;
    }

    public void setAccountnum(String accountnum) {
        this.accountnum = accountnum;
    }

    public String getTicketRef() {
        return ticketRef;
    }

    public void setTicketRef(String ticketRef) {
        this.ticketRef = ticketRef;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getPanSource() {
        return panSource;
    }

    public void setPanSource(String panSource) {
        this.panSource = panSource;
    }

    public String getDeviceLanguageCode() {
        return deviceLanguageCode;
    }

    public void setDeviceLanguageCode(String deviceLanguageCode) {
        this.deviceLanguageCode = deviceLanguageCode;
    }

    public String getDeviceLocation() {
        return deviceLocation;
    }

    public void setDeviceLocation(String deviceLocation) {
        this.deviceLocation = deviceLocation;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getCardHolderWalletAccount() {
        return cardHolderWalletAccount;
    }

    public void setCardHolderWalletAccount(String cardHolderWalletAccount) {
        this.cardHolderWalletAccount = cardHolderWalletAccount;
    }

    public String getWalletRiskAssessment() {
        return walletRiskAssessment;
    }

    public void setWalletRiskAssessment(String walletRiskAssessment) {
        this.walletRiskAssessment = walletRiskAssessment;
    }

    public String getWalletRiskAssessmentVersion() {
        return walletRiskAssessmentVersion;
    }

    public void setWalletRiskAssessmentVersion(String walletRiskAssessmentVersion) {
        this.walletRiskAssessmentVersion = walletRiskAssessmentVersion;
    }

    public String getWalletDeviceScore() {
        return walletDeviceScore;
    }

    public void setWalletDeviceScore(String walletDeviceScore) {
        this.walletDeviceScore = walletDeviceScore;
    }

    public String getWalletAccountScore() {
        return walletAccountScore;
    }

    public void setWalletAccountScore(String walletAccountScore) {
        this.walletAccountScore = walletAccountScore;
    }

    public String getWalletReasonCode() {
        return walletReasonCode;
    }

    public void setWalletReasonCode(String walletReasonCode) {
        this.walletReasonCode = walletReasonCode;
    }

    public String getTokenAssuranceLevel() {
        return tokenAssuranceLevel;
    }

    public void setTokenAssuranceLevel(String tokenAssuranceLevel) {
        this.tokenAssuranceLevel = tokenAssuranceLevel;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getNumberActiveTokensPan() {
        return numberActiveTokensPan;
    }

    public void setNumberActiveTokensPan(String numberActiveTokensPan) {
        this.numberActiveTokensPan = numberActiveTokensPan;
    }

    public String getNumberInactiveTokens() {
        return numberInactiveTokens;
    }

    public void setNumberInactiveTokens(String numberInactiveTokens) {
        this.numberInactiveTokens = numberInactiveTokens;
    }

    public String getNumberSuspendedTokens() {
        return numberSuspendedTokens;
    }

    public void setNumberSuspendedTokens(String numberSuspendedTokens) {
        this.numberSuspendedTokens = numberSuspendedTokens;
    }

    public String getTermAndConditions() {
        return termAndConditions;
    }

    public void setTermAndConditions(String termAndConditions) {
        this.termAndConditions = termAndConditions;
    }

    public String getTermAndConditionsDate() {
        return termAndConditionsDate;
    }

    public void setTermAndConditionsDate(String termAndConditionsDate) {
        this.termAndConditionsDate = termAndConditionsDate;
    }

    public String getPvv() {
        return pvv;
    }

    public void setPvv(String pvv) {
        this.pvv = pvv;
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    @Override
    public String toString() {
        return "Card [id=" + id + ", tokenId=" + tokenId + ", item=" + item + ", issuerid=" + issuerid
                + ", tokenTypeId=" + tokenTypeId + ", customer=" + customer + ", product=" + product + ", productName="
                + productName + ", sittarcode=" + sittarcode + ", lastmovementdate=" + lastmovementdate
                + ", blockcodes=" + blockcodes + ", expirationdate=" + expirationdate + ", cardArtWallet="
                + cardArtWallet + ", cardArtDefault=" + cardArtDefault + ", ticketRef=" + ticketRef
                + ", tokenRequestorId=" + tokenRequestorId + ", deviceType=" + deviceType + ", deviceName=" + deviceName
                + ", deviceId=" + deviceId + ", deviceNumber=" + deviceNumber + ", panSource=" + panSource
                + ", deviceLanguageCode=" + deviceLanguageCode + ", deviceLocation=" + deviceLocation + ", ipAddress="
                + ipAddress + ", cardHolderWalletAccount=" + cardHolderWalletAccount + ", walletRiskAssessment="
                + walletRiskAssessment + ", walletRiskAssessmentVersion=" + walletRiskAssessmentVersion
                + ", walletDeviceScore=" + walletDeviceScore + ", walletAccountScore=" + walletAccountScore
                + ", walletReasonCode=" + walletReasonCode + ", tokenAssuranceLevel=" + tokenAssuranceLevel
                + ", tokenType=" + tokenType + ", numberActiveTokensPan=" + numberActiveTokensPan
                + ", numberInactiveTokens=" + numberInactiveTokens + ", numberSuspendedTokens=" + numberSuspendedTokens
                + ", termAndConditions=" + termAndConditions + ", termAndConditionsDate=" + termAndConditionsDate
                + ", accountnum=" + accountnum + ", pvv=" + pvv + ", issueDate=" + issueDate + "]";
    }
    
    

}
