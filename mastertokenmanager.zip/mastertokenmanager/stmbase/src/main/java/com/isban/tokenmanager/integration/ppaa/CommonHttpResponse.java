package com.isban.tokenmanager.integration.ppaa;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.isban.tokenmanager.dto.ResponseBase;

import io.swagger.annotations.ApiModelProperty;

public class CommonHttpResponse extends ResponseBase {
    
    private String status;
    
    @ApiModelProperty(value = "http status code", required = false)
    @Size(max = 3)
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @ApiModelProperty(value = "Allows to identify if the request is authorize or denied.", required = false)
    @Size(max = 4)
    @Override
    public String getCode() {
        return super.getCode();
    }
    
    @JsonProperty(value = "message")
    @ApiModelProperty(value = "Message adapted to the user's languaje in order to show it directly to him", required = false)
    @Size(max = 26)
    @Override
    public String getDescription() {
        return super.getDescription();
    }
    
    @Override
    public void setCode(String c) {
        super.setCode(c);
    }
    
    @Override
    public void setDescription(String d) {
        super.setDescription(d);
    }
}