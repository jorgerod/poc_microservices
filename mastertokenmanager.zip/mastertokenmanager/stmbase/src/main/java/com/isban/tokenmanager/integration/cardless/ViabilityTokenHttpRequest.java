package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class ViabilityTokenHttpRequest extends CardlessCommonHttpRequest {

    @ApiModelProperty(required = true)
    @Size(max = 10, min = 4)    
    private String customer;
    
    @ApiModelProperty(required = true)
    @Size(max = 20, min = 4)    
    private String contract;
    
    @ApiModelProperty(required = true)
    @Override
    public String getNrbe() {
        return super.getNrbe();
    }
    
    @ApiModelProperty(required = true)
    @Override
    public String getRequestorId() {
        return super.getRequestorId();
    }
    
    
    @ApiModelProperty(required = true)
    @Size(max = 12)    
    @Min(1)
    private String amount;
    
    @ApiModelProperty(required = true)
    @Size(min = 2, max = 3)   
    private String currency;

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getContract() {
        return contract;
    }

    public void setContract(String contract) {
        this.contract = contract;
    }
}
