package com.isban.tokenmanager.dto.mdes;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

public class CardAndTokenInfoDataDto {

    @ApiModelProperty(required = true)
    private CardInfoData card = null;

    @ApiModelProperty(required = true)
    private TokenDataDto token = null;

    @JsonIgnore
    private String tokenUniqueReference;

    public CardInfoData getCard() {
        return card;
    }

    public void setCard(CardInfoData card) {
        this.card = card;
    }

    public TokenDataDto getToken() {
        return token;
    }

    public void setToken(TokenDataDto token) {
        this.token = token;
    }

    public String getTokenUniqueReference() {
        return tokenUniqueReference;
    }

    public void setTokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
    }

}
