package com.isban.tokenmanager.integration.hubdigital.enm;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum ResponseInfoStatusEnum {
    
    OK("0000"), 
    ERROR_NO_RESULTS("2000"),
    ERROR_OPERATION_DENIED("4000"),
    ERROR_NO_OTHER_USES("4001"),
    ERROR_TOKEN_EXPIRED("4002"),
    ERROR_ICVV_VALIDATION("4003"),
    ERROR_EMV_VALIDATION("4010"),
    ERROR_MAC_VALIDATION("8000"),
    ERROR_INCORRECT_DECRYPT("8001"),
    ERROR_INVALID_OPERATION("8002"),
    ERROR_INVALID_INPUT_FORMAT("9000"),
    ERROR_INTERNAL_SERVER_ERROR("9099");
    
    private static Map<String, ResponseInfoStatusEnum> FORMAT_MAP = Stream.of(ResponseInfoStatusEnum.values())
            .collect(Collectors.toMap(s -> s.formatted, Function.identity()));
    
    private static Map<String, ResponseInfoStatusEnum> KEY_MAP = Stream.of(ResponseInfoStatusEnum.values())
            .collect(Collectors.toMap(s -> s.name(), Function.identity()));

    private final String formatted;

    ResponseInfoStatusEnum(String formatted) {
        this.formatted = formatted;
    }
    
    public String getFormatted() {
        return formatted;
    }

    @JsonCreator // This is the factory method and must be static
    public static ResponseInfoStatusEnum fromString(String value) {
        ResponseInfoStatusEnum responseInfoStatusEnum = FORMAT_MAP.get(value) != null ? FORMAT_MAP.get(value) : KEY_MAP.get(value);
        if (responseInfoStatusEnum == null) {
            throw new IllegalArgumentException(value + " has no corresponding value");
        }
        return responseInfoStatusEnum;
    }

}
