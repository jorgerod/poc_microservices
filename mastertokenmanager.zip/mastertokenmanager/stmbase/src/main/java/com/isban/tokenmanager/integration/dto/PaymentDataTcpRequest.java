package com.isban.tokenmanager.integration.dto;

public class PaymentDataTcpRequest extends TcpCommonDataRequest {

    private String ditem;
    private String expirationDPanDate;
    private String resolutorOperation;
    private String resolverCode;
    private String authId;
    private String amount;
    private String currency;
    private String commerceId;
    private String town;
    private String countryId;
    private String deviceType;
    private String paymentType;

    public PaymentDataTcpRequest() {
        super();
    }

    public PaymentDataTcpRequest(String operationId, String operationDateTime, String issuerId, String tokenTypeId, String tokenRequestorId,
            String pan, String expirationDatePan, String dataEntryMode, String ditem, String expirationDPanDate,
            String resolutorOperation, String resolverCode, String authId, String amount, String currency,
            String commerceId, String town, String countryId, String deviceType, String paymentType) {
        super(operationId, operationDateTime, issuerId, tokenTypeId, tokenRequestorId, pan, expirationDatePan, dataEntryMode);
        this.ditem = ditem;
        this.expirationDPanDate = expirationDPanDate;
        this.resolutorOperation = resolutorOperation;
        this.resolverCode = resolverCode;
        this.authId = authId;
        this.amount = amount;
        this.currency = currency;
        this.commerceId = commerceId;
        this.town = town;
        this.countryId = countryId;
        this.deviceType = deviceType;
        this.paymentType = paymentType;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    public String getExpirationDPanDate() {
        return expirationDPanDate;
    }

    public void setExpirationDPanDate(String expirationDPanDate) {
        this.expirationDPanDate = expirationDPanDate;
    }

    public String getResolutorOperation() {
        return resolutorOperation;
    }

    public void setResolutorOperation(String resolutorOperation) {
        this.resolutorOperation = resolutorOperation;
    }

    public String getResolverCode() {
        return resolverCode;
    }

    public void setResolverCode(String resolverCode) {
        this.resolverCode = resolverCode;
    }

    public String getAuthId() {
        return authId;
    }

    public void setAuthId(String authId) {
        this.authId = authId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCommerceId() {
        return commerceId;
    }

    public void setCommerceId(String commerceId) {
        this.commerceId = commerceId;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getCountryId() {
        return countryId;
    }

    public void setCountryId(String countryId) {
        this.countryId = countryId;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("PaymentDataTcpRequest [dpan=").append(ditem).append(", expirationDPanDate=")
                .append(expirationDPanDate).append(", resolutorOperation=").append(resolutorOperation)
                .append(", resolverCode=").append(resolverCode).append(", authId=").append(authId).append(", amount=")
                .append(amount).append(", currency=").append(currency).append(", commerceId=").append(commerceId)
                .append(", town=").append(town).append(", countryId=").append(countryId).append(", deviceType=")
                .append(deviceType).append(", paymentType=").append(paymentType).append("]");
        return builder.toString();
    }

}
