package com.isban.tokenmanager.dto;

public class NotificationCreatedTokenRequest extends NotificationTokenizationBaseRequest {

    private String ditem;
    private String expirationDateDpan;
    private String termsAndConditionsData;
    private String termsAndConditionsDateAndTime;

    public String getExpirationDateDpan() {
        return expirationDateDpan;
    }

    public void setExpirationDateDpan(String expirationDateDpan) {
        this.expirationDateDpan = expirationDateDpan;
    }

    public String getTermsAndConditionsData() {
        return termsAndConditionsData;
    }

    public void setTermsAndConditionsData(String termsAndConditionsData) {
        this.termsAndConditionsData = termsAndConditionsData;
    }

    public String getTermsAndConditionsDateAndTime() {
        return termsAndConditionsDateAndTime;
    }

    public void setTermsAndConditionsDateAndTime(String termsAndConditionsDateAndTime) {
        this.termsAndConditionsDateAndTime = termsAndConditionsDateAndTime;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("NotificationCreatedTokenRequest [ditem=").append(ditem).append(", expirationDateDpan=")
                .append(expirationDateDpan).append(", termsAndConditionsData=").append(termsAndConditionsData)
                .append(", termsAndConditionsDateAndTime=").append(termsAndConditionsDateAndTime).append("]");
        return builder.toString();
    }

}
