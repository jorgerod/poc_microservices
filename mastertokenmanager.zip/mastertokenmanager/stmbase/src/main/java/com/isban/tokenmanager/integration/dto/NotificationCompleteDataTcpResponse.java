package com.isban.tokenmanager.integration.dto;

public class NotificationCompleteDataTcpResponse extends TcpCommonDataResponse {

    public NotificationCompleteDataTcpResponse() {
        super();
    }

    public NotificationCompleteDataTcpResponse(NotificationCompleteDataTcpRequest request) {
        super(request.getOperationId(), request.getOperationDateTime());
    }

    @Override
    public String toString() {
        return "NotificationCompleteDataTcpResponse [getOperationId()=" + getOperationId() + ", getOperationDate()="
                + getOperationDateTime() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
                + ", hashCode()=" + hashCode() + "]";
    }
}
