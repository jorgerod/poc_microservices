package com.isban.tokenmanager.dto;

import java.util.List;

public class DeviceDto {

    private String deviceId = null;
    private String deviceExt = null;
    private String deviceType = null;
    private String deviceName = null;
    private String deviceLanguageCode = null;
    private String deviceNumber = null;
    private String deviceLocation = null;
    private String deviceSerialNumber = null;
    private String formFactor = null;// PHONE, TABLE or WATCH
    private String storageTechnology = null;// DEVICE_MEMORY,
                                            // DEVICE_MEMORY_PROTECTED_TPM, TEE,
                                            // SE, SERVER, VEE
    private String osName = null;// ANDROID, WINDOWS, TIZEN, IOS
    private String osVersion = null;
    private List<String> devicePaymentTypes = null;// NFC, DSRP, ECOMMERCE
    private String deviceImei = null;
    private String deviceMsidn = null;
    private String ipAddress = null;

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceExt() {
        return deviceExt;
    }

    public void setDeviceExt(String deviceExt) {
        this.deviceExt = deviceExt;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceLanguageCode() {
        return deviceLanguageCode;
    }

    public void setDeviceLanguageCode(String deviceLanguageCode) {
        this.deviceLanguageCode = deviceLanguageCode;
    }

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getDeviceLocation() {
        return deviceLocation;
    }

    public void setDeviceLocation(String deviceLocation) {
        this.deviceLocation = deviceLocation;
    }

    public String getDeviceSerialNumber() {
        return deviceSerialNumber;
    }

    public void setDeviceSerialNumber(String deviceSerialNumber) {
        this.deviceSerialNumber = deviceSerialNumber;
    }

    public String getFormFactor() {
        return formFactor;
    }

    public void setFormFactor(String formFactor) {
        this.formFactor = formFactor;
    }

    public String getStorageTechnology() {
        return storageTechnology;
    }

    public void setStorageTechnology(String storageTechnology) {
        this.storageTechnology = storageTechnology;
    }

    public String getOsName() {
        return osName;
    }

    public void setOsName(String osName) {
        this.osName = osName;
    }

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public List<String> getDevicePaymentTypes() {
        return devicePaymentTypes;
    }

    public void setDevicePaymentTypes(List<String> devicePaymentTypes) {
        this.devicePaymentTypes = devicePaymentTypes;
    }

    public String getDeviceImei() {
        return deviceImei;
    }

    public void setDeviceImei(String deviceImei) {
        this.deviceImei = deviceImei;
    }

    public String getDeviceMsidn() {
        return deviceMsidn;
    }

    public void setDeviceMsidn(String deviceMsidn) {
        this.deviceMsidn = deviceMsidn;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

}
