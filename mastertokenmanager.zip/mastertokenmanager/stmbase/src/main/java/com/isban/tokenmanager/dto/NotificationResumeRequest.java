package com.isban.tokenmanager.dto;

public class NotificationResumeRequest extends NotificationCommonDataRequest {

    public NotificationResumeRequest() {
    }


}
