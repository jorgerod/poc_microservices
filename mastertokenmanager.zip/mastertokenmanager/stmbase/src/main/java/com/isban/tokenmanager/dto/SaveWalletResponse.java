package com.isban.tokenmanager.dto;

public class SaveWalletResponse extends ResponseBase {

    private WalletDto walletDto;

    public SaveWalletResponse() {
    }

    public SaveWalletResponse(String code, String description) {
        super(code, description);
    }

    public WalletDto getWalletDto() {
        return walletDto;
    }

    public void setWalletDto(WalletDto walletDto) {
        this.walletDto = walletDto;
    }

    @Override
    public String toString() {
        return "SaveWalletResponse [walletDto=" + walletDto + "]";
    }

}
