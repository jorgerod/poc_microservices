package com.isban.tokenmanager.integration.cardless;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class RequestTokenHttpResponse extends CardlessCommonResponse {

    String tokenId;
    String tokenKey;
    String expireTime;

    public RequestTokenHttpResponse() {
        super();
    }

    public RequestTokenHttpResponse(String tokenId, String tokenKey, String expireTime) {
        super();
        this.tokenId = tokenId;
        this.tokenKey = tokenKey;
        this.expireTime = expireTime;
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    @JsonIgnore()
    public String getTokenKey() {
        return tokenKey;
    }

    public void setTokenKey(String tokenKey) {
        this.tokenKey = tokenKey;
    }

    public String getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(String expireTime) {
        this.expireTime = expireTime;
    }

}
