package com.isban.tokenmanager.util;

public class Constants {

    public static final String TOKEN_MANAGER = "TOKEN_MANAGER";
    public static final String WALLET = "WALLET";
    public static final String SWITCH = "SWITCH";
    public static final String CMS = "CMS";
    public static final String CANALES = "CANALES";
    public static final String TSP = "TSP";


    // RESPONSE
    public static final int CODE_RESPONSE_LENGTH = 3;
    public static final int DES_RESPONSE_LENGTH = 100;

    // HEADER
    public static final int SERVER_LENGTH = 4;
    public static final int PROTOCOL_VERSION_LENGTH = 2;
    public static final int MESSAGE_TYPE_LENGTH = 4;
    public static final int ORIGIN_NETWORK_LENGTH = 6;

    // SWITCHBASE
    public static final int OPERATION_ID_LENGTH = 19;
    public static final int OPERATION_DATE_TIME_LENGTH = 17;
    public static final int ISSUER_LENGTH = 4;
    public static final int TOKEN_REQUESTOR_ID_LENGTH = 4;
    public static final int ITEM_LENGTH = 22;
    public static final int EXPIRATION_PAN_DATE_LENGTH = 4;
    public static final int DATA_ENTRY_MODE_LENGTH = 12;

    public static final int NETWORK_SOURCE_LENGTH = 6;
    public static final int WALLET_TYPE_LENGTH = 2;
    public static final int RESOLVER_OPERATION_LENGTH = 2;
    public static final int RESOLVER_CODE_LENGTH = 3;
    public static final int DPAN_LENGTH = 22;
    public static final int DPAN_TYPE_LENGTH = 2;
    public static final int AUTH_ID_LENGTH = 6;
    public static final int OPERATION_TYPE_LENGTH = 2;
    public static final int OPERATION_DATA_LENGTH = 19;
    public static final int USE_TYPE_LENGTH = 2;

    public static final int EXPIRATION_DPAN_DATE_LENGTH = 4;
    public static final int AMOUNT_LENGTH = 12;
    public static final int CURRENCY_LENGTH = 3;
    public static final int COMMERCE_ID_LENGTH = 25;
    public static final int TOWN_LENGTH = 13;
    public static final int COUNTRY_ID_LENGTH = 3;

    public static final int OPERATION_DATE_LENGTH = 8;
    public static final int OPERATION_HOUR_LENGTH = 6;

    // Payment
    public static final int PAYMENT_TYPE_LENGTH = 2;

    // Register
    public static final int ACTIVATION_CODE_LENGTH = 8;
    public static final int ACTIVATION_CODE_EXPIRATION_LENGTH = 10;
    public static final int ACTIVATION_METHOD_LENGTH = 2;
    public static final int ACTIVATION_VERIFICATION_RESULT_LENGTH = 2;

    // Notification(s)
    public static final int DEVICE_ID_LENGTH = 10;
    public static final int DEVICE_EXT_LENGTH = 50;
    public static final int DPAN_EVENT_RESULT_LENGTH = 3;

    // Flow decision
//    public static final String FLOW_DECISION_GREEN = "green";
//    public static final String FLOW_DECISION_YELLOW = "yellow";
//    public static final String FLOW_DECISION_RED = "red";
//    public static final String FLOW_DECISION_GREEN_CODE = "0";
//    public static final String FLOW_DECISION_YELLOW_CODE = "1";
//    public static final String FLOW_DECISION_RED_CODE = "2";

    // GetFlowAndMedia
    public static final int TICKET_REF_LENGTH = 32;
    public static final int REQUEST_ID_LENGTH = 15;
    public static final int REQUEST_INFO_ID_LENGTH = 15;
    public static final int REQUEST_RAW_INFO_LENGTH = 8192;
    public static final int TOKEN_INFO_ID_LENGTH = 15;
    public static final int TOKEN_RAW_INFO_LENGTH = 8192;
    public static final int TOKEN_REFERENCE_ID_LENGTH = 64;
    public static final int DEVICE_TYPE_LENGTH = 2;
    public static final int DEVICE_NUMBER_LENGTH = 15;
    public static final int DEVICE_LANGUAGE_CODE_LENGTH = 3;
    public static final int DEVICE_NAME_LENGTH = 20;
    public static final int ITEM_SOURCE_LENGTH = 2;

    public static final int DECISION_LENGTH = 1;
    public static final int DECISION_MADE_BY_LENGHT = 1;
    public static final int CARDHOLDER_WALLET_ACCOUNT_ID_LENGHT = 64;

    public static final int TOKEN_TYPE_EXT_LENGTH = 2;
    public static final int NUMBER_ACTIVE_TOKENS_LENGTH = 2;
    public static final int NUMBER_ACTIVATION_ATTEMPS_LENGTH = 1;
    public static final int DEVICE_INFO_LENGTH = 22;
    public static final int PAYMENT_CARD_DATA_LENGTH = 20;
    public static final int FLOW_DECISION_LENGTH = 30;
    public static final int TYPE_MEDIA_LENGTH = 2;
    public static final int DESCRIPTION_RESPONSE_LENGTH = 50;

    public static final int TERMS_AND_CONDITIONS_DATA_LENGTH = 32;
    public static final int TERMS_AND_CONDITIONS_DATE_AND_TIME_LENGTH = 32;

    public static final String INIT_MEDIA_VALUES = "{";
    public static final String END_MEDIA_VALUES = "}";
    public static final String SPLIT_CHARACTER_VALUES = "|";
    public static final String WHITE_CHAR = " ";
    public static final String CSV_SPLIT_CHARACTER = ";";

    // Visa Codes
    public static final String OK_VISA_CODE = "00";
    public static final String KO_VISA_CODE = "01";

    // PAYMENT TYPE
    public static final String PAYMENT_TYPE_PAYMENT = "00";
    public static final String PAYMENT_TYPE_REFUND = "20";

    // MDES ACTIONS
    public static final String MDES_ACTION_SUSPEND = "suspend";
    public static final String MDES_ACTION_RESUME = "unsuspend";
    public static final String MDES_ACTION_DELETE = "delete";
    public static final String MDES_ACTION_REMAP = "swap";
    public static final String MDES_ACTION_UPDATE_EXP_DATE = "swap";

    // Data base
    public static final int ISSUER_ID_LENGTH = 4;
    public static final int TSP_ID_LENGTH = 4;
    public static final int REQUEST_CLIENT_ID_LENGTH = 20;
    public static final int PAN_REQUEST_PAN_LENGTH = 22;
    public static final int PAN_REQUEST_ACCOUNT_NUMBER_LENGTH = 20;
    public static final int ISSUER_PRODUCT_ID_LENGTH = 20;
    public static final int REGISTRATION_EVENT_ID_LENGTH = 15;
    public static final int TAG_EVENT_ID_LENGTH = 3;
    public static final int TYPE_MESSAGE_ID_LENGTH = 3;
    public static final int TYPE_ALERT_ID_LENGTH = 3;
    public static final int SERVICE_ID_LENGTH = 3;
    public static final int BRAND_ID_LENGTH = 3;
    public static final int NOTIFICATION_ACTION_ID_LENGTH = 3;
    public static final int TOKEN_STATE_ID_LENGTH = 3;
    public static final int TSP_SYNC_STATE_ID_LENGTH = 3;
    public static final int BLOCK_ID_LENGTH = 2;
    public static final int BLOCK_DESC_LENGTH = 50;
    public static final int ORIGIN_MESSAGE_ID_LENGTH = 2;
    public static final int SIT_CARD_ID_LENGTH = 2;
    public static final int SIT_CARD_DESC_LENGTH = 50;
    public static final int PRODUCT_ID_LENGTH = 20;
    public static final int PRODUCT_DESC_LENGTH = 50;
    public static final int BIN_ID_LENGTH = 10;
    public static final int TYPE_BIN_ID_LENGTH = 3;
    public static final int MIN_PAN_LENGTH = 22;
    public static final int MAX_PAN_LENGTH = 22;
    public static final int DELIVERY_METHOD_ID_LENGTH = 2;
    public static final int MESSAGE_CODE_LENGTH = 20;
    public static final int PRIORITY_LENGTH = 4;
    public static final int ACCOUNT_NUMBER = 30;

    public static final int DEVICE_LOCATION_LENGTH = 25;
    public static final int IP_ADDRESS_LENGTH = 15;
    public static final int CARD_HOLDER_WALLET_ACCOUNT_LENGTH = 64;
    public static final int WALLET_RISK_ASSESSMENT_LENGTH = 1;
    public static final int WALLET_RISK_ASSESSMENT_VERSION_LENGTH = 10;
    public static final int WALLET_DEVICE_SCORE_LENGTH = 2;
    public static final int WALLET_ACCOUNT_SCORE_LENGTH = 2;
    public static final int WALLET_REASON_CODE_LENGTH = 30;
    public static final int TOKEN_ASSURANCE_LEVEL_LENGTH = 2;
    public static final int NUMBER_ACTIVE_TOKENS_PAN_LENGTH = 2;
    public static final int NUMBER_INACTIVE_TOKENS_LENGTH = 2;
    public static final int NUMBER_SUSPENDED_TOKENS_LENGTH = 2;
    public static final int TERM_AND_CONDITIONS_LENGTH = 64;
    public static final int TERM_AND_CONDITIONS_DATE_LENGTH = 32;
    public static final int TIME_WAIT_LENGTH = 3;
    public static final int REGISTRATION_EVENT_STATE_ID_LENGTH = 3;
    public static final int OBSERVATIONS_LENGTH = 10000;
    public static final int EVENT_ID_LENGTH = 3;
    public static final int EVENT_TYPE_ID_LENGTH = 3;
    public static final int ALERT_DEF_ID_LENGTH = 3;
    public static final int TIME_WAIT_NOTIFICATION_LENGTH = 3;
    public static final int SEND_METHOD_ID_LENGTH = 2;
    public static final int DESCRIPTION_LENGTH = 100;
    public static final int ROLE_ID_LENGTH = 4;
    public static final int NAME_LENGTH = 50;
    public static final int VALUE_LENGTH = 200;
    public static final int SFTP_TYPE_ID_LENGTH = 1;
    public static final int COMPANY_LENGTH = 3;
    public static final int TOKEN_EVENT_RESULT_LENGTH = 2;
    public static final int NOTIFICATION_TYPE_ID_LENGTH = 1;
    public static final int USER_ID_LENGTH = 20;
    public static final int TYPE_DOC_LENGTH = 3;
    public static final int DOC_LENGTH = 15;
    public static final int USER_EXT_LENGTH = 64;
    public static final int PVV_LENGTH = 5;
    public static final int TRANSACTION_ID_LENGTH = 20;
    public static final int TICKET_TOKEN_ID_LENGTH = 10;

    public static final int TOKEN_TYPE_ID_LENGTH = 1;
    //public static final int PAN_REFERENCE_ID_LENGTH = 48;
    public static final int ITEM_REFERENCE_ID_LENGTH = 48;
    public static final int CORRELATION_ID_LENGTH = 32;
    public static final int BRANCH_OFFICE_LENGTH = 4;
    public static final int CURRENCY_CODE_LENGTH = 3;
    public static final int PHONE_NUMBER_LENGTH = 15;
    public static final int TERMINAL_ID_LENGTH = 8;
    public static final int COMMENTS_LENGTH = 30;
    public static final int AUTHORIZATION_CODE = 19;

    
    // Incoming
    public static final int PAYMENT_INIT_CHANNEL = 2;

    // Remap
    public static final int REMAP_DATE_MAX_LENGTH = 10;
    public static final String BATCH_DATE_FORMAT = "yyMM";

    // VISA Actions
    // TODO Comprobar en integracion con VISA si valor debe ser numerico o
    // string
    public static final String VEPTS_ACTION_DELETE = "3701";
    public static final String VEPTS_ACTION_SUSPEND = "3702";
    public static final String VEPTS_ACTION_RESUME = "3703";
    public static final String VEPTS_ACTION_ACTIVATE = "3713"; // Call center
    public static final String VEPTS_ACTION_UPDATE_PAN_EXPIRY_DATE = "3720";
    public static final String VEPTS_ACTION_REPLACE_PAN_FOR_TOKEN = "3721";

    // Channel Suspicious fraud
    public static final String CHANNEL_SUSPICIOUS_FRAUD_OK = "0";
    public static final String CHANNEL_SUSPICIOUS_FRAUD_SUSPECT = "1";
    public static final String CHANNEL_SUSPICIOUS_FRAUD_BLOCKED = "2";

    // NOTIFICATIONS TO CLIENT
    public static final String TOKEN_EVENT_RESULT_KO_OTP_EXPIRED = "01";
    public static final String TOKEN_EVENT_RESULT_KO_OTP_RETRIES_EXCEEDED = "02";
    public static final String TOKEN_EVENT_RESULT_KO_OTP_FAILED = "03";

    public static final String TYPE_MESSAGE_TOKEN_EVENT_RESULT_KO_OTP_EXPIRED = "003";
    public static final String TYPE_MESSAGE_TOKEN_EVENT_RESULT_KO_OTP_RETRIES_EXCEEDED = "004";
    public static final String TYPE_MESSAGE_TOKEN_EVENT_RESULT_KO_OTP_FAILED = "005";

    // ROLE SUPER_ADMIN
    public static final String ROLE_SUPER_ADMIN_ID = "10";

    public static final Integer DEFAULT_MAX_TOKENS = 9999;
    public static final Integer DEFAULT_NUM_DAYS_USAGE = 9999;
    public static final Integer DEFAULT_NUM_DAYS_VALID = 0;

    public static final Integer DEFAULT_NUM_MAX_ACTIVATION_ATTEMPTS_VALID = 0;
    public static final Integer DEFAULT_NUM_MAX_ACTIVE_TOKENS_VALID = 0;
    public static final Integer DEFAULT_NUM_MAX_AMOUNT_VALID = 0;

    public static final String TOKEN_STATUS_NOT_DIGITALIZED = "NO";

    // CUSTOMER
    public static final int CUSTOMER_ID_LENGTH = 10;
    public static final int CUSTOMER_EXT_LENGTH = 20;
    public static final int CUSTOMER_DOC_LENGTH = 10;
    public static final int CUSTOMER_TYPE_DOC_LENGTH = 10;
    public static final int CUSTOMER_NAME_LENGTH = 50;
    public static final int CUSTOMER_SURNAME_LENGTH = 50;

    // EXTRA TAR
    public static final int PROCESSING_CODE_LENGTH = 6;
    public static final int AMOUNT_TRANSACTION_LENGTH = 12;
    public static final int AMOUNT_CARDHOLDER_BILLING_LENGTH = 12;
    public static final int TRANSMISSION_DATE_AND_TIME_LENGTH = 10;
    public static final int CONVERSION_RATE_LENGTH = 8;
    public static final int MERCHANTTYPE_LENGTH = 4;
    public static final int ACQUIRING_INSTITUTION_COUNTRYCODE_LENGTH = 3;
    public static final int POINT_OF_SERVICE_CONDITION_CODE_LENGTH = 2;
    public static final int ACQUIRINGINSTITUTIONIDENTIFICATIONCODE_LENGTH = 11;
    public static final int RETRIEVALREFERENCENUMBER_LENGTH = 12;
    public static final int CARDACCEPTORIDENTIFICATIONCODE_LENGTH = 15;
    public static final int CARDACCEPTORNAMELOCATION_LENGTH = 40;
    public static final int ADDRESSVERIFICATIONRESULTCODE_LENGTH = 1;
    public static final int CVV2RESULTCODE_LENGTH = 1;
    public static final int CURRENCYCODETRANSACTION_LENGTH = 3;
    public static final int CURRENCYCODECARDHOLDERBILLING_LENGTH = 3;
    public static final int TRANSACTIONIDENTIFIER_LENGTH = 15;
    public static final int NETWORKIDENTIFICATIONCODE_LENGTH = 4;
    public static final int MESSAGEREASONCODE_LENGTH = 4;
    public static final int POSTALCODE_LENGTH = 9;
    public static final int CARDHOLDERADDRESS_LENGTH = 40;
    public static final int UKCOMPRESSEDAVSDATA_LENGTH = 14;
    public static final int ADDRESSVERIFICATIONSERVICE_LENGTH = 2;
    public static final int CVC2_LENGTH = 3;
    public static final int POSTRANSACTIONSTATUS_LENGTH = 1;
    public static final int RECORDDATA_LENGTH = 120;
    public static final int TRANSACTIONCATEGORYCODE_LENGTH = 1;
    public static final int PAYMENTINITIATORCHANNEL_LENGTH = 2;
    public static final int TOKENASSURANCELEVEL_LENGTH = 2;
    public static final int TOKENTYPE_LENGTH = 2;
    public static final int NUMBERACTIVETOKENSPAN_LENGTH = 2;
    public static final int NUMBERINACTIVETOKENS_LENGTH = 2;
    public static final int NUMBERSUSPENDEDTOKENS_LENGTH = 2;
    public static final int VISATOKENSCORE_LENGTH = 2;
    public static final int PANREFERENCEID_LENGTH = 32;
    public static final int CVV2ATHORIZATIONREQUESTDATA_LENGTH = 6;
    public static final int PRIMARYACCOUNTNUMBERSOURCE_LENGTH = 1;
    public static final int CARDHOLDERNAME_LENGTH = 27;
    public static final int PAYMENTAPPLICATIONINSTANCEID_LENGTH = 48;
    public static final int VISATOKENDECISIONING_LENGTH = 2;
    public static final int WALLET_ACCOUNT_EMAIL_ADDRESS_LENGTH = 32;
    // RULE
    public static final int RULE_ID_LENGTH = 2;

    // ACN

    public static final int PAN_REFERENCE_ID_LENGTH = 32;
    public static final int WP_REQUEST_ID_LENGTH = 64;
    public static final int WP_CONVERSATION_ID_LENGTH = 64;
    public static final int WALLET_ACCOUNT_ID_LENGTH = 32;
    public static final int LIFE_CYCLE_TRACE_ID_LENGTH = 15;
    public static final int TOKEN_LENGTH = 19;
    public static final int SECURE_ELEMENT_ID_LENGTH = 48;
    public static final int VERSION_LENGTH = 32;
    public static final int ENCRYPTION_KEY_INDEX_LENGTH = 8;
    public static final int ENCRYPTION_DATA_BLOB_LENGTH = 512;
    public static final int TRANSACTION_CATEGORY_CODE_LENGTH = 1;
    public static final int POINT_OF_SERVICE_DATA_LENGTH = 1;
    public static final int PAYMENT_INITIATOR_CHANNEL_LENGTH = 2;
    
    
    //ISSUERS
    public static final String ISSUER_SANTANDER_CONSUMER_BANK = "3293";
    
    //TOKEN REQUESTOR
    public static final String TR_SANTANDER_CONSUMER_BANK = "0009";
    

    public static final String PATTERN_DATETIME = "^(-?(?:[1-9][0-9]*)?[0-9]{4})-(1[0-2]|0[1-9])-(3[01]|0[1-9]|[12][0-9])T(2[0-3]|[01][0-9]):([0-5][0-9]):([0-5][0-9])(\\.[0-9]+)?(Z|[+-](?:2[0-3]|[01][0-9]):[0-5][0-9])?$";

}
