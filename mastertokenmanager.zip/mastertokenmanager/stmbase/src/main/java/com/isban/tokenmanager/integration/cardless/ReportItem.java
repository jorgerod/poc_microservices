package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class ReportItem {

    private String branchOffice;
    private String customerId;
    private String terminalId;
    private String contract;
    private Integer amount;
    private String dateOfRequest;
    private String timeOfRequest;
    private String status;
    private String timeOfStatus;

    @ApiModelProperty(notes = "Branch Office that asks the change", required = true)
    @Size(max = 4)
    public String getBranchOffice() {
        return branchOffice;
    }
    public void setBranchOffice(String branchOffice) {
        this.branchOffice = branchOffice;
    }

    @ApiModelProperty(notes = "Id of a customer", required = true)
    @Size(max = 10)
    public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    @ApiModelProperty(notes = "", required = true)
    @Size(max = 10)
    public String getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    @ApiModelProperty(notes = "", required = true)
    @Size(max = 18)
    public String getContract() {
        return contract;
    }
    public void setContract(String contract) {
        this.contract = contract;
    }

    @ApiModelProperty(notes = "", required = true)
    public Integer getAmount() {
        return amount;
    }
    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    @ApiModelProperty(notes = "", required = true)
    @Size(max = 10)
    public String getDateOfRequest() {
        return dateOfRequest;
    }
    public void setDateOfRequest(String dateOfRequest) {
        this.dateOfRequest = dateOfRequest;
    }

    @ApiModelProperty(notes = "", required = true)
    @Size(max = 5)
    public String getTimeOfRequest() {
        return timeOfRequest;
    }
    public void setTimeOfRequest(String timeOfRequest) {
        this.timeOfRequest = timeOfRequest;
    }

    @ApiModelProperty(notes = "", required = true)
    @Size(max = 4)
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    @ApiModelProperty(notes = "", required = true)
    @Size(max = 5)
    public String getTimeOfStatus() {
        return timeOfStatus;
    }
    public void setTimeOfStatus(String timeOfStatus) {
        this.timeOfStatus = timeOfStatus;
    }

}
