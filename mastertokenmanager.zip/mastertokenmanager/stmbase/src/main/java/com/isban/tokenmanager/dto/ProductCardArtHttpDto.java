package com.isban.tokenmanager.dto;

public class ProductCardArtHttpDto{

    private String issuerId;
    private String tokenTypeId;
    private String productId;
    private String startDate;
    private String cardArt;
    private String cardArtTag;

    public ProductCardArtHttpDto() {
    }

    public ProductCardArtHttpDto(String issuerId, String tokenTypeId, String productId, String date, String cardart, String cardArtTag) {
        this.issuerId = issuerId;
        this.tokenTypeId = tokenTypeId;
        this.productId = productId;
        this.startDate = date;
        this.cardArt = cardart;
        this.cardArtTag = cardArtTag;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getCardArt() {
        return cardArt;
    }

    public void setCardArt(String cardArt) {
        this.cardArt = cardArt;
    }

    public String getCardArtTag() {
        return cardArtTag;
    }

    public void setCardArtTag(String cardArtTag) {
        this.cardArtTag = cardArtTag;
    }
}
