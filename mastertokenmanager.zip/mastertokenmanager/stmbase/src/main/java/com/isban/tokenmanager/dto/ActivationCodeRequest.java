package com.isban.tokenmanager.dto;

public class ActivationCodeRequest extends ModelBaseDto {

    private String item;
    private String itemReferenceId;
    private String activationCode;
    private String tokenReferenceId;
    private String activationCodeExpiry;
    private String activationMethod;

    public ActivationCodeRequest() {
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getActivationCode() {
        return activationCode;
    }

    public void setActivationCode(String activationCode) {
        this.activationCode = activationCode;
    }

    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    public String getActivationCodeExpiry() {
        return activationCodeExpiry;
    }

    public void setActivationCodeExpiry(String activationCodeExpiry) {
        this.activationCodeExpiry = activationCodeExpiry;
    }

    public String getActivationMethod() {
        return activationMethod;
    }

    public void setActivationMethod(String activationMethod) {
        this.activationMethod = activationMethod;
    }

    public String getItemReferenceId() {
        return itemReferenceId;
    }

    public void setItemReferenceId(String itemReferenceId) {
        this.itemReferenceId = itemReferenceId;
    }

}
