package com.isban.tokenmanager.service.security.impl;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;

import org.springframework.stereotype.Service;

import com.isban.tokenmanager.service.security.CryptographicVeptsService;

@Service(value = "cryptographicVeptsServiceImpl")
public class CryptographicVeptsServiceImpl extends CryptographicBase implements CryptographicVeptsService {
    @Override
    public String prepad( String value ){
        String prepadRandomPart = createBase58RandomId( 4 );
        String ret = prepad( value, prepadRandomPart );
        return ret;
    }

    @Override
    public String unprepad( String value ) {
        String ret = null;
        if( value == null ){ return ret; }
        
        try {
            String lengthValue = value.substring( 6, 8 );
            int length = Integer.parseInt(lengthValue);
            ret = value.substring( 8, 8 + length );
            
        } catch( Exception e ) {
        }
        
        return ret;
    }
    
    @Override
    public byte[] encrypt( EncSkcInput input4enc ) {
        byte ret[] = null;
        if( input4enc == null ){ return ret; }
        if( input4enc.msg == null ){ return ret; }
        if( input4enc.secretKey == null ){ return ret; }
        
        //prepad
        String input4encMsgStr = new String( input4enc.msg );
        String input4encMsgPaddedStr = prepad( input4encMsgStr );
        
        //encrypt
        EncSkcInput input4encRaw = new EncSkcInput();
        input4encRaw.msg = input4encMsgPaddedStr.getBytes();
        input4encRaw.secretKey = input4enc.secretKey;
        ret = encryptRaw( input4encRaw );
        
        return ret;
    }

    public byte[] encryptRaw( EncSkcInput input4enc ) {
        byte ret[] = null;
        if( input4enc == null ){ return ret; }
        if( input4enc.msg == null ){ return ret; }
        if( input4enc.secretKey == null ){ return ret; }
        
        try {
            Cipher cipher = Cipher.getInstance( "DESede/CBC/Nopadding" );
            IvParameterSpec ivParamSpec = new IvParameterSpec( createIvBytes( input4enc.secretKey ));
            cipher.init( Cipher.ENCRYPT_MODE, input4enc.secretKey, ivParamSpec );
            ret = cipher.doFinal( input4enc.msg );
            
        } catch( InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | 
                 InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e ) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    @Override
    public byte[] decrypt( DecSkcInput input4dec ) {
        byte retPadded[] = null;
        byte ret[] = null;
        if( input4dec == null ){ return ret; }
        if( input4dec.encryptedMsg == null ){ return ret; }
        if( input4dec.secretKey == null ){ return ret; }
        
        try {
            //decrypt
            Cipher cipher = Cipher.getInstance( "DESede/CBC/Nopadding" );
            IvParameterSpec ivParamSpec = new IvParameterSpec( createIvBytes( input4dec.secretKey ) );
            cipher.init( Cipher.DECRYPT_MODE, input4dec.secretKey, ivParamSpec );
            retPadded = cipher.doFinal( input4dec.encryptedMsg );
            
        } catch( InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | 
                 InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e ) {
            e.printStackTrace();
        }
        if( retPadded == null ){ return ret; }
        
        //unprepad
        String retStr, retPaddedStr = new String( retPadded );
        retStr = unprepad(retPaddedStr);
        if( retStr == null ){ return ret; }
        
        ret = retStr.getBytes();
        return ret;
    }
    
    @Override
    public SecretKey createSecretKey( byte[] secretKeyBytes ) {
        SecretKey ret = null;
        if( secretKeyBytes == null ){ return ret; }
        
        byte secretKeyBytesfinal[];
        try {
            if( secretKeyBytes.length == 16 ){ //2 8bytes parts ,,, using 1st+2nd+2nd
                secretKeyBytesfinal = new byte[24];
                System.arraycopy( secretKeyBytes, 0, secretKeyBytesfinal, 0, 16 );
                System.arraycopy( secretKeyBytes, 0, secretKeyBytesfinal, 16, 8 );
                
            } else { //3 8bytes parts ,,, using 1st+2nd+3rd
                secretKeyBytesfinal = secretKeyBytes;
            }
            
            DESedeKeySpec keyspec = new DESedeKeySpec( secretKeyBytesfinal );
            ret = getSecretKeyFactory().generateSecret( keyspec );

        } catch( InvalidKeyException | InvalidKeySpecException e ) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    byte[] createIvBytes( SecretKey secretKey ) {
        byte ret[] = null;
        if( secretKey == null ){ return ret; }
        
        byte secretKeyBytes[] = secretKey.getEncoded();
        if( secretKeyBytes.length < 8 ){ return ret; }
        
        ret = new byte[8];
        System.arraycopy(secretKeyBytes, 0, ret, 0, 8);
        
        return ret;
    }
    
    SecretKeyFactory keyfactory;
    SecretKeyFactory getSecretKeyFactory(){
        if( keyfactory != null ){ return keyfactory; }
        try {
            keyfactory = SecretKeyFactory.getInstance( "DESede" );
            
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        
        return keyfactory;
    }
    
    public String prepad( String value, String prepadRandomPart ){
        String ret = "";
        if( value == null ){ return ret; }
        if( prepadRandomPart == null ){ return ret; }
        
        ret = ret + "  " + prepadRandomPart + value.length() + value;
        ret = ret + createFillPart( ret );

        return ret;
    }
    
    public String createFillPart( String value ){
        String ret = "";
        if( value == null ){ return ret; }
        if( value.isEmpty() ){ return ret; }
        
        int valueLength = value.length();
        int valueLengthMod8 = valueLength % 8;
        if( valueLengthMod8 == 0 ){ return ret; }
        
        int sz = 8 - valueLengthMod8;
        for( int i=0 ; i<sz ; i++ ) {
            ret = ret + "!";
        }
        
        return ret;
    }
}
