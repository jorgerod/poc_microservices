package com.isban.tokenmanager.integration.hubdigital;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;

public class HubDigitalInfoResponse extends HubDigitalInfoBase {

    @ApiModelProperty(required = true, value = "Result of the request")
    private String status;

    @ApiModelProperty(required = false, value = "Array with the list of methods to use in the current registration process.")
    private List<MethodList> methodList;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
