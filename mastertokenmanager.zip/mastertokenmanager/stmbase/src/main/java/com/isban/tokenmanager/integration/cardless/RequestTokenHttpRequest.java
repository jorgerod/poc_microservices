package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class RequestTokenHttpRequest  extends ViabilityTokenHttpRequest {
    
    @ApiModelProperty(required = true)
    @Size(max = 4, min = 4)    
    private String branchOffice;
    
    @ApiModelProperty(required = true)
    @Size(max = 15, min = 6)
    private String smsPhone;

 
    public String getSmsPhone() {
        return smsPhone;
    }

    public void setSmsPhone(String smsPhone) {
        this.smsPhone = smsPhone;
    }

    public String getBranchOffice() {
        return branchOffice;
    }

    public void setBranchOffice(String branchOffice) {
        this.branchOffice = branchOffice;
    }

}
