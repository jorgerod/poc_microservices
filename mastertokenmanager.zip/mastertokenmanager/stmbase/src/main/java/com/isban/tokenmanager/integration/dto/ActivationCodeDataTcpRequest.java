package com.isban.tokenmanager.integration.dto;

public class ActivationCodeDataTcpRequest extends TcpCommonDataRequest {
    
    private String correlationId;
    private String tokenReferenceId;
    private String activationCode;
    private String activationCodeExpiry;
    private String activationMethod;
    
    private String panReferenceId;
    private String wpRequestId;
    private String wpConversationId;
    private String walletAccountId;
    private String lifeCycleTraceId;
    private String token;
    private String deviceType;
    private String deviceName;
    private String secureElementId;
    private String versionEncryptedStructure;
    private String encryptionKeyIndex;
    private String encryptionDataBlob;
    private String processingCode;
    private String amountTransaction;
    private String transactionCategoryCode;
    private String pointOfServiceData;
    private String messageType;
    private String paymentInitiatorChannel;

    public ActivationCodeDataTcpRequest() {
        super();
    }

//    public ActivationCodeDataTcpRequest(TcpCommonDataRequest requestBase, String ticketRef, String activationCode,
//            String activationCodeExpiry, String activationMethod) {
//        super(requestBase.getOperationId(), requestBase.getOperationDateTime(),
//                requestBase.getIssuerId(), requestBase.getTokenTypeId(),
//                requestBase.getTokenRequestorId(), requestBase.getItem(),
//                requestBase.getExpirationDatePan(), requestBase.getDataEntryMode());
//        this.ticketRef = ticketRef;
//        this.activationCode = activationCode;
//        this.activationCodeExpiry = activationCodeExpiry;
//        this.activationMethod = activationMethod;
//    }
    
    

    public String getPanReferenceId() {
        return panReferenceId;
    }

//    public ActivationCodeDataTcpRequest(TcpCommonDataRequest requestBase, String ticketRef, String activationCode, String activationCodeExpiry,
//        String activationMethod, String panReferenceId, String wpRequestId, String wpConversationId,
//        String walletAccountId, String lifeCycleTraceId, String token, String deviceType, String deviceName,
//        String secureElementId, String versionEncryptedStructure, String encryptionKeyIndex, String encryptionDataBlob,
//        String processingCode, String amountTransaction, String transactionCategoryCode, String pointOfServiceData,
//        String messageType, String paymentInitiatorChannel) {
//      super(requestBase.getOperationId(), requestBase.getOperationDateTime(),
//      requestBase.getIssuerId(), requestBase.getTokenTypeId(),
//      requestBase.getTokenRequestorId(), requestBase.getItem(),
//      requestBase.getExpirationDatePan(), requestBase.getDataEntryMode());
//    this.tokenReferenceId = ticketRef;
//    this.activationCode = activationCode;
//    this.activationCodeExpiry = activationCodeExpiry;
//    this.activationMethod = activationMethod;
//    this.panReferenceId = panReferenceId;
//    this.wpRequestId = wpRequestId;
//    this.wpConversationId = wpConversationId;
//    this.walletAccountId = walletAccountId;
//    this.lifeCycleTraceId = lifeCycleTraceId;
//    this.token = token;
//    this.deviceType = deviceType;
//    this.deviceName = deviceName;
//    this.secureElementId = secureElementId;
//    this.version = versionEncryptedStructure;
//    this.encryptionKeyIndex = encryptionKeyIndex;
//    this.encryptionDataBlob = encryptionDataBlob;
//    this.processingCode = processingCode;
//    this.amountTransaction = amountTransaction;
//    this.transactionCategoryCode = transactionCategoryCode;
//    this.pointOfServiceData = pointOfServiceData;
//    this.messageType = messageType;
//    this.paymentInitiatorChannel = paymentInitiatorChannel;
//}

    
    
    public void setPanReferenceId(String panReferenceId) {
        this.panReferenceId = panReferenceId;
    }

    public ActivationCodeDataTcpRequest(TcpCommonDataRequest requestBase,String correlationId, String tokenReferenceId, String activationCode,
        String activationCodeExpiry, String activationMethod, String panReferenceId, String wpRequestId,
        String wpConversationId, String walletAccountId, String lifeCycleTraceId, String token, String deviceType,
        String deviceName, String secureElementId, String version, String encryptionKeyIndex, String encryptionDataBlob,
        String processingCode, String amountTransaction, String transactionCategoryCode, String pointOfServiceData,
        String messageType, String paymentInitiatorChannel) {
        super(requestBase.getOperationId(), requestBase.getOperationDateTime(),
                requestBase.getIssuerId(), requestBase.getTokenTypeId(),
                requestBase.getTokenRequestorId(), requestBase.getItem(),
                requestBase.getExpirationDatePan(), requestBase.getDataEntryMode());
    this.correlationId = correlationId;
    this.tokenReferenceId = tokenReferenceId;
    this.activationCode = activationCode;
    this.activationCodeExpiry = activationCodeExpiry;
    this.activationMethod = activationMethod;
    this.panReferenceId = panReferenceId;
    this.wpRequestId = wpRequestId;
    this.wpConversationId = wpConversationId;
    this.walletAccountId = walletAccountId;
    this.lifeCycleTraceId = lifeCycleTraceId;
    this.token = token;
    this.deviceType = deviceType;
    this.deviceName = deviceName;
    this.secureElementId = secureElementId;
    this.versionEncryptedStructure = version;
    this.encryptionKeyIndex = encryptionKeyIndex;
    this.encryptionDataBlob = encryptionDataBlob;
    this.processingCode = processingCode;
    this.amountTransaction = amountTransaction;
    this.transactionCategoryCode = transactionCategoryCode;
    this.pointOfServiceData = pointOfServiceData;
    this.messageType = messageType;
    this.paymentInitiatorChannel = paymentInitiatorChannel;
}

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    public String getWpRequestId() {
        return wpRequestId;
    }

    public void setWpRequestId(String wpRequestId) {
        this.wpRequestId = wpRequestId;
    }

    public String getWpConversationId() {
        return wpConversationId;
    }

    public void setWpConversationId(String wpConversationId) {
        this.wpConversationId = wpConversationId;
    }

    public String getWalletAccountId() {
        return walletAccountId;
    }

    public void setWalletAccountId(String walletAccountId) {
        this.walletAccountId = walletAccountId;
    }

    public String getLifeCycleTraceId() {
        return lifeCycleTraceId;
    }

    public void setLifeCycleTraceId(String lifeCycleTraceId) {
        this.lifeCycleTraceId = lifeCycleTraceId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getSecureElementId() {
        return secureElementId;
    }

    public void setSecureElementId(String secureElementId) {
        this.secureElementId = secureElementId;
    }

    public String getVersionEncryptedStructure() {
        return versionEncryptedStructure;
    }

    public void setVersionEncryptedStructure(String version) {
        this.versionEncryptedStructure = version;
    }

    public String getEncryptionKeyIndex() {
        return encryptionKeyIndex;
    }

    public void setEncryptionKeyIndex(String encryptionKeyIndex) {
        this.encryptionKeyIndex = encryptionKeyIndex;
    }

    public String getEncryptionDataBlob() {
        return encryptionDataBlob;
    }

    public void setEncryptionDataBlob(String encryptionDataBlob) {
        this.encryptionDataBlob = encryptionDataBlob;
    }

    public String getProcessingCode() {
        return processingCode;
    }

    public void setProcessingCode(String processingCode) {
        this.processingCode = processingCode;
    }

    public String getAmountTransaction() {
        return amountTransaction;
    }

    public void setAmountTransaction(String amountTransaction) {
        this.amountTransaction = amountTransaction;
    }

    public String getTransactionCategoryCode() {
        return transactionCategoryCode;
    }

    public void setTransactionCategoryCode(String transactionCategoryCode) {
        this.transactionCategoryCode = transactionCategoryCode;
    }

    public String getPointOfServiceData() {
        return pointOfServiceData;
    }

    public void setPointOfServiceData(String pointOfServiceData) {
        this.pointOfServiceData = pointOfServiceData;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getPaymentInitiatorChannel() {
        return paymentInitiatorChannel;
    }

    public void setPaymentInitiatorChannel(String paymentInitiatorChannel) {
        this.paymentInitiatorChannel = paymentInitiatorChannel;
    }

    public String getActivationCode() {
        return activationCode;
    }

    public void setActivationCode(String activationCode) {
        this.activationCode = activationCode;
    }

    public String getActivationCodeExpiry() {
        return activationCodeExpiry;
    }

    public void setActivationCodeExpiry(String activationCodeExpiry) {
        this.activationCodeExpiry = activationCodeExpiry;
    }

    public String getActivationMethod() {
        return activationMethod;
    }

    public void setActivationMethod(String activationMethod) {
        this.activationMethod = activationMethod;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ActivationCodeDataTcpRequest [correlationId=");
        builder.append(correlationId);
        builder.append(", tokenReferenceId=");
        builder.append(tokenReferenceId);
        builder.append(", activationCode=");
        builder.append(activationCode);
        builder.append(", activationCodeExpiry=");
        builder.append(activationCodeExpiry);
        builder.append(", activationMethod=");
        builder.append(activationMethod);
        builder.append(", panReferenceId=");
        builder.append(panReferenceId);
        builder.append(", wpRequestId=");
        builder.append(wpRequestId);
        builder.append(", wpConversationId=");
        builder.append(wpConversationId);
        builder.append(", walletAccountId=");
        builder.append(walletAccountId);
        builder.append(", lifeCycleTraceId=");
        builder.append(lifeCycleTraceId);
        builder.append(", token=");
        builder.append(token);
        builder.append(", deviceType=");
        builder.append(deviceType);
        builder.append(", deviceName=");
        builder.append(deviceName);
        builder.append(", secureElementId=");
        builder.append(secureElementId);
        builder.append(", versionEncryptedStructure=");
        builder.append(versionEncryptedStructure);
        builder.append(", encryptionKeyIndex=");
        builder.append(encryptionKeyIndex);
        builder.append(", encryptionDataBlob=");
        builder.append(encryptionDataBlob);
        builder.append(", processingCode=");
        builder.append(processingCode);
        builder.append(", amountTransaction=");
        builder.append(amountTransaction);
        builder.append(", transactionCategoryCode=");
        builder.append(transactionCategoryCode);
        builder.append(", pointOfServiceData=");
        builder.append(pointOfServiceData);
        builder.append(", messageType=");
        builder.append(messageType);
        builder.append(", paymentInitiatorChannel=");
        builder.append(paymentInitiatorChannel);
        builder.append("]");
        return builder.toString();
    }



}
