package com.isban.tokenmanager.dto;

public class NotificationResumeResponse extends ResponseBase {

    public NotificationResumeResponse() {
    }

    public NotificationResumeResponse(String code, String description) {
        super(code, description);
    }
}
