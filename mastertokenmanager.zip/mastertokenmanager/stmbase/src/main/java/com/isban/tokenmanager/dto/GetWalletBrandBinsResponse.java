package com.isban.tokenmanager.dto;

import java.util.List;

public class GetWalletBrandBinsResponse extends ResponseBase {

    private List<TokenRequestorBrandDto> walletBrandBins;

    public GetWalletBrandBinsResponse() {
    }

    public GetWalletBrandBinsResponse(String code, String description) {
        super(code, description);
    }

    public List<TokenRequestorBrandDto> getWalletBrandBins() {
        return walletBrandBins;
    }

    public void setWalletBrandBins(List<TokenRequestorBrandDto> walletBrandBins) {
        this.walletBrandBins = walletBrandBins;
    }

    @Override
    public String toString() {
        return "GetWalletBrandBinsResponse [walletBrandBins=" + walletBrandBins + "]";
    }

}
