package com.isban.tokenmanager.dto;

import java.util.Date;

public class TokenInfoDto extends TokenDto {

    private String tokenId = null;
    private String requestId = null;

    private String item = null;
    private String itemReferenceId = null;
    private Date expirationItem = null;
    private String ditem;
    private Date expirationDitem = null;

    private String tokenReferenceId = null; // token externo
    private String correlationId = null;

    private Date operationDate = null;
    private String tokenAssuranceLevel = null;
    private String tokenTypeExt = null;
    private Integer numberActiveTokensPan = 0;
    private Integer numberInactiveTokens = 0;
    private Integer numberSuspendedTokens = 0;
    private Integer numberActivationAttemps = 0;
    private String termAndConditions = null;
    private Date termAndConditionsDate = null;
    private String pvv = null;
    private String accountNumber = null;
    
    
    private String statusChangeBranchOffice;
    private String statusChangeUserId;
    private String statusChangeComments;
    private String externalTransactionId;

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getItemReferenceId() {
        return itemReferenceId;
    }

    public void setItemReferenceId(String itemReferenceId) {
        this.itemReferenceId = itemReferenceId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Date getExpirationItem() {
        return expirationItem;
    }

    public void setExpirationItem(Date expirationItem) {
        this.expirationItem = expirationItem;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    public Date getExpirationDitem() {
        return expirationDitem;
    }

    public void setExpirationDitem(Date expirationDitem) {
        this.expirationDitem = expirationDitem;
    }

    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public String getTokenAssuranceLevel() {
        return tokenAssuranceLevel;
    }

    public void setTokenAssuranceLevel(String tokenAssuranceLevel) {
        this.tokenAssuranceLevel = tokenAssuranceLevel;
    }

    public String getTokenTypeExt() {
        return tokenTypeExt;
    }

    public void setTokenTypeExt(String tokenTypeExt) {
        this.tokenTypeExt = tokenTypeExt;
    }

    public Integer getNumberActiveTokensPan() {
        return numberActiveTokensPan;
    }

    public void setNumberActiveTokensPan(Integer numberActiveTokensPan) {
        this.numberActiveTokensPan = numberActiveTokensPan;
    }

    public Integer getNumberInactiveTokens() {
        return numberInactiveTokens;
    }

    public void setNumberInactiveTokens(Integer numberInactiveTokens) {
        this.numberInactiveTokens = numberInactiveTokens;
    }

    public Integer getNumberSuspendedTokens() {
        return numberSuspendedTokens;
    }

    public void setNumberSuspendedTokens(Integer numberSuspendedTokens) {
        this.numberSuspendedTokens = numberSuspendedTokens;
    }

    public Integer getNumberActivationAttemps() {
        return numberActivationAttemps;
    }

    public void setNumberActivationAttemps(Integer numberActivationAttemps) {
        this.numberActivationAttemps = numberActivationAttemps;
    }

    public String getTermAndConditions() {
        return termAndConditions;
    }

    public void setTermAndConditions(String termAndConditions) {
        this.termAndConditions = termAndConditions;
    }

    public Date getTermAndConditionsDate() {
        return termAndConditionsDate;
    }

    public void setTermAndConditionsDate(Date termAndConditionsDate) {
        this.termAndConditionsDate = termAndConditionsDate;
    }

    public String getPvv() {
        return pvv;
    }

    public void setPvv(String pvv) {
        this.pvv = pvv;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getStatusChangeBranchOffice() {
        return statusChangeBranchOffice;
    }

    public void setStatusChangeBranchOffice(String statusChangeBranchOffice) {
        this.statusChangeBranchOffice = statusChangeBranchOffice;
    }

    public String getStatusChangeUserId() {
        return statusChangeUserId;
    }

    public void setStatusChangeUserId(String statusChangeUserId) {
        this.statusChangeUserId = statusChangeUserId;
    }

    public String getStatusChangeComments() {
        return statusChangeComments;
    }

    public void setStatusChangeComments(String statusChangeComments) {
        this.statusChangeComments = statusChangeComments;
    }

    public String getExternalTransactionId() {
        return externalTransactionId;
    }

    public void setExternalTransactionId(String externalTransactionId) {
        this.externalTransactionId = externalTransactionId;
    }
}
