package com.isban.tokenmanager.dto;

public class SaveIssuerResponse extends ResponseBase {

    private IssuerDto issuerDto;

    public SaveIssuerResponse() {
    }

    public SaveIssuerResponse(String code, String description) {
        super(code, description);
    }

    public IssuerDto getIssuerDto() {
        return issuerDto;
    }

    public void setIssuerDto(IssuerDto issuerDto) {
        this.issuerDto = issuerDto;
    }

    @Override
    public String toString() {
        return "SaveIssuerResponse [issuerDto=" + issuerDto + "]";
    }

}
