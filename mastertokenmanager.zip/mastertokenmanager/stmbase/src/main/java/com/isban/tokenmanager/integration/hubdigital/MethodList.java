package com.isban.tokenmanager.integration.hubdigital;

import javax.validation.constraints.NotNull;

import com.isban.tokenmanager.integration.hubdigital.enm.HubDigitalMethodTypeEnum;

import io.swagger.annotations.ApiModelProperty;

public class MethodList {

    @ApiModelProperty(required = true, value = "Type of verification method.")
    @NotNull
    private HubDigitalMethodTypeEnum methodType;
    
    @ApiModelProperty(required = true, value = "Value of the contact information of the verification method.")
    @NotNull
    private String methodValue;

    public HubDigitalMethodTypeEnum getMethodType() {
        return methodType;
    }

    public void setMethodType(HubDigitalMethodTypeEnum methodType) {
        this.methodType = methodType;
    }

    public String getMethodValue() {
        return methodValue;
    }

    public void setMethodValue(String methodValue) {
        this.methodValue = methodValue;
    }

}
