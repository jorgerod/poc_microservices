package com.isban.tokenmanager.dto;

import java.util.ArrayList;
import java.util.List;

public class RoleResponse extends ResponseBase {

    private List<RoleDto> roles = new ArrayList<>();

    public RoleResponse(String code, String description) {
        super(code, description);
    }

    public RoleResponse() {
    }

    public List<RoleDto> getRoles() {
        return roles;
    }

    public void setRoles(List<RoleDto> roles) {
        this.roles = roles;
    }
}
