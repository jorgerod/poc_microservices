package com.isban.tokenmanager.dto;

import java.util.List;

public class UserDto extends LifeTimeDto {

    private String userId;
    private List<IssuerTokenTypeUserDto> issuerUsersList;

    public UserDto(String issuerId, String tokenTypeId, String userId, List<IssuerTokenTypeUserDto> issuerUsersList) {
        this(issuerId, tokenTypeId);
        this.userId = userId;
        this.issuerUsersList = issuerUsersList;
    }

    public UserDto(String issuerId, String tokenTypeId) {
        this.issuerId = issuerId;
        this.tokenTypeId = tokenTypeId;
    }
    
    public UserDto() {
        super();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<IssuerTokenTypeUserDto> getIssuerUsersList() {
        return issuerUsersList;
    }

    public void setIssuerUsersList(List<IssuerTokenTypeUserDto> issuerUsersList) {
        this.issuerUsersList = issuerUsersList;
    }
}
