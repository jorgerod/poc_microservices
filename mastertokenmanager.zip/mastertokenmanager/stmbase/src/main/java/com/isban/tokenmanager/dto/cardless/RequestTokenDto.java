package com.isban.tokenmanager.dto.cardless;

import com.isban.tokenmanager.dto.TokenDto;

public class RequestTokenDto extends ViabilityTokenDto {

    private String branchOffice;
    private String smsPhone;
    
    private TokenDto token;

    public TokenDto getToken() {
        return token;
    }

    public void setToken(TokenDto tokenDto) {
        this.token = tokenDto;
    }

    public String getSmsPhone() {
        return smsPhone;
    }

    public void setSmsPhone(String smsPhone) {
        this.smsPhone = smsPhone;
    }

    public String getBranchOffice() {
        return branchOffice;
    }

    public void setBranchOffice(String branchOffice) {
        this.branchOffice = branchOffice;
    }

}
