package com.isban.tokenmanager.integration.cardless;

import java.util.List;

import com.isban.tokenmanager.dto.ResponseBase;
import com.isban.tokenmanager.integration.dto.IntegrationResponseBase;

public class GetReportRequestInDateHttpResponse  extends IntegrationResponseBase<List<ReportItem>> {
    public GetReportRequestInDateHttpResponse() {
        super();
    }

    public GetReportRequestInDateHttpResponse(String codeResponse, String desResponse) {
        super(codeResponse, desResponse);
    }

    public GetReportRequestInDateHttpResponse(ResponseBase responseBase) {
        super(responseBase);
    }
}
