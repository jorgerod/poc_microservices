package com.isban.tokenmanager.integration.mdes;

public class NotifyTokenUpdatedHttpResponse extends MdesApiCommonResponse {

}
