package com.isban.tokenmanager.integration.dto;

public class NotificationFailedActivationDataTcpRequest extends NotificationDataBaseTcpRequest {

    private String tokenEventResult;

    public NotificationFailedActivationDataTcpRequest() {
        super();
    }

    public NotificationFailedActivationDataTcpRequest(TcpCommonDataRequest requestBase, String ticketRef, String ditem,
            String tokenEventResult) {
        super(requestBase, ticketRef, ditem);
        this.tokenEventResult = tokenEventResult;
    }

    public String getTokenEventResult() {
        return tokenEventResult;
    }

    public void setTokenEventResult(String tokenEventResult) {
        this.tokenEventResult = tokenEventResult;
    }

    @Override
    public String toString() {
        return "NotificationFailedActivationDataTcpRequest [activationVerificationResult=" + tokenEventResult
                + ", getTicketRef()=" + getTokenReferenceId() + ", getDitem()=" + getDitem() + ", toString()=" + super.toString()
                + ", getOperationId()=" + getOperationId() + ", getOperationDate()=" + getOperationDateTime() + ", getIssuerId()=" + getIssuerId() + ", getTokenRequestorId()="
                + getTokenRequestorId() + ", getItem()=" + getItem() + ", getExpirationDatePan()=" + getExpirationDatePan()
                + ", getDataEntryMode()=" + getDataEntryMode() + ", getClass()=" + getClass() + ", hashCode()="
                + hashCode() + "]";
    }

}
