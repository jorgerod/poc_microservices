package com.isban.tokenmanager.exception;


public class TokenManagerException extends Exception {

    private static final long serialVersionUID = 7242092731742922896L;

    public static final String UNKNOWN_EXCEPTION = "E01";
    public static final String HTTP_CLIENT_EXCEPTION = "E02";
    public static final String TIMEOUT_EXCEPTION = "E03";
    public static final String CONNECT_EXCEPTION = "E04";
    public static final String RESOURCE_ACCESS_EXCEPTION = "E05";

    private String code;
    private String description;

    public TokenManagerException() {
    }

    public TokenManagerException(String code, String description, Throwable throwable) {
        super(throwable);
        this.code = (code != null && !"".equals(code) ? code : UNKNOWN_EXCEPTION);
        this.description = (description != null && !"".equals(description) ? description : throwable.getMessage());
    }

    public TokenManagerException(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
