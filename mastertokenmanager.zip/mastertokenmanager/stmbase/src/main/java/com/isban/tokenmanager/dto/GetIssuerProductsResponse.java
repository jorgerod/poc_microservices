package com.isban.tokenmanager.dto;

import java.util.List;

public class GetIssuerProductsResponse extends ResponseBase {

    private List<ProductDto> issuerProducts;

    public GetIssuerProductsResponse() {
    }

    public GetIssuerProductsResponse(String code, String description) {
        super(code, description);
    }

    public List<ProductDto> getIssuerProducts() {
        return issuerProducts;
    }

    public void setIssuerProducts(List<ProductDto> issuerProducts) {
        this.issuerProducts = issuerProducts;
    }

    @Override
    public String toString() {
        return "GetIssuerProductsResponse [issuerProducts=" + issuerProducts + "]";
    }

}
