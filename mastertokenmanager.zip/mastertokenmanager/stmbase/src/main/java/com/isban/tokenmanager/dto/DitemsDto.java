package com.isban.tokenmanager.dto;

import java.util.Date;

public class DitemsDto {

    private String ditem;
    private String deviceId;
    private String ditemStatus;
    private Date expiryDate;
    private String deviceName;
    private String deviceType;
    private String tokenRequestorDescription;

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    
    public String getDitemStatus() {
        return ditemStatus;
    }

    public void setDitemStatus(String ditemStatus) {
        this.ditemStatus = ditemStatus;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getTokenRequestorDescription() {
        return tokenRequestorDescription;
    }

    public void setTokenRequestorDescription(String walletDescription) {
        this.tokenRequestorDescription = walletDescription;
    }
}