package com.isban.tokenmanager.integration.dto;

public class PaymentCancellationDataTcpResponse extends TcpCommonDataResponse {

    public PaymentCancellationDataTcpResponse() {
        super();
    }

    public PaymentCancellationDataTcpResponse(String operationId, String operationDateTime) {
        super(operationId, operationDateTime);
    }
    
    public PaymentCancellationDataTcpResponse(PaymentCancellationDataTcpRequest paymentCancellationDataRequest) {
        super(paymentCancellationDataRequest.getOperationId(), paymentCancellationDataRequest.getOperationDateTime());
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("PaymentCancellationDataTcpResponse [getOperationId()=").append(getOperationId())
                .append(", getOperationDateTime()=").append(getOperationDateTime()).append("]");
        return builder.toString();
    }

}
