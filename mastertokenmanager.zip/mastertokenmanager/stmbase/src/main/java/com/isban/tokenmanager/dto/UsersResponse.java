package com.isban.tokenmanager.dto;

import java.util.List;

public class UsersResponse extends ResponseBase {

    private List<UserDto> users;

    public UsersResponse(String code, String description) {
        super(code, description);
    }

    public UsersResponse() {
    }

    public List<UserDto> getUsers() {
        return users;
    }

    public void setUsers(List<UserDto> users) {
        this.users = users;
    }
}
