package com.isban.tokenmanager.dto;

import java.util.List;

public class GetDpansResponse extends ResponseBase {

    private List<DitemsDto> dpanList;

    public GetDpansResponse(String code, String description) {
        super(code, description);
    }

    public GetDpansResponse() {
    }

    public List<DitemsDto> getDpanList() {
        return dpanList;
    }

    public void setDitemList(List<DitemsDto> dpanList) {
        this.dpanList = dpanList;
    }
}
