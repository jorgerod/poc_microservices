package com.isban.tokenmanager.stmcrypto.dto;

public class EncryptDataOutput {

    /* 
     * Properties
     */
    private Integer errorCode = 0;
    private String errorDescription = "No error";
    private String iv;
    private Integer encryptedDataLength;
    private String encryptedData;
    
    /*
     * Getters and setters
     */
    public Integer getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }
    public String getErrorDescription() {
        return errorDescription;
    }
    public void setErrorDescription(String value) {
        this.errorDescription = value;
    }
    public String getIv() {
        return iv;
    }
    public void setIv(String iv) {
        this.iv = iv;
    }
    public Integer getEncryptedDataLength() {
        return encryptedDataLength;
    }
    public void setEncryptedDataLength(Integer encryptedDataLength) {
        this.encryptedDataLength = encryptedDataLength;
    }
    public String getEncryptedData() {
        return encryptedData;
    }
    public void setEncryptedData(String encryptedData) {
        this.encryptedData = encryptedData;
    }

}
