package com.isban.tokenmanager.dto;

public class SaveTspRequest extends TspDto {
}
