package com.isban.tokenmanager.integration.tsp;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class InformationHttpRequest {

    private String tokenTypeId;
    private String tspId;
    private Integer expiration;
    private String unitExpiration;
    private String shortDescription = null;
    private String description = null;

    @JsonFormat(pattern = "yyyyMMdd")
    private Date startDate;

    @JsonFormat(pattern = "yyyyMMdd")
    private Date endDate;

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    public String getTspId() {
        return tspId;
    }

    public void setTspId(String tspId) {
        this.tspId = tspId;
    }    

    public Integer getExpiration() {
        return expiration;
    }
    public void setExpiration(Integer expiration) {
        this.expiration = expiration;
    }

    public String getUnitExpiration() {
        return unitExpiration;
    }
    public void setUnitExpiration(String unitExpiration) {
        this.unitExpiration = unitExpiration;
    }

}
