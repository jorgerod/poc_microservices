package com.isban.tokenmanager.service.security;

import javax.crypto.SecretKey;

public interface CryptographicVeptsService extends CryptographicService{
    public String prepad( String value );
    public String unprepad( String value );
    
    // ///////////////////////////////////////////////////////////////////////
    //SKC = https://en.wikipedia.org/wiki/Cryptography#Symmetric-key_cryptography
    public byte[] encrypt( EncSkcInput input4enc );
    public byte[] decrypt( DecSkcInput input4dec );
    public SecretKey createSecretKey( byte[] secretKeyBytes );
    //
    public class EncSkcInput{
        public byte[] msg;
        public SecretKey secretKey;
    }
    public class DecSkcInput{
        public byte[] encryptedMsg;
        public SecretKey secretKey;
    }
}
