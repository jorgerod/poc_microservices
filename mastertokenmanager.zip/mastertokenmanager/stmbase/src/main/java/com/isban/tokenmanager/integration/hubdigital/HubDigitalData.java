package com.isban.tokenmanager.integration.hubdigital;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isban.tokenmanager.integration.hubdigital.enm.HubDigitalWalletEnum;

import io.swagger.annotations.ApiModelProperty;

public class HubDigitalData {
    
    @ApiModelProperty(required = false, value = "Unique identifier of the instance associated with the registration process that is starting with the current request. "
            + "All subsequent communications regarding this registration process will use this identifier to be able to correlate.")
    @Size(min = 24, max = 24)    
    private String instanceId;

    @ApiModelProperty(required = false, value = "Indicates the application requesting the registration")
    private HubDigitalWalletEnum application;

    @ApiModelProperty(required = false, value = "Product identifier.")
    private String productId;

    @ApiModelProperty(required = false, value = "Identifier of Terms and Conditions.")
    private String tycId;

    @ApiModelProperty(required = false, value = "Identify the set of images to use.")
    private String cardArtId;

    @ApiModelProperty(required = false, value = "New token state. A - Active, D - Deactive, B - Deleted")
    @Size(min = 1, max = 1)
    private String newStatus;

    @ApiModelProperty(required = false, value = "Initial state after deployment. A - Active, D - Deactive, B - Deleted")
    @Size(min = 1, max = 1)
    private String status;

    @ApiModelProperty(required = false, value = "Device identifier where deployment was done")
    private String deviceId;

    @ApiModelProperty(required = false, value = "Verification method selected by cardholder")
    private String methodType;

    @ApiModelProperty(required = false, value = "Verification result")
    @Size(min = 2, max = 2)
    private String result;

    @JsonIgnore
    private String serviceName;


    public String getInstanceId() {
        return instanceId;
    }
    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }
    public HubDigitalWalletEnum getApplication() {
        return application;
    }
    public void setApplication(HubDigitalWalletEnum application) {
        this.application = application;
    }
    public String getProductId() {
        return productId;
    }
    public void setProductId(String productId) {
        this.productId = productId;
    }
    public String getTycId() {
        return tycId;
    }
    public void setTycId(String tycId) {
        this.tycId = tycId;
    }
    public String getCardArtId() {
        return cardArtId;
    }
    public void setCardArtId(String cardArtId) {
        this.cardArtId = cardArtId;
    }
    public String getNewStatus() {
        return newStatus;
    }
    public void setNewStatus(String newStatus) {
        this.newStatus = newStatus;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getDeviceId() {
        return deviceId;
    }
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
    public String getMethodType() {
        return methodType;
    }
    public void setMethodType(String methodType) {
        this.methodType = methodType;
    }
    public String getResult() {
        return result;
    }
    public void setResult(String result) {
        this.result = result;
    }
    public String getServiceName() {
        return serviceName;
    }
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
    
}
