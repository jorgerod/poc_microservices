package com.isban.tokenmanager.dto;

public class CardLessSMSHttpRequestBase {
    
    String message;
    String sender;
    
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public String getSender() {
        return sender;
    }
    public void setSender(String sender) {
        this.sender = sender;
    }
    
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CardLessSMSHttpRequestBase [message=");
        builder.append(message);
        builder.append(", sender=");
        builder.append(sender);
        builder.append("]");
        return builder.toString();
    }

    
    
    
}
