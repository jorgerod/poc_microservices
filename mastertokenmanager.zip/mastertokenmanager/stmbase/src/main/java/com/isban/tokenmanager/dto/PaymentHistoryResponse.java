package com.isban.tokenmanager.dto;

import java.util.List;

public class PaymentHistoryResponse extends ResponseBase {

    private List<TransactionHistoryDto> paymentHistory;

    public PaymentHistoryResponse(String code, String description) {
        super(code, description);
    }

    public PaymentHistoryResponse() {
    }

    public List<TransactionHistoryDto> getPaymentHistory() {
        return paymentHistory;
    }

    public void setPaymentHistory(List<TransactionHistoryDto> paymentHistory) {
        this.paymentHistory = paymentHistory;
    }
}
