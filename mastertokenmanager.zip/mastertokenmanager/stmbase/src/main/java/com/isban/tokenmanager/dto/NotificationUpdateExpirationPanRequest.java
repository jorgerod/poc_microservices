package com.isban.tokenmanager.dto;

public class NotificationUpdateExpirationPanRequest extends NotificationCommonDataRequest {

    public NotificationUpdateExpirationPanRequest() {
    }
}
