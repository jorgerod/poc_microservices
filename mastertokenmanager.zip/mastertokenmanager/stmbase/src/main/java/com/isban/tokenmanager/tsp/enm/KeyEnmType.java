package com.isban.tokenmanager.tsp.enm;

public enum KeyEnmType {
    NUMERIC(0), 
    ALPHANUMERIC(1);

    private int code;

    private KeyEnmType(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public static KeyEnmType get(int n) {
        for (KeyEnmType c : values()) {
          if (c.code == n) {
            return c;
          }
        }
        // either throw the IAE or return null, your choice.
        throw new IllegalArgumentException(String.valueOf(n));
    }
}
