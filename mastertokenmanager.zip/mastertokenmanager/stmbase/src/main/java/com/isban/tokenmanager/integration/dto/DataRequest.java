package com.isban.tokenmanager.integration.dto;

import java.util.List;

public class DataRequest {

    private String tickettm;
    private String customerid;
    private String issuerid;
    private String walletid;
    private String otp;
    private List<String> listpan;
    private String pan;
    private String messageid;
    private String typemedia;
    private String valuemedia;
    private String language;
    private String channel;
    private List<CardChannel> pans;
    private String schemeid;
    private String devicetype;
    private String expiry;
    private String deliverymethodid;
    
    


    public String getTickettm() {
        return tickettm;
    }

    public void setTickettm(String tickettm) {
        this.tickettm = tickettm;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getCustomerid() {
        return customerid;
    }

    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }

    public String getIssuerid() {
        return issuerid;
    }

    public void setIssuerid(String issuerid) {
        this.issuerid = issuerid;
    }

    public String getWalletid() {
        return walletid;
    }

    public void setWalletid(String walletid) {
        this.walletid = walletid;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public List<String> getListpan() {
        return listpan;
    }

    public void setListpan(List<String> listpan) {
        this.listpan = listpan;
    }

    public String getMessageid() {
        return messageid;
    }

    public void setMessageid(String messageid) {
        this.messageid = messageid;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getTypemedia() {
        return typemedia;
    }

    public void setTypemedia(String typemedia) {
        this.typemedia = typemedia;
    }

    public String getValuemedia() {
        return valuemedia;
    }

    public void setValuemedia(String valuemedia) {
        this.valuemedia = valuemedia;
    }
    
    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public List<CardChannel> getPans() {
        return pans;
    }

    public void setPans(List<CardChannel> pans) {
        this.pans = pans;
    }

    public String getSchemeid() {
        return schemeid;
    }

    public void setSchemeid(String schemeid) {
        this.schemeid = schemeid;
    }

    public String getDevicetype() {
        return devicetype;
    }

    public void setDevicetype(String devicetype) {
        this.devicetype = devicetype;
    }

    public String getExpiry() {
        return expiry;
    }

    public void setExpiry(String expiry) {
        this.expiry = expiry;
    }

    public String getDeliverymethodid() {
        return deliverymethodid;
    }

    public void setDeliverymethodid(String deliverymethodid) {
        this.deliverymethodid = deliverymethodid;
    }

    @Override
    public String toString() {
        return "DataRequest [customerid=" + customerid + ", issuerid="
                + issuerid + ", walletid=" + walletid + ", otp=" + otp
                + ", listpan=" + listpan + ", pan=" + pan + ", messageid="
                + messageid + ", typemedia=" + typemedia + ", valuemedia="
                + valuemedia + ", language=" + language + ", channel="
                + channel + ", pans=" + pans + ", schemeid=" + schemeid
                + ", devicetype=" + devicetype + ", expiry=" + expiry
                + ", deliverymethodid=" + deliverymethodid + "]";
    }

   
}
