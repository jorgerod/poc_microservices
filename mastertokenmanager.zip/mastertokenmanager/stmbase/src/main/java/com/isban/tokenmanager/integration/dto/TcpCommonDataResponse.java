package com.isban.tokenmanager.integration.dto;

public class TcpCommonDataResponse {

    private String operationId;
    private String operationDateTime;//aaaammdd

    public TcpCommonDataResponse() {
    }

    public TcpCommonDataResponse(String operationId, String operationDateTime) {
        super();
        this.operationId = operationId;
        this.operationDateTime = operationDateTime;
    }

    public String getOperationId() {
        return operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }


    public String getOperationDateTime() {
        return operationDateTime;
    }

    public void setOperationDateTime(String operationDateTime) {
        this.operationDateTime = operationDateTime;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("TcpCommonDataResponse [operationId=").append(operationId).append(", operationDateTime=")
                .append(operationDateTime).append("]");
        return builder.toString();
    }

}
