package com.isban.tokenmanager.dto;

import java.util.List;

public class GetIssuerBlocksResponse extends ResponseBase {

    private List<BlockDto> issuerBlocks;

    public GetIssuerBlocksResponse() {
    }

    public GetIssuerBlocksResponse(String code, String description) {
        super(code, description);
    }

    public List<BlockDto> getIssuerBlocks() {
        return issuerBlocks;
    }

    public void setIssuerBlocks(List<BlockDto> issuerBlocks) {
        this.issuerBlocks = issuerBlocks;
    }

    @Override
    public String toString() {
        return "GetIssuerBlocksResponse [issuerBlocks=" + issuerBlocks + "]";
    }

}
