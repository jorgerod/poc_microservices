package com.isban.tokenmanager.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class ExceptionUtil {
    public void logException( Exception e , Logger logger ){
        if( e == null ){ return; }
        if( logger == null ){ 
            logException( e );
            return;
        }
        
        String toLog = exceptionStackTraceToString( e );
        logger.error(toLog);
    }

    public void logException(Exception e) {
        if( e == null ){ return; }
        e.printStackTrace();
    }
    
    public String exceptionStackTraceToString(Exception e){
        String ret = null;
        if( e == null ){ return ret; }
        
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        ret = sw.toString();
        
        return ret;
    }
}
