package com.isban.tokenmanager.dto;


public class SaveUserResponse extends ResponseBase {

    private UserDto user;

    public SaveUserResponse() {
    }

    public SaveUserResponse(String code, String description) {
        super(code, description);
    }

    public UserDto getUser() {
        return user;
    }

    public void setUser(UserDto user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "SaveUserResponse{" +
                "user=" + user +
                '}';
    }
}