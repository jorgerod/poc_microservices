package com.isban.tokenmanager.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class LifeTimeDto extends ModelBaseDto {

    @JsonFormat(pattern = "yyyyMMdd")
    private Date startDate;

    @JsonFormat(pattern = "yyyyMMdd")
    private Date endDate;

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
}
