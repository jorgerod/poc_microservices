package com.isban.tokenmanager.integration.dto;

/**
 * @author Sergey Zlobin
 * @since 04/08/2015
 */
public class ActivateDataRequest {

    private String pan;
    private String state;
    private String ditem;

    public String getItem() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    @Override
    public String toString() {
        return "ActivateDataRequest{" +
                "pan='" + pan + '\'' +
                ", state='" + state + '\'' +
                ", dpan='" + ditem+ '\'' +
                '}';
    }
}
