package com.isban.tokenmanager.dto.card;

public class CardByCSR {
    
    String item;
    String tokenStateId;
    String deviceName;
    String deviceType;
    String tokenRequestorId;
    String tokenReferenceId;
    public String getItem() {
        return item;
    }
    public void setItem(String item) {
        this.item = item;
    }
    public String getTokenStateId() {
        return tokenStateId;
    }
    public void setTokenStateId(String tokenStateId) {
        this.tokenStateId = tokenStateId;
    }
    public String getDeviceName() {
        return deviceName;
    }
    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }
    public String getDeviceType() {
        return deviceType;
    }
    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }
    public String getTokenRequestorId() {
        return tokenRequestorId;
    }
    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }
    public String getTokenReferenceId() {
        return tokenReferenceId;
    }
    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }
    
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CardByCSRResponse [item=");
        builder.append(item);
        builder.append(", tokenStateId=");
        builder.append(tokenStateId);
        builder.append(", deviceName=");
        builder.append(deviceName);
        builder.append(", deviceType=");
        builder.append(deviceType);
        builder.append(", tokenRequestorId=");
        builder.append(tokenRequestorId);
        builder.append(", tokenReferenceId=");
        builder.append(tokenReferenceId);
        builder.append("]");
        return builder.toString();
    }
    
    

}
