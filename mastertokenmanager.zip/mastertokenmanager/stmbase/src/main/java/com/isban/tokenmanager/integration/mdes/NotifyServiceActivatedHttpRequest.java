package com.isban.tokenmanager.integration.mdes;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isban.tokenmanager.dto.mdes.CardAndTokenInfoDataDto;
import com.isban.tokenmanager.dto.mdes.CardAndTokenInfoDto;
import com.isban.tokenmanager.dto.mdes.DeviceInfoDto;
import com.isban.tokenmanager.dto.mdes.enm.DecisionMadeByMdesEnum;
import com.isban.tokenmanager.dto.mdes.enm.DecisionMdesEnum;
import com.isban.tokenmanager.dto.mdes.enm.MDESServiceEnum;
import com.isban.tokenmanager.dto.mdes.enm.MDESTokenTypeEnum;

import io.swagger.annotations.ApiModelProperty;

public class NotifyServiceActivatedHttpRequest extends MdesApiCommonRequest {

    @ApiModelProperty(required = true)
    @NotNull
    private List<MDESServiceEnum> services = null;

    @ApiModelProperty(required = true)
    @NotNull
    private CardAndTokenInfoDto cardAndTokenInfo = null;
    
    @ApiModelProperty(required = true)
    private CardAndTokenInfoDataDto cardAndTokenData = null;

    private DeviceInfoDto deviceInfo = null;

    @ApiModelProperty(required = true)
    @NotNull
    @Size(max = 14)
    private String correlationId = "";

    @ApiModelProperty(required = true)
    @NotNull
    @Size(max = 11)
    private String tokenRequestorId = "";

    @Size(max = 3)
    private String walletId = null;

    @Size(max = 48)
    private String paymentAppInstanceId = null;

    @ApiModelProperty(required = true)
    @NotNull
    private MDESTokenTypeEnum tokenType = null;

    @Size(max = 48)
    private String secureElementId = null;

    @ApiModelProperty(required = true)
    @NotNull
    @Size(max = 8)
    private String accountPanSuffix = null;

    // TODO YYYY-MM-DDThh:mm:ss[.sss]Z
    // YYYY-MM-DDThh:mm:ss[.sss]±hh:mm
    @ApiModelProperty(required = true)
    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private Date serviceRequestDateTime = null;

    @Size(max = 64)
    private String termsAndConditionsAssetId = null;

    // TODO YYYY-MM-DDThh:mm:ss[.sss]Z
    // YYYY-MM-DDThh:mm:ss[.sss]±hh:mm
    @ApiModelProperty(required = true)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private Date termsAndConditionsAcceptedTimestamp = null;

    @Size(max = 64)
    private String productConfigurationId = null;

    @Size(max = 2)
    private String consumerLanguage = null;

    @ApiModelProperty(required = true)
    @NotNull
    private DecisionMdesEnum decision = null;

    @ApiModelProperty(required = true)
    @NotNull
    private DecisionMadeByMdesEnum decisionMadeBy = null;

    // TODO YYYY-MM-DDThh:mm:ss[.sss]Z
    // YYYY-MM-DDThh:mm:ss[.sss]±hh:mm
    @ApiModelProperty(required = true)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private Date tokenActivatedDateTime = null;

    @Min(0)
    @Size(max = 1)
    private String numberOfActivationAttempts = null;

    @Min(0)
    @Size(max = 2)
    private String numberOfActiveTokens = null;

    public List<MDESServiceEnum> getServices() {
        return services;
    }

    public void setServices(List<MDESServiceEnum> services) {
        this.services = services;
    }

    public CardAndTokenInfoDto getCardAndTokenInfo() {
        return cardAndTokenInfo;
    }

    public void setCardAndTokenInfo(CardAndTokenInfoDto cardAndTokenInfo) {
        this.cardAndTokenInfo = cardAndTokenInfo;
    }

    public DeviceInfoDto getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(DeviceInfoDto deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getWalletId() {
        return walletId;
    }

    public void setWalletId(String walletId) {
        this.walletId = walletId;
    }

    public String getPaymentAppInstanceId() {
        return paymentAppInstanceId;
    }

    public void setPaymentAppInstanceId(String paymentAppInstanceId) {
        this.paymentAppInstanceId = paymentAppInstanceId;
    }

    public MDESTokenTypeEnum getTokenType() {
        return tokenType;
    }

    public void setTokenType(MDESTokenTypeEnum tokenType) {
        this.tokenType = tokenType;
    }

    public String getSecureElementId() {
        return secureElementId;
    }

    public void setSecureElementId(String secureElementId) {
        this.secureElementId = secureElementId;
    }

    public String getAccountPanSuffix() {
        return accountPanSuffix;
    }

    public void setAccountPanSuffix(String accountPanSuffix) {
        this.accountPanSuffix = accountPanSuffix;
    }

    public Date getServiceRequestDateTime() {
        return serviceRequestDateTime;
    }

    public void setServiceRequestDateTime(Date serviceRequestDateTime) {
        this.serviceRequestDateTime = serviceRequestDateTime;
    }

    public String getTermsAndConditionsAssetId() {
        return termsAndConditionsAssetId;
    }

    public void setTermsAndConditionsAssetId(String termsAndConditionsAssetId) {
        this.termsAndConditionsAssetId = termsAndConditionsAssetId;
    }

    public Date getTermsAndConditionsAcceptedTimestamp() {
        return termsAndConditionsAcceptedTimestamp;
    }

    public void setTermsAndConditionsAcceptedTimestamp(Date termsAndConditionsAcceptedTimestamp) {
        this.termsAndConditionsAcceptedTimestamp = termsAndConditionsAcceptedTimestamp;
    }

    public String getProductConfigurationId() {
        return productConfigurationId;
    }

    public void setProductConfigurationId(String productConfigurationId) {
        this.productConfigurationId = productConfigurationId;
    }

    public String getConsumerLanguage() {
        return consumerLanguage;
    }

    public void setConsumerLanguage(String consumerLanguage) {
        this.consumerLanguage = consumerLanguage;
    }

    public DecisionMdesEnum getDecision() {
        return decision;
    }

    public void setDecision(DecisionMdesEnum decision) {
        this.decision = decision;
    }

    public DecisionMadeByMdesEnum getDecisionMadeBy() {
        return decisionMadeBy;
    }

    public void setDecisionMadeBy(DecisionMadeByMdesEnum decisionMadeBy) {
        this.decisionMadeBy = decisionMadeBy;
    }

    public Date getTokenActivatedDateTime() {
        return tokenActivatedDateTime;
    }

    public void setTokenActivatedDateTime(Date tokenActivatedDateTime) {
        this.tokenActivatedDateTime = tokenActivatedDateTime;
    }

    public String getNumberOfActivationAttempts() {
        return numberOfActivationAttempts;
    }

    public void setNumberOfActivationAttempts(String numberOfActivationAttempts) {
        this.numberOfActivationAttempts = numberOfActivationAttempts;
    }

    public String getNumberOfActiveTokens() {
        return numberOfActiveTokens;
    }

    public void setNumberOfActiveTokens(String numberOfActiveTokens) {
        this.numberOfActiveTokens = numberOfActiveTokens;
    }

    public CardAndTokenInfoDataDto getCardAndTokenData() {
        return cardAndTokenData;
    }

    public void setCardAndTokenData(CardAndTokenInfoDataDto cardAndTokenData) {
        this.cardAndTokenData = cardAndTokenData;
    }
}
