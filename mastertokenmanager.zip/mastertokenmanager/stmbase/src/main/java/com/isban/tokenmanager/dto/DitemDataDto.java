package com.isban.tokenmanager.dto;

import java.util.Date;

public class DitemDataDto {
    
    private String ditem;
    private Date expirationDitem;
    
    public String getDitem() {
        return ditem;
    }
    public void setDitem(String ditem) {
        this.ditem = ditem;
    }
    public Date getExpirationDitem() {
        return expirationDitem;
    }
    public void setExpirationDitem(Date expirationDitem) {
        this.expirationDitem = expirationDitem;
    }

}
