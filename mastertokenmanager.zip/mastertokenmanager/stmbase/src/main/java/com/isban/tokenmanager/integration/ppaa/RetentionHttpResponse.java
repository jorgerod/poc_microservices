package com.isban.tokenmanager.integration.ppaa;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class RetentionHttpResponse extends CommonHttpResponse {

    private String retentionId;

    @JsonProperty(value = "withholdingId")
    @ApiModelProperty(value = "Identifier associated to the withholding.", required = false)
    public String getRetentionId() {
        return retentionId;
    }

    public void setRetentionId(String retentionId) {
        this.retentionId = retentionId;
    }

}
