package com.isban.tokenmanager.dto;

import java.util.Date;

public class NotificationCompleteRequest extends NotificationTokenizationBaseRequest {

    private String tokenRequestorExt;
    private String walletExt = null;
    
    private String paymentAppInstanceId = null;

    private String secureElement = null;
    private String accountPanSuffix = null;
    private Date serviceRequestDateTime = null;
    private String termsAndConditionsAssetId = null;
    private Date termsAndConditionsAcceptedTimestamp = null;
    private String productConfigurationId = null;
    private String consumerLanguage = null;
    private String decision = null;
    private String decisionMadeBy = null;
    private Date tokenActivatedDateTime = null;
    private String numberOfActivationAttempts = null;
    private String numberOfActiveTokens = null;
    
    public NotificationCompleteRequest() {
    }
    

    public String getTokenRequestorExt() {
        return tokenRequestorExt;
    }

    public void setTokenRequestorExt(String tokenRequestorExt) {
        this.tokenRequestorExt = tokenRequestorExt;
    }

    public String getWalletExt() {
        return walletExt;
    }

    public void setWalletExt(String walletExt) {
        this.walletExt = walletExt;
    }

    public String getPaymentAppInstanceId() {
        return paymentAppInstanceId;
    }

    public void setPaymentAppInstanceId(String paymentAppInstanceId) {
        this.paymentAppInstanceId = paymentAppInstanceId;
    }

    public String getSecureElement() {
        return secureElement;
    }

    public void setSecureElement(String secureElement) {
        this.secureElement = secureElement;
    }

    public String getAccountPanSuffix() {
        return accountPanSuffix;
    }

    public void setAccountPanSuffix(String accountPanSuffix) {
        this.accountPanSuffix = accountPanSuffix;
    }

    public Date getServiceRequestDateTime() {
        return serviceRequestDateTime;
    }

    public void setServiceRequestDateTime(Date serviceRequestDateTime) {
        this.serviceRequestDateTime = serviceRequestDateTime;
    }

    public String getTermsAndConditionsAssetId() {
        return termsAndConditionsAssetId;
    }

    public void setTermsAndConditionsAssetId(String termsAndConditionsAssetId) {
        this.termsAndConditionsAssetId = termsAndConditionsAssetId;
    }

    public Date getTermsAndConditionsAcceptedTimestamp() {
        return termsAndConditionsAcceptedTimestamp;
    }

    public void setTermsAndConditionsAcceptedTimestamp(Date termsAndConditionsAcceptedTimestamp) {
        this.termsAndConditionsAcceptedTimestamp = termsAndConditionsAcceptedTimestamp;
    }

    public String getProductConfigurationId() {
        return productConfigurationId;
    }

    public void setProductConfigurationId(String productConfigurationId) {
        this.productConfigurationId = productConfigurationId;
    }

    public String getConsumerLanguage() {
        return consumerLanguage;
    }

    public void setConsumerLanguage(String consumerLanguage) {
        this.consumerLanguage = consumerLanguage;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public String getDecisionMadeBy() {
        return decisionMadeBy;
    }

    public void setDecisionMadeBy(String decisionMadeBy) {
        this.decisionMadeBy = decisionMadeBy;
    }

    public Date getTokenActivatedDateTime() {
        return tokenActivatedDateTime;
    }

    public void setTokenActivatedDateTime(Date tokenActivatedDateTime) {
        this.tokenActivatedDateTime = tokenActivatedDateTime;
    }

    public String getNumberOfActivationAttempts() {
        return numberOfActivationAttempts;
    }

    public void setNumberOfActivationAttempts(String numberOfActivationAttempts) {
        this.numberOfActivationAttempts = numberOfActivationAttempts;
    }

    public String getNumberOfActiveTokens() {
        return numberOfActiveTokens;
    }

    public void setNumberOfActiveTokens(String numberOfActiveTokens) {
        this.numberOfActiveTokens = numberOfActiveTokens;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("NotificationCompleteRequest [tokenRequestorExt=").append(tokenRequestorExt)
                .append(", walletExt=").append(walletExt).append(", paymentAppInstanceId=").append(paymentAppInstanceId)
                .append(", secureElement=").append(secureElement).append(", accountPanSuffix=").append(accountPanSuffix)
                .append(", serviceRequestDateTime=").append(serviceRequestDateTime)
                .append(", termsAndConditionsAssetId=").append(termsAndConditionsAssetId)
                .append(", termsAndConditionsAcceptedTimestamp=").append(termsAndConditionsAcceptedTimestamp)
                .append(", productConfigurationId=").append(productConfigurationId).append(", consumerLanguage=")
                .append(consumerLanguage).append(", decision=").append(decision).append(", tokenActivatedDateTime=")
                .append(tokenActivatedDateTime).append(", numberOfActivationAttempts=")
                .append(numberOfActivationAttempts).append(", numberOfActiveTokens=").append(numberOfActiveTokens)
                .append("]");
        return builder.toString();
    }

}
