package com.isban.tokenmanager.integration.dto;

/**
 * 
 * 
 * 
 * @author realsec
 */
public class GetFlowAndMediaMdesResponse extends IntegrationResponseBase<FlowAndMedia> {

    public GetFlowAndMediaMdesResponse(String codeResponse, String desResponse) {
        super(codeResponse, desResponse);
    }
}
