package com.isban.tokenmanager.dto.metrics;

public class MetricExtended {
    public Long time;
    public Long okcount = 0L;
    public Long kocount = 0L;
    public Double gauge = -1D;
    
    
    
    public Long getTime() {
        return time;
    }
    public void setTime(Long time) {
        this.time = time;
    }
    public Long getOkcount() {
        return okcount;
    }
    public void setOkcount(Long okcount) {
        this.okcount = okcount;
    }
    public Long getKocount() {
        return kocount;
    }
    public void setKocount(Long kocount) {
        this.kocount = kocount;
    }
    public Double getGauge() {
        return gauge;
    }
    public void setGauge(Double gauge) {
        this.gauge = gauge;
    }
}
