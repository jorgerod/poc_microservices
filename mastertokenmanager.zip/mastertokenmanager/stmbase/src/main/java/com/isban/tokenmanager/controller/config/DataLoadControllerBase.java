package com.isban.tokenmanager.controller.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

public class DataLoadControllerBase {
    protected static final CharSequence ENV_PRE = "PRE";
    protected static final CharSequence ENV_DEV = "DEV";
    protected static final CharSequence ENV_LOCAL = "LOC";
    protected static final String SPRING_PROFILES_ACTIVE = "spring.profiles.active";

    @Autowired
    protected Environment environment;
}
