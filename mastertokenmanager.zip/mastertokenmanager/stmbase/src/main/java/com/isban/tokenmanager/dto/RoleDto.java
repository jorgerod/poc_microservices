package com.isban.tokenmanager.dto;

public class RoleDto {

    private String roleId;
    private String issuerId;
    private String tokenTypeId;
    private String description;

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}