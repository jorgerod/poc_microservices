package com.isban.tokenmanager.model.enm;

public enum EventTypeEnum {

    OK("000", "Successfully completed"), 
    
    ERROR_TECH_DB("001", "Error in DB access"),
    ERROR_TECH_COMMUNICATION("002", "Error in communications"),
    ERROR_TECH_PARAMETERS_REQUEST("003", "Error in parameters"),
    ERROR_TECH_FILE_READING("004", "Error read/write file"),
    ERROR_TECH_GENERIC("005", "Error technical generic"),
    ERROR_TECH_STM_COMMUNICATION("010", "Error in communications"),
    
    ERROR_LOGICAL_INTREGRITY_DB("006", "Error integrity DB"),
    ERROR_LOGICAL_SEQ_PROCCESS("007", "Error sequence process"),
    ERROR_LOGICAL_PARAMETRIZATION("008", "Error integrity in parameters"),
    
    WARNING_PROCCESS("009", "Warning");//por ejemplo: sincronizacion de tsp
    

    private String code;
    private String description;

    EventTypeEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
