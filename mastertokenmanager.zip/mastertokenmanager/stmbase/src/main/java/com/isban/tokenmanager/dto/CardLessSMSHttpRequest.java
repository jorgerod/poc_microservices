package com.isban.tokenmanager.dto;

public class CardLessSMSHttpRequest extends CardLessSMSHttpRequestBase {
    
    String recipient;
    
    public String getRecipient() {
        return recipient;
    }
    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }
    
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CardLessSMSHttpRequest [recipient=");
        builder.append(recipient);
        builder.append("]");
        return builder.toString();
    }

    
}
