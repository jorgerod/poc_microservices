package com.isban.tokenmanager.integration.dto;

public class NotificationCompleteDataTcpRequest extends NotificationDataBaseTcpRequest {

    private String expirationDateDpan;
    private String tokenTypeExt;
    private String panReferenceId;
    private String numberActiveTokensForFpan;
    private String numberActivationAttemps;
    private String deviceType;
    private String deviceLanguageCode;
    private String deviceName;
    private String deviceId;
    private String termsAndConditionsData;
    private String termsAndConditionsDateAndTime;
    private String decision;
    private String decisionMadeBy;
    private String cardHolderWalletAccountId;

    public NotificationCompleteDataTcpRequest() {
        super();
    }

    public NotificationCompleteDataTcpRequest(TcpCommonDataRequest requestBase, String ticketRef, String ditem,
            String dateexpirationdpan, String tokenTypeExt, String panReferenceId, String numberActiveTokensForFpan,
            String numberActivationAttemps, String deviceType, String deviceLanguageCode, String deviceName,
            String deviceId, String termsAndConditionsData, String termsAndConditionsDateAndTime, String decision,
            String decisionMadeBy, String cardHolderWalletAccountId) {
        super(requestBase, ticketRef, ditem);
        this.expirationDateDpan = dateexpirationdpan;
        this.tokenTypeExt = tokenTypeExt;
        this.panReferenceId = panReferenceId;
        this.numberActiveTokensForFpan = numberActiveTokensForFpan;
        this.numberActivationAttemps = numberActivationAttemps;
        this.deviceType = deviceType;
        this.deviceLanguageCode = deviceLanguageCode;
        this.deviceName = deviceName;
        this.deviceId = deviceId;
        this.termsAndConditionsData = termsAndConditionsData;
        this.termsAndConditionsDateAndTime = termsAndConditionsDateAndTime;
        this.decision = decision;
        this.decisionMadeBy = decisionMadeBy;
        this.cardHolderWalletAccountId = cardHolderWalletAccountId;
    }

    public String getExpirationDateDpan() {
        return expirationDateDpan;
    }

    public void setExpirationDateDpan(String expirationDateDpan) {
        this.expirationDateDpan = expirationDateDpan;
    }

    public String getNumberActiveTokensForFpan() {
        return numberActiveTokensForFpan;
    }

    public void setNumberActiveTokensForFpan(String numberActiveTokensForFpan) {
        this.numberActiveTokensForFpan = numberActiveTokensForFpan;
    }

    public String getNumberActivationAttemps() {
        return numberActivationAttemps;
    }

    public void setNumberActivationAttemps(String numberActivationAttemps) {
        this.numberActivationAttemps = numberActivationAttemps;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceLanguageCode() {
        return deviceLanguageCode;
    }

    public void setDeviceLanguageCode(String deviceLanguageCode) {
        this.deviceLanguageCode = deviceLanguageCode;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getTermsAndConditionsData() {
        return termsAndConditionsData;
    }

    public void setTermsAndConditionsData(String termsAndConditionsData) {
        this.termsAndConditionsData = termsAndConditionsData;
    }

    public String getTermsAndConditionsDateAndTime() {
        return termsAndConditionsDateAndTime;
    }

    public void setTermsAndConditionsDateAndTime(String termsAndConditionsDateAndTime) {
        this.termsAndConditionsDateAndTime = termsAndConditionsDateAndTime;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public String getDecisionMadeBy() {
        return decisionMadeBy;
    }

    public void setDecisionMadeBy(String decisionMadeBy) {
        this.decisionMadeBy = decisionMadeBy;
    }

    public String getCardHolderWalletAccountId() {
        return cardHolderWalletAccountId;
    }

    public void setCardHolderWalletAccountId(String cardHolderWalletAccountId) {
        this.cardHolderWalletAccountId = cardHolderWalletAccountId;
    }

    public String getTokenTypeExt() {
        return tokenTypeExt;
    }

    public void setTokenTypeExt(String tokenTypeExt) {
        this.tokenTypeExt = tokenTypeExt;
    }

    public String getPanReferenceId() {
        return panReferenceId;
    }

    public void setPanReferenceId(String panReferenceId) {
        this.panReferenceId = panReferenceId;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("NotificationCompleteDataTcpRequest [expirationDateDpan=").append(expirationDateDpan)
                .append(", numberActiveTokensForFpan=").append(numberActiveTokensForFpan)
                .append(", numberActivationAttemps=").append(numberActivationAttemps).append(", deviceType=")
                .append(deviceType).append(", deviceLanguageCode=").append(deviceLanguageCode).append(", deviceName=")
                .append(deviceName).append(", termsAndConditionsData=").append(termsAndConditionsData)
                .append(", termsAndConditionsDateAndTime=").append(termsAndConditionsDateAndTime)
                .append(", getTicketRef()=").append(getTokenReferenceId()).append(", getDitem()=").append(getDitem())
                .append(", toString()=").append(super.toString()).append(", getOperationId()=").append(getOperationId())
                .append(", getOperationDateTime()=").append(getOperationDateTime()).append(", getIssuerId()=")
                .append(getIssuerId()).append(", getTokenRequestorId()=").append(getTokenRequestorId())
                .append(", getItem()=").append(getItem()).append(", getExpirationDatePan()=")
                .append(getExpirationDatePan()).append(", getDataEntryMode()=").append(getDataEntryMode()).append("]");
        return builder.toString();
    }

}
