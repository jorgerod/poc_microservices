package com.isban.tokenmanager.dto.cardless;

import com.isban.tokenmanager.dto.ModelBaseDto;

public class DailyConciliationRequestDto extends ModelBaseDto{
    
    String executionDate;

    public String getExecutionDate() {
        return executionDate;
    }

    public void setExecutionDate(String executionDate) {
        this.executionDate = executionDate;
    }
    
    

}
