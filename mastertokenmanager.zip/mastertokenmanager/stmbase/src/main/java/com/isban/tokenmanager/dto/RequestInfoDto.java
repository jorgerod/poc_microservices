package com.isban.tokenmanager.dto;

public class RequestInfoDto {

    private String requestId = null;

    private String cardHolderWalletAccount = null;
    private String walletRiskAssessment = null;
    private String walletRiskAssessmentVersion = null;
    private String walletDeviceScore = null;
    private String walletAccountScore = null;
    private String walletReasonCode = null;
    private String itemSource = null;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getCardHolderWalletAccount() {
        return cardHolderWalletAccount;
    }

    public void setCardHolderWalletAccount(String cardHolderWalletAccount) {
        this.cardHolderWalletAccount = cardHolderWalletAccount;
    }

    public String getWalletRiskAssessment() {
        return walletRiskAssessment;
    }

    public void setWalletRiskAssessment(String walletRiskAssessment) {
        this.walletRiskAssessment = walletRiskAssessment;
    }

    public String getWalletRiskAssessmentVersion() {
        return walletRiskAssessmentVersion;
    }

    public void setWalletRiskAssessmentVersion(String walletRiskAssessmentVersion) {
        this.walletRiskAssessmentVersion = walletRiskAssessmentVersion;
    }

    public String getWalletDeviceScore() {
        return walletDeviceScore;
    }

    public void setWalletDeviceScore(String walletDeviceScore) {
        this.walletDeviceScore = walletDeviceScore;
    }

    public String getWalletAccountScore() {
        return walletAccountScore;
    }

    public void setWalletAccountScore(String walletAccountScore) {
        this.walletAccountScore = walletAccountScore;
    }

    public String getWalletReasonCode() {
        return walletReasonCode;
    }

    public void setWalletReasonCode(String walletReasonCode) {
        this.walletReasonCode = walletReasonCode;
    }

    public String getItemSource() {
        return itemSource;
    }

    public void setItemSource(String itemSource) {
        this.itemSource = itemSource;
    }

}
