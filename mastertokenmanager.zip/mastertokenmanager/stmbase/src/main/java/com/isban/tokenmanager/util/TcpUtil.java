package com.isban.tokenmanager.util;

import java.io.IOException;
import java.io.InputStream;

import org.springframework.stereotype.Component;

@Component
public class TcpUtil {

    private static TcpUtil instance = null;

    public static TcpUtil getInstance() {
        if (instance == null) {
            instance = new TcpUtil();
        }

        return instance;
    }

    public String parseString(InputStream inputStream, int length) throws IOException {
        return parseString(inputStream, length, null);
    }

    /**
     * Private parseString with a default start char.
     *
     * @param inputStream InputStream.
     * @param length      Length of the Object.
     * @param startChar   Start Char in the Input Stream to read.
     * @return String
     * @throws IOException
     */
    public String parseString(InputStream inputStream, int length, String startChar) throws IOException {
        String ret = "";
        startChar = startChar != null ? startChar : " ";

        StringBuilder builder = new StringBuilder();

        int c;
        for (int i = 0; i < length; ++i) {
            c = inputStream.read();
            checkClosure(c);
            builder.append((char) c);
        }
        ret = builder.toString();

        while (ret.startsWith(startChar)) {
            ret = ret.substring(1);
        }

        return ret;
    }

    /**
     * Check whether the byte passed in is the "closed socket" byte
     * Note, I put this in here just as an example, but you could just extend the
     * {@link org.springframework.integration.ip.tcp.serializer.AbstractByteArraySerializer} class
     * which has this method
     *
     * @param bite bite
     * @throws IOException
     */
    public void checkClosure(int bite) throws IOException {
        if (bite < 0) {
            throw new IOException("Socket closed during message assembly");
        }
    }

    public String leftPadding(String value, int size, String symbol) {
        String ret = value;

        int length = value.length();
        if (length < size) {
            int gap = size - length;
            for (int i = 0; i < gap; i++) {
                ret = symbol + ret;
            }
        } else if (length > size) {
            ret = ret.substring(0, size);
        }

        return ret;
    }

    public String leftPadding(String value, int size) {
        return leftPadding(value, size, " ");
    }

    public String rightPadding(String value, int size, String symbol) {
        String ret = value == null ? "": value;

        int length = ret.length();
        if (length < size) {
            int gap = size - length;
            for (int i = 0; i < gap; i++) {
                ret = ret + symbol;
            }
        } else if (length > size) {
            ret = ret.substring((length - size), length);
        }
        
        return ret;
    }

    public String rightPadding(String value, int size) {
        return rightPadding(value, size, " ");
    }

    public String deleteWhiteChars(String value) {
        if (value != null) {
            while (value.startsWith(Constants.WHITE_CHAR)) {
                value = value.substring(1);
            }
        }

        return value;
    }

    protected String fixLength(String ret, int size) {
        return ret.substring(0, size);
    }
}