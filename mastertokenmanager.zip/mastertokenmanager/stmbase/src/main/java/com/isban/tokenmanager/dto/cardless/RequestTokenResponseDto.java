package com.isban.tokenmanager.dto.cardless;

import java.util.Date;

import com.isban.tokenmanager.dto.ResponseBase;

public class RequestTokenResponseDto extends ResponseBase {

    private String tokenRefenceId;
    private String ditem;
    private Date expirationDitem;

    public RequestTokenResponseDto(String code, String description) {
        super(code, description);
    }
    
    public RequestTokenResponseDto() {
        super();
    }


    public String getTokenRefenceId() {
        return tokenRefenceId;
    }

    public void setTokenRefenceId(String tokenRefenceId) {
        this.tokenRefenceId = tokenRefenceId;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    public Date getExpirationDitem() {
        return expirationDitem;
    }

    public void setExpirationDitem(Date expirationDitem) {
        this.expirationDitem = expirationDitem;
    }

}
