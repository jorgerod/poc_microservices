package com.isban.tokenmanager.integration.gateway;

import com.isban.tokenmanager.exception.TokenManagerException;
import com.isban.tokenmanager.stmcrypto.dto.DecryptDataInput;
import com.isban.tokenmanager.stmcrypto.dto.DecryptDataOutput;
import com.isban.tokenmanager.stmcrypto.dto.EncryptDataInput;
import com.isban.tokenmanager.stmcrypto.dto.EncryptDataOutput;
import com.isban.tokenmanager.stmcrypto.dto.GenerateMacInput;
import com.isban.tokenmanager.stmcrypto.dto.GenerateMacOutput;
import com.isban.tokenmanager.stmcrypto.dto.VerifyMacInput;
import com.isban.tokenmanager.stmcrypto.dto.VerifyMacOutput;

public interface StmCryptoGateway {

    EncryptDataOutput encryptData(EncryptDataInput request) throws TokenManagerException;

    GenerateMacOutput generateMac(GenerateMacInput request) throws TokenManagerException;

    DecryptDataOutput decryptMac(DecryptDataInput request) throws TokenManagerException;

    VerifyMacOutput verifyMac(VerifyMacInput request) throws TokenManagerException;

}
