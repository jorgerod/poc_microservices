package com.isban.tokenmanager.integration.mdes;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.isban.tokenmanager.dto.mdes.TokenMdes;

import io.swagger.annotations.ApiModelProperty;

public class NotifyTokenUpdatedHttpRequest extends MdesApiCommonRequest {

    @ApiModelProperty(required = true)
    @NotNull
    private List<TokenMdes> tokens = null;

    public List<TokenMdes> getTokens() {
        return tokens;
    }

    public void setTokens(List<TokenMdes> tokens) {
        this.tokens = tokens;
    }
    
}
