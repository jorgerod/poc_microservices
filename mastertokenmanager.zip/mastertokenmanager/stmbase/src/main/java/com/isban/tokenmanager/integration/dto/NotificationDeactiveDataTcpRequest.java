package com.isban.tokenmanager.integration.dto;

public class NotificationDeactiveDataTcpRequest extends NotificationDataBaseTcpRequest {

    public NotificationDeactiveDataTcpRequest() {
        super();
    }

    public NotificationDeactiveDataTcpRequest(TcpCommonDataRequest requestBase, String ticketRef, String ditem) {
        super(requestBase, ticketRef, ditem);
    }

    @Override
    public String toString() {
        return "NotificationDeactiveDataTcpRequest [getTicketRef()=" + getTokenReferenceId() + ", getDitem()="
                + getDitem() + ", toString()=" + super.toString() + ", getOperationId()=" + getOperationId()
                + ", getOperationDate()=" + getOperationDateTime() + ", getIssuerId()=" + getIssuerId()
                + ", getTokenRequestorId()=" + getTokenRequestorId() + ", getItem()=" + getItem()
                + ", getExpirationDatePan()=" + getExpirationDatePan() + ", getDataEntryMode()=" + getDataEntryMode()
                + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
    }
}
