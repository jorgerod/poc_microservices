package com.isban.tokenmanager.dto;

public class BinDigitalDto extends LifeTimeDto {

    private String id;
    private String maxPan;
    private String minPan;
    private String typeBinId;
    private String brandId;
    private String tspId;
    
    public BinDigitalDto() {
    }
    
    public BinDigitalDto(String issuerId, String tokenTypeId) {
        this.issuerId = issuerId;
        this.tokenTypeId = tokenTypeId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMaxPan() {
        return maxPan;
    }

    public void setMaxPan(String maxPan) {
        this.maxPan = maxPan;
    }

    public String getMinPan() {
        return minPan;
    }

    public void setMinPan(String minPan) {
        this.minPan = minPan;
    }

    public String getTypeBinId() {
        return typeBinId;
    }

    public void setTypeBinId(String typeBinId) {
        this.typeBinId = typeBinId;
    }

    public String getBrandId() {
        return brandId;
    }

    public void setBrandId(String brandId) {
        this.brandId = brandId;
    }

    public String getTspId() {
        return tspId;
    }

    public void setTspId(String tspId) {
        this.tspId = tspId;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

}
