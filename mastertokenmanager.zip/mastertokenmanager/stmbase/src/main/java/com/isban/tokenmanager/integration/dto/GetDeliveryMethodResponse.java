package com.isban.tokenmanager.integration.dto;

import java.util.List;

public class GetDeliveryMethodResponse {

    String code;
    String description;
    List<DeliveryMethodResponse> methods;
    Integer suspiciusFraud;

    public GetDeliveryMethodResponse() {

    }

    public GetDeliveryMethodResponse(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public GetDeliveryMethodResponse(String code, String description, List<DeliveryMethodResponse> methods,
            Integer suspiciusFraud) {
        this.code = code;
        this.description = description;
        this.methods = methods;
        this.suspiciusFraud = suspiciusFraud;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<DeliveryMethodResponse> getMethods() {
        return methods;
    }

    public void setMethods(List<DeliveryMethodResponse> methods) {
        this.methods = methods;
    }

    public Integer getSuspiciusFraud() {
        return suspiciusFraud;
    }

    public void setSuspiciusFraud(Integer suspiciusFraud) {
        this.suspiciusFraud = suspiciusFraud;
    }

    @Override
    public String toString() {
        return "GetDeliveryMethodResponse [code=" + code + ", description=" + description + ", methods=" + methods
                + ", suspiciusFraud=" + suspiciusFraud + "]";
    }

}
