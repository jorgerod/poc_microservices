package com.isban.tokenmanager.dto;

public class ActivationMethodDto extends ModelBaseDto {

    private String id;
    private String description;
    private Boolean hasCustomerData;
    private Boolean isSuspicious;
    private String deliveryMethodId;
    private String deliveryMethodDescription;

    public ActivationMethodDto() {
    }

    public ActivationMethodDto(String id, String description,
            Boolean hasCustomerData, Boolean isSuspicious, String deliveryMethodId, String deliveryMethodDescription) {
        this.id = id;
        this.description = description;
        this.hasCustomerData = hasCustomerData;
        this.isSuspicious = isSuspicious;
        this.deliveryMethodId = deliveryMethodId;
        this.deliveryMethodDescription = deliveryMethodDescription;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getHasCustomerData() {
        return hasCustomerData;
    }

    public void setHasCustomerData(Boolean hasCustomerData) {
        this.hasCustomerData = hasCustomerData;
    }

    public Boolean getIsSuspicious() {
        return isSuspicious;
    }

    public void setIsSuspicious(Boolean isSuspicious) {
        this.isSuspicious = isSuspicious;
    }

    public String getDeliveryMethodId() {
        return deliveryMethodId;
    }

    public void setDeliveryMethodId(String deliveryMethodId) {
        this.deliveryMethodId = deliveryMethodId;
    }

    public String getDeliveryMethodDescription() {
        return deliveryMethodDescription;
    }

    public void setDeliveryMethodDescription(String deliveryMethodDescription) {
        this.deliveryMethodDescription = deliveryMethodDescription;
    }

    @Override
    public String toString() {
        return "ActivationMethodDto [id=" + id + ", description=" + description + ", hasCustomerData=" + hasCustomerData
                + ", isSuspicious=" + isSuspicious + ", deliveryMethodId=" + deliveryMethodId
                + ", deliveryMethodDescription=" + deliveryMethodDescription + "]";
    }

}
