package com.isban.tokenmanager.service.metrics;

import org.springframework.boot.actuate.endpoint.PublicMetrics;

import com.isban.tokenmanager.dto.metrics.GraphMetrics;

public interface GraphMetricsService {
    public GraphMetrics addMetrics(PublicMetrics publicMetrics);
    public GraphMetrics getGraphMetrics();
    
    
    
    public boolean getEnabled();
    public String getGraphMetricsNodebase();  //nodebase = protocol + host + port
    public String getGraphMetricsPath();      //url4graphMetrics = nodebase + path
    public int getGraphMetricsSize();
    public String getGraphMetricsCron();
}
