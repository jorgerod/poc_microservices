package com.isban.tokenmanager.dto.card;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class DataCardResponse {

    /** Card list */
    private List<CardResponse> cards;

    /** Cycle Life of the transaction */
    private String transactionTicket;

    private String userExt;

    /**
     * @return the cards
     */
    public List<CardResponse> getCards() {
        if (cards == null) {
            cards = new ArrayList<>();
        }
        return cards;
    }

    /**
     * @param cards
     *            the cards to set
     */
    public void setCards(List<CardResponse> cards) {
        this.cards = cards;
    }

    /**
     * @return the transactionTicket
     */
    public String getTransactionTicket() {
        return transactionTicket;
    }

    /**
     * @param transactionTicket
     *            the transactionTicket to set
     */
    public void setTransactionTicket(String transactionTicket) {
        this.transactionTicket = transactionTicket;
    }

    public String getUserExt() {
        return userExt;
    }

    public void setUserExt(String userExt) {
        this.userExt = userExt;
    }

}
