package com.isban.tokenmanager.dto.pan;

import java.util.Date;
import java.util.UUID;

import com.isban.tokenmanager.dto.ModelBaseDto;

public class ProvisioningDto extends ModelBaseDto {

    private String transactionId = UUID.randomUUID().toString();
    
    private String tokenReferenceId;
    private String item;
    private String ditem;
    private Date expirationDitem;
    private String tokenRequestorId;
    private String tspId;

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    public Date getExpirationDitem() {
        return expirationDitem;
    }

    public void setExpirationDitem(Date expirationDitem) {
        this.expirationDitem = expirationDitem;
    }

    public String getTspId() {
        return tspId;
    }

    public void setTspId(String tspId) {
        this.tspId = tspId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

}
