package com.isban.tokenmanager.dto;

import java.util.List;

public class UserIssuerResponse extends ResponseBase {

    private List<IssuerDto> issuers;

    public UserIssuerResponse(String code, String description) {
        super(code, description);
    }

    public UserIssuerResponse() {
    }

    public List<IssuerDto> getIssuers() {
        return issuers;
    }

    public void setIssuers(List<IssuerDto> issuers) {
        this.issuers = issuers;
    }
}
