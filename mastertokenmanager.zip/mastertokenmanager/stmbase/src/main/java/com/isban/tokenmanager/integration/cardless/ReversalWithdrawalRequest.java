package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class ReversalWithdrawalRequest extends WithdrawalRequest {
    
    private String reasonCode;
    private String withdrawalOpTime;
    private String withdrawalAuthCode;
    
    
    @ApiModelProperty(value = "Reason of the reversal", required = true)
    @Pattern(regexp="^(1|2|3)$")
    @Size(max = 2)    
    public String getReasonCode() {
        return reasonCode;
    }
    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }
    
    @ApiModelProperty(value = "Date and time of the withdrawal to reverse", required = true)
    @Pattern(regexp="^(-?(?:[1-9][0-9]*)?[0-9]{4})-(1[0-2]|0[1-9])-(3[01]|0[1-9]|[12][0-9])T(2[0-3]|[01][0-9]):([0-5][0-9]):([0-5][0-9])(\\.[0-9]+)?(Z|[+-](?:2[0-3]|[01][0-9]):[0-5][0-9])?$")
    @Size(max = 19)    
    public String getWithdrawalOpTime() {
        return withdrawalOpTime;
    }
    public void setWithdrawalOpTime(String withdrawalOpTime) {
        this.withdrawalOpTime = withdrawalOpTime;
    }
    
    @ApiModelProperty(value = "Authorization code of the withdrawal to reverse", required = true)
    @Size(max = 16)    
    public String getWithdrawalAuthCode() {
        return withdrawalAuthCode;
    }
    public void setWithdrawalAuthCode(String withdrawalAuthCode) {
        this.withdrawalAuthCode = withdrawalAuthCode;
    }
    
}
