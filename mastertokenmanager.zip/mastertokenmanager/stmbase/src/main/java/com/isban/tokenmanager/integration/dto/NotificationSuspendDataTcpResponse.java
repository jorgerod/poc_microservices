package com.isban.tokenmanager.integration.dto;

public class NotificationSuspendDataTcpResponse extends TcpCommonDataResponse {

    public NotificationSuspendDataTcpResponse() {
        super();
    }

    public NotificationSuspendDataTcpResponse(NotificationSuspendDataTcpRequest request) {
        super(request.getOperationId(), request.getOperationDateTime());
    }

    @Override
    public String toString() {
        return "NotificationSuspendDataTcpResponse [getOperationId()=" + getOperationId() + ", getOperationDate()="
                + getOperationDateTime() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
                + ", hashCode()=" + hashCode() + "]";
    }
}
