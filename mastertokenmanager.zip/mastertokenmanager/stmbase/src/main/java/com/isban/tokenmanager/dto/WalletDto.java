package com.isban.tokenmanager.dto;

import java.util.List;

public class WalletDto extends LifeTimeDto {

    private String id;
    private String description;

    private String shortDescription;
    private Boolean ownerWallet;

    private List<TokenRequestorBrandDto> walletBrandBinList;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public Boolean getOwnerWallet() {
        return ownerWallet;
    }

    public void setOwnerWallet(Boolean sanWallet) {
        this.ownerWallet = sanWallet;
    }

    public List<TokenRequestorBrandDto> getWalletBrandBinList() {
        return walletBrandBinList;
    }

    public void setWalletBrandBinList(List<TokenRequestorBrandDto> walletBrandBinList) {
        this.walletBrandBinList = walletBrandBinList;
    }

}
