package com.isban.tokenmanager.component.health;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health.Builder;

public abstract class SocketBaseHealthCheck extends AbstractHealthIndicator {
    abstract public String getHost();
    abstract public int getPort();
    
    public int getTimeoutValue(){
        return 3000;
    }

    public boolean getEnableCheck(){
        return true;
    }
    
    @Override
    protected void doHealthCheck(Builder builder) throws Exception {
        if(!getEnableCheck()){ return; }
        
        builder.withDetail("host", getHost());
        builder.withDetail("port", getPort());
        
        Socket socket = null;
        try {
            socket = new Socket();
            socket.connect(  
                    new InetSocketAddress(getHost(), getPort()), 
                    getTimeoutValue()  );
            builder.up().build();
            
        } catch (final Exception e) {
            builder.down(e).build();
            
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                    
                } catch (final IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
