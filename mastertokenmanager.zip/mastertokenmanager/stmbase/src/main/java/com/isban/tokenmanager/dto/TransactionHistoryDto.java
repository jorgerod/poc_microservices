package com.isban.tokenmanager.dto;

public class TransactionHistoryDto {

    private String operationPaymentDate;
    private String paymentStateId;
    private String paymentStateDescription;
    private String paymentTown;

    public String getOperationPaymentDate() {
        return operationPaymentDate;
    }

    public void setOperationPaymentDate(String operationPaymentDate) {
        this.operationPaymentDate = operationPaymentDate;
    }


    public String getPaymentStateId() {
        return paymentStateId;
    }

    public void setPaymentStateId(String paymentStateId) {
        this.paymentStateId = paymentStateId;
    }

    public String getPaymentStateDescription() {
        return paymentStateDescription;
    }

    public void setPaymentStateDescription(String paymentStateDescription) {
        this.paymentStateDescription = paymentStateDescription;
    }

    public String getPaymentTown() {
        return paymentTown;
    }

    public void setPaymentTown(String paymentTown) {
        this.paymentTown = paymentTown;
    }
}
