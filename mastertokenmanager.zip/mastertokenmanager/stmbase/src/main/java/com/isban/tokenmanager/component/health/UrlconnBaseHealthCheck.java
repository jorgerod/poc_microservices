package com.isban.tokenmanager.component.health;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.UnknownHostException;

import org.springframework.boot.actuate.health.Health.Builder;

abstract public class UrlconnBaseHealthCheck extends SocketUrlBaseHealthCheck {
    @Override
    protected void doHealthCheck(Builder builder) throws Exception {
        if(!getEnableCheck()){ return; }
        
        builder.withDetail("url", getUrl());

        HttpURLConnection httpUrlConn = null;
        BufferedReader bufReader = null;
        try {
            URL url = new URL(getUrl());
            httpUrlConn = (HttpURLConnection) url.openConnection();
            httpUrlConn.setRequestMethod("GET");
            
            bufReader = new BufferedReader(new InputStreamReader(httpUrlConn.getInputStream()));
            while(bufReader.readLine() != null) {}
            builder.up().build();
            
        } catch( UnknownHostException e ) {  //UnknownHostException is ko
            builder.down(e).build();
            
        } catch( ConnectException e ) {  //ConnectException is ko
            builder.down(e).build();
            
        } catch( IOException e ) {  //403, 500, 503 codes is OK
            builder.up().build();
            
        } catch( Exception e ) {  //other exceptions is OK
            builder.up().build();
            
        } finally {
            try {
                if (bufReader != null) {
                    bufReader.close();
                }
                if (httpUrlConn != null) {
                    httpUrlConn.disconnect();
                }
                
            } catch( IOException e ) {
                e.printStackTrace();
            }
        }
    }
    
    @Override
    public boolean getEnableCheck() {
        String getUrl = getUrl();
        if( getUrl == null ){ return false; }
        if( getUrl.length() < 6 ){ return false; }
        
        return super.getEnableCheck();
    }
}
