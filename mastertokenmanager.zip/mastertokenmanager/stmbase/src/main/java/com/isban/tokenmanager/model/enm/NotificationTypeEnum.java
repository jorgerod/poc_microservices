package com.isban.tokenmanager.model.enm;

public enum NotificationTypeEnum {
    OPERATION("0", "OPERATION"), 
    PRODUCTION("1", "PRODUCTION"), 
    OPERATION_PRODUCTION("2", "OPERATION_PRODUCTION");

    private String id;
    private String description;

    NotificationTypeEnum(String id, String description) {
        this.id = id;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
