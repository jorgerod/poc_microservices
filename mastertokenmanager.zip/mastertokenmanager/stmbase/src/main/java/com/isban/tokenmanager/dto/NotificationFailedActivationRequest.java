package com.isban.tokenmanager.dto;

public class NotificationFailedActivationRequest extends NotificationCommonDataRequest {

    private String tokenEventResult;

    public NotificationFailedActivationRequest() {
    }

    public String getTokenEventResult() {
        return tokenEventResult;
    }

    public void setTokenEventResult(String tokenEventResult) {
        this.tokenEventResult = tokenEventResult;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("NotificationFailedActivationRequest [tokenEventResult=").append(tokenEventResult).append("]");
        return builder.toString();
    }

}
