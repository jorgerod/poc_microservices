package com.isban.tokenmanager.dto;

public class NotificationDeactiveRequest extends NotificationCommonDataRequest {

}
