package com.isban.tokenmanager.dto;

/**
 * @author Sergey Zlobin
 * @since 14/09/2015
 */
public class CancelMassiveDto {

    private String issuerId;
    private String tokenTypeId;
    private String customerId;
    private String item;
    private String accountNum;
    private String product;
    private String expiryDate;

    public CancelMassiveDto() {
    }

    public CancelMassiveDto(String issuerId, String tokenTypeId, String customerId, String item, String accountNum,
            String product, String expiryDate) {
        this.issuerId = issuerId;
        this.customerId = customerId;
        this.item = item;
        this.accountNum = accountNum;
        this.product = product;
        this.expiryDate = expiryDate;
        this.tokenTypeId = tokenTypeId;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    @Override
    public String toString() {
        return "CancelMassiveDto{" + "issuerId='" + issuerId + '\'' + ", customerId='" + customerId + '\'' + ", pan='"
                + item + '\'' + ", accountNum='" + accountNum + '\'' + ", product='" + product + '\'' + ", expiryDate='"
                + expiryDate + '\'' + '}';
    }
}
