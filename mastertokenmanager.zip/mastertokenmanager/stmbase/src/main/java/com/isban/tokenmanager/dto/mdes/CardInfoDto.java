package com.isban.tokenmanager.dto.mdes;

public class CardInfoDto extends CardInfoCommonDto {
    /**
    Sample unencrypted object:
    {
        "accountNumber" : "5123456789012345",
        "expiryMonth" : "12",
        "expiryYear" : "15",
        "source" : "CARD_ON_FILE",
        "cardholderName" : "John Doe",
        "securityCode" : "123",
        “cardholderData”: {
            "sourceIp" : "127.0.0.1",
            "deviceLocation" : "38.63, -90.2"
        }
    }
    */
}