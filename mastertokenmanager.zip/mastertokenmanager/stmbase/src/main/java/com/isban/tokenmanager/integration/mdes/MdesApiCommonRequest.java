package com.isban.tokenmanager.integration.mdes;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class MdesApiCommonRequest {

    @ApiModelProperty(value = "Unique identifier for the request.", required = true)
    @NotNull
    @Size(max = 64)
    private String requestId;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

}

