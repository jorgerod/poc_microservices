package com.isban.tokenmanager.integration.pmas;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class ConfirmationHttpRequest {

    private String operationId;
    private String opTime;
    private String tokenId;
    private String customerId;
    private String nrbe;
    private String contract;
    private String amount;
    private String currency;
    private String transactionId;
    private String responseCode;
    private String codPreAuthorization;
    private String retentionId;
    private String terminalId;
    private String commerceId;
    private String commerceName;
    private String commerceAddress;
    private String commerceCity;
    private String commerceState;
    private String commerceCountry;
    private String commercePostalCode;
    private String acquirerId;
    private String forwardingId;

    @ApiModelProperty(value = "Id. of the operation (Numeric)", required = true)
    @Size(max = 4)
    public String getOperationId() {
        return operationId;
    }
    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }

    @ApiModelProperty(value = "Date and Time of the original Operation (CCYY-MM-DDThh:mm:ss format)", required = true)
    @Size(max = 19)
    public String getOpTime() {
        return opTime;
    }
    public void setOpTime(String opTime) {
        this.opTime = opTime;
    }

    @ApiModelProperty(value = "Id. of the token", required = true)
    @Size(max = 32)
    public String getTokenId() {
        return tokenId;
    }
    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    @ApiModelProperty(value = "Customer associates to token", required = true)
    @Size(max = 10)
    public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    @ApiModelProperty(value = "Entity code", required = true)
    @Size(max = 4)
    public String getNrbe() {
        return nrbe;
    }
    public void setNrbe(String nrbe) {
        this.nrbe = nrbe;
    }

    @ApiModelProperty(value = "Partenon Contract Number", required = true)
    @Size(max = 32)
    public String getContract() {
        return contract;
    }
    public void setContract(String contract) {
        this.contract = contract;
    }

    @ApiModelProperty(value = "Amount to withdrawal", required = true)
    @Size(max = 12)    
    @Min(0)
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }

    @ApiModelProperty(value = "Currency of the amount to withdrawal. (ISO 4217)", required = true)
    @Size(max = 3)   
    @Min(0)
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @ApiModelProperty(value = "Unique Id. of transaction", required = true)
    @Size(max = 19)   
     public String getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    @ApiModelProperty(value = "Response code given to withdrawal", required = true)
    @Size(max = 2)   
    public String getResponseCode() {
        return responseCode;
    }
    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    @ApiModelProperty(value = "Authorization Code received in the pre-authorization", required = true)
    @Size(max = 10)   
    public String getCodPreAuthorization() {
        return codPreAuthorization;
    }
    public void setCodPreAuthorization(String codPreAuthorization) {
        this.codPreAuthorization = codPreAuthorization;
    }

    @ApiModelProperty(value = "Unique id. of retention received in the pre-authorization", required = true)
    @Size(max = 20)   
    public String getRetentionId() {
        return retentionId;
    }
    public void setRetentionId(String retentionId) {
        this.retentionId = retentionId;
    }

    @ApiModelProperty(value = "Identification of the terminal for withdrawal", required = true)
    @Size(max = 10)   
    public String getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    @ApiModelProperty(value = "Identification of the commerce of the terminal", required = true)
    @Size(max = 10)   
    public String getCommerceId() {
        return commerceId;
    }
    public void setCommerceId(String commerceId) {
        this.commerceId = commerceId;
    }

    @ApiModelProperty(value = "Name of the commerce", required = false)
    @Size(max = 15)   
    public String getCommerceName() {
        return commerceName;
    }
    public void setCommerceName(String commerceName) {
        this.commerceName = commerceName;
    }

    @ApiModelProperty(value = "Address of the commerce", required = true)
    @Size(max = 25)   
    public String getCommerceAddress() {
        return commerceAddress;
    }
    public void setCommerceAddress(String commerceAddress) {
        this.commerceAddress = commerceAddress;
    }

    @ApiModelProperty(value = "City of the commerce", required = false)
    @Size(max = 15)   
    public String getCommerceCity() {
        return commerceCity;
    }
    public void setCommerceCity(String commerceCity) {
        this.commerceCity = commerceCity;
    }

    @ApiModelProperty(value = "State of the commerce", required = false)
    @Size(max = 2)   
    public String getCommerceState() {
        return commerceState;
    }
    public void setCommerceState(String commerceState) {
        this.commerceState = commerceState;
    }

    @ApiModelProperty(value = "Country of the commerce", required = true)
    @Size(max = 3)   
    public String getCommerceCountry() {
        return commerceCountry;
    }
    public void setCommerceCountry(String commerceCountry) {
        this.commerceCountry = commerceCountry;
    }

    @ApiModelProperty(value = "Postal code of the commerce", required = false)
    @Size(max = 10)   
    public String getCommercePostalCode() {
        return commercePostalCode;
    }
    public void setCommercePostalCode(String commercePostalCode) {
        this.commercePostalCode = commercePostalCode;
    }

    @ApiModelProperty(value = "Identifies the acquiring institution", required = true)
    @Size(max = 12)   
    public String getAcquirerId() {
        return acquirerId;
    }
    public void setAcquirerId(String acquirerId) {
        this.acquirerId = acquirerId;
    }

    @ApiModelProperty(value = "Identifies the institution forwarding a Request", required = false)
    @Size(max = 12)   
    public String getForwardingId() {
        return forwardingId;
    }
    public void setForwardingId(String forwardingId) {
        this.forwardingId = forwardingId;
    }
}
