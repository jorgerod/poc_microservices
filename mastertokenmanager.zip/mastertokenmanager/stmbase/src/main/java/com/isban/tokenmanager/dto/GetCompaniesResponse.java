package com.isban.tokenmanager.dto;

import java.util.List;

public class GetCompaniesResponse extends ResponseBase {

    private List<String> companyList;

    public GetCompaniesResponse(String code, String description) {
        super(code, description);
    }

    public GetCompaniesResponse() {
    }

    public List<String> getCompanyList() {
        return companyList;
    }

    public void setCompanyList(List<String> companyList) {
        this.companyList = companyList;
    }
}
