package com.isban.tokenmanager.integration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.isban.tokenmanager.exception.TokenManagerException;

public abstract class GetGateway<I, O> {

    protected String url;
    protected int connectTimeout;
    protected int readTimeout;

    private final Class<O> typeOutputClass;

    @Autowired
    private RestTemplate restTemplate;

    public GetGateway(Class<O> typeOutputParamClass) {
        this.typeOutputClass = typeOutputParamClass;
    }

    public abstract void configureParameters();

    public O execute(String uri) throws TokenManagerException {

        O ret = null;
        try {
            if (restTemplate.getRequestFactory() instanceof SimpleClientHttpRequestFactory) {
                ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(readTimeout);
                ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(connectTimeout);
            
            } else {
                SimpleClientHttpRequestFactory s = new SimpleClientHttpRequestFactory();
                s.setReadTimeout(readTimeout);
                s.setConnectTimeout(connectTimeout);

                restTemplate.setRequestFactory(s);
            }
            ret = restTemplate.getForObject(uri, typeOutputClass);

        } catch (Exception ex) {
            System.out.println();
            throw new TokenManagerException(TokenManagerException.CONNECT_EXCEPTION, ex.getMessage(), ex);
        }
        return ret;
    }

    public O executeGetTextMessage(String textId, String keysValues) throws TokenManagerException {

        configureParameters(); // TODO
        O ret = null;
        url = url + "/" + textId + "/";

        try {
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
            if (!"".equals(keysValues) && !"[]".equals(keysValues))
                builder.queryParam("params", keysValues);
            ret = execute(builder.toUriString());
        } catch (Exception ex) {
            System.out.println();
            throw new TokenManagerException(TokenManagerException.CONNECT_EXCEPTION, ex.getMessage(), ex);
        }

        return ret;
    }

    public O executeGetTextMessage(String textId) throws TokenManagerException {

        configureParameters(); // TODO

        O ret = null;
        try {
            ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(readTimeout);
            ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(connectTimeout);

            url = url + "/" + textId;

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
            ret = restTemplate.getForObject(builder.toUriString(), typeOutputClass);

        } catch (Exception ex) {
            System.out.println();
            throw new TokenManagerException(TokenManagerException.CONNECT_EXCEPTION, ex.getMessage(), ex);
        }
        return ret;
    }

}
