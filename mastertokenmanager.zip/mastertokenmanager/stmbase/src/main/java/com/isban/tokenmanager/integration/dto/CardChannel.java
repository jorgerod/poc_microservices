package com.isban.tokenmanager.integration.dto;


public class CardChannel {
    String pan;
    String schemeId;


    public CardChannel() {

    }

    public CardChannel(String pan, String schemeId) {
        super();
        this.pan = pan;
        this.schemeId = schemeId;
    }

    public String getItem() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getSchemeId() {
        return schemeId;
    }

    public void setSchemeId(String schemeId) {
        this.schemeId = schemeId;
    }

    @Override
    public String toString() {
        return "CardChannel [pan=" + pan + ", schemeId=" + schemeId + "]";
    }

}
