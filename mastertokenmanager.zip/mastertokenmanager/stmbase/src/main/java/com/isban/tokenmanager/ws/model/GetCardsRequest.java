
package com.isban.tokenmanager.ws.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="issuerid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="client" type="{http://www.isban.com/tokenmanager/ws/model}ClientType"/>
 *         &lt;element name="walletid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="channelframe" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="multichannelcontract" type="{http://www.isban.com/tokenmanager/ws/model}MultiChannelContractType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "issuerid",
    "client",
    "walletid",
    "channelframe",
    "multichannelcontract"
})
@XmlRootElement(name = "getCardsRequest")
public class GetCardsRequest {

    @XmlElement(required = true)
    protected String issuerid;
    @XmlElement(required = true)
    protected ClientType client;
    @XmlElement(required = true)
    protected String walletid;
    protected String channelframe;
    protected MultiChannelContractType multichannelcontract;

    /**
     * Obtiene el valor de la propiedad issuerid.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuerid() {
        return issuerid;
    }

    /**
     * Define el valor de la propiedad issuerid.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuerid(String value) {
        this.issuerid = value;
    }

    /**
     * Obtiene el valor de la propiedad client.
     * 
     * @return
     *     possible object is
     *     {@link ClientType }
     *     
     */
    public ClientType getClient() {
        return client;
    }

    /**
     * Define el valor de la propiedad client.
     * 
     * @param value
     *     allowed object is
     *     {@link ClientType }
     *     
     */
    public void setClient(ClientType value) {
        this.client = value;
    }

    /**
     * Obtiene el valor de la propiedad walletid.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWalletid() {
        return walletid;
    }

    /**
     * Define el valor de la propiedad walletid.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWalletid(String value) {
        this.walletid = value;
    }

    /**
     * Obtiene el valor de la propiedad channelframe.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelframe() {
        return channelframe;
    }

    /**
     * Define el valor de la propiedad channelframe.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelframe(String value) {
        this.channelframe = value;
    }

    /**
     * Obtiene el valor de la propiedad multichannelcontract.
     * 
     * @return
     *     possible object is
     *     {@link MultiChannelContractType }
     *     
     */
    public MultiChannelContractType getMultichannelcontract() {
        return multichannelcontract;
    }

    /**
     * Define el valor de la propiedad multichannelcontract.
     * 
     * @param value
     *     allowed object is
     *     {@link MultiChannelContractType }
     *     
     */
    public void setMultichannelcontract(MultiChannelContractType value) {
        this.multichannelcontract = value;
    }

}
