package com.isban.tokenmanager.util.batch;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.isban.tokenmanager.dto.IssuerDto;
import com.isban.tokenmanager.dto.ResponseEvent;
import com.isban.tokenmanager.exception.ExceptionUtil;
import com.isban.tokenmanager.model.enm.ResponseStateEnum;
import com.isban.tokenmanager.util.CommonUtil;

public class BatchCommon {
    static final Logger logger = Logger.getLogger(BatchCommon.class);
    
    @Value("${files.path.base}")
    protected String pathBase;
    @Value("${files.toprocess.path.part0}")
    protected String part0toprocess;
    @Value("${files.processed.ok.path.part0}")
    protected String part0processedOk;
    @Value("${files.processed.ko.path.part0}")
    protected String part0processedKo;
    @Value("${files.import.path.part1}")
    protected String part1import;
    @Value("${files.export.path.part1}")
    protected String part1export;
    @Value("${files.path.reports}")
    protected String reports;
    
    private Path pathBasePath;
    private Path toProcessPath;
    private Path processedOkPath;
    private Path processedKoPath;
    private Path toProcessImportPath;

    @Autowired
    protected CommonUtil commonUtil;
    @Autowired
    protected ExceptionUtil exceptionUtil;
    
    public Path getPathBasePath(){
        if( pathBasePath != null ){ return pathBasePath; }
        pathBasePath = Paths.get( pathBase );
        return pathBasePath;
    }
    
    public Path getToProcessPath(){
        if( toProcessPath != null ){ return toProcessPath; }
        toProcessPath = Paths.get( pathBase, part0toprocess );
        return toProcessPath;
    }
    
    public Path getProcessedOkPath(){
        if( processedOkPath != null ){ return processedOkPath; }
        processedOkPath = Paths.get( pathBase, part0processedOk );
        return processedOkPath;
    }
    
    public Path getProcessedKoPath(){
        if( processedKoPath != null ){ return processedKoPath; }
        processedKoPath = Paths.get( pathBase, part0processedKo );
        return processedKoPath;
    }
    
    public Path getToProcessImportPath(){
        if( toProcessImportPath != null ){ return toProcessImportPath; }
        toProcessImportPath = Paths.get( pathBase, part0toprocess, part1import );
        return toProcessImportPath;
    }
    
    public List<File> getFilesToProccess( IssuerDto issuerDto ) {
        List<File> ret = new ArrayList<File>();
        try {
            String folderPath = "" + getToProcessImportPath() + File.separator + issuerDto.getIssuerId();
            File folder = new File( folderPath );
            
            for( File file : folder.listFiles() ) {
                if (file.isFile()) {
                    ret.add(file);
                    logger.info("getFilesToProccess::file= " + file);
                }
            }
            
        } catch( Exception e ) {
            exceptionUtil.logException(e, logger);
        }
        
        return ret;
    }
    
    public ResponseEvent processKo(  
            Logger logger,
            Path file  ) {
        ResponseEvent responseAlert = new ResponseEvent(ResponseStateEnum.KO);
        responseAlert = processKo( responseAlert, null, logger, file );
        return responseAlert;
    }
    
    public ResponseEvent processKo(  
            Exception e, 
            Logger logger,
            Path file  ) {
        ResponseEvent responseAlert = new ResponseEvent(ResponseStateEnum.KO);
        responseAlert = processKo( responseAlert, e, logger, file );
        return responseAlert;
    }
    
    public ResponseEvent processKo(  
            ResponseEvent responseAlert,
            Exception e, 
            Logger logger,
            Path file  ) {
        responseAlert = processKo( responseAlert, e, logger, file, "" );
        return responseAlert;
    }
    
    public ResponseEvent processKo(  
            ResponseEvent responseAlert, 
            Exception e, 
            Logger logger, 
            Path file, 
            String extraMsg  ) {
        exceptionUtil.logException( e, logger );
        logger.error(extraMsg);
        responseAlert.setResponseState(ResponseStateEnum.KO);
        responseAlert = processResponseEvent(responseAlert, file);
        return responseAlert;
    }
    
    public ResponseEvent processKo( Path file ) {
        ResponseEvent responseAlert = new ResponseEvent(ResponseStateEnum.KO);
        responseAlert = processResponseEvent(responseAlert, file);
        return responseAlert;
    }
    
    public ResponseEvent processOK( Path file ) {
        ResponseEvent responseAlert = new ResponseEvent(ResponseStateEnum.OK);
        responseAlert = processResponseEvent(responseAlert, file);
        return responseAlert;
    }
    
    public ResponseEvent processResponseEvent( 
            ResponseEvent responseAlert,
            Path file  ){
        Path targetBasePath = getProcessedKoPath();
        if(ResponseStateEnum.OK.equals( responseAlert.getResponseState() )){
            targetBasePath = getProcessedOkPath();
        }
        commonUtil.structuredmoveFile(  
                getToProcessPath(), 
                file, 
                targetBasePath  );
        
        return responseAlert;
    }

}
