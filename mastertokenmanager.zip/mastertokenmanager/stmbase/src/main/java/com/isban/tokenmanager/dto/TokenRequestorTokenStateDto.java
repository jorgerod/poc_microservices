package com.isban.tokenmanager.dto;

public class TokenRequestorTokenStateDto extends ModelBaseDto {

    private String tokenRequestorId = null;
    private String tokenStateId = null;
    private String tokenStateName = null;
    private Boolean sendNotification = false;
    
    public String getTokenRequestorId() {
        return tokenRequestorId;
    }
    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }
    public String getTokenStateId() {
        return tokenStateId;
    }
    public void setTokenStateId(String tokenStateId) {
        this.tokenStateId = tokenStateId;
    }
    public String getTokenStateName() {
        return tokenStateName;
    }
    public void setTokenStateName(String tokenStateName) {
        this.tokenStateName = tokenStateName;
    }
    public Boolean getSendNotification() {
        return sendNotification;
    }
    public void setSendNotification(Boolean sendNotification) {
        this.sendNotification = sendNotification;
    }
    
}
