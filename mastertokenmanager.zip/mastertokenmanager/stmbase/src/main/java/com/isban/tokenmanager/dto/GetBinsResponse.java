package com.isban.tokenmanager.dto;

import java.util.List;

public class GetBinsResponse extends ResponseBase {

    private List<BinDto> bins;

    public GetBinsResponse() {
    }

    public GetBinsResponse(String code, String description) {
        super(code, description);
    }

    public List<BinDto> getBins() {
        return bins;
    }

    public void setBins(List<BinDto> bins) {
        this.bins = bins;
    }

    @Override
    public String toString() {
        return "GetBinsResponse [bins=" + bins + "]";
    }

}
