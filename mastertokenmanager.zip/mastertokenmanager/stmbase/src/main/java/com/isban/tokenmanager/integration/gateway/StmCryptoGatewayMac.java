package com.isban.tokenmanager.integration.gateway;

import org.springframework.stereotype.Component;

import com.isban.tokenmanager.config.StmCryptoProperties;
import com.isban.tokenmanager.integration.PostGateway;
import com.isban.tokenmanager.stmcrypto.dto.GenerateMacInput;
import com.isban.tokenmanager.stmcrypto.dto.GenerateMacOutput;

@Component
public class StmCryptoGatewayMac extends PostGateway<GenerateMacInput, GenerateMacOutput> {
    
//  @Value("${stmcrypto.macEndpointUrl}")
  private String url;
  
  private int connectTimeout = 300000;
  private int readTimeout = 300000;

  public StmCryptoGatewayMac(StmCryptoProperties stmCryptoProperties) {
      super(GenerateMacOutput.class);
      url = stmCryptoProperties.getMacEndpointUrl();
  }

  @Override
  public void configureParameters() {
      super.url = this.url;
      super.connectTimeout = this.connectTimeout;
      super.readTimeout = this.readTimeout;
  }
}
