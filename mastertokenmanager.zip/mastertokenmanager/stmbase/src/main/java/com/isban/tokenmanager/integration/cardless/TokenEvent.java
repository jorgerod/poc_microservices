package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.isban.tokenmanager.util.Constants;

import io.swagger.annotations.ApiModelProperty;

public class TokenEvent {
    
    String eventTime;
    String newState;
    String eventBranchOffice;
    String eventUserId;
    String comment;
    
    @ApiModelProperty(value = "Date and time of the event", required = true)
    @Pattern(regexp = Constants.PATTERN_DATETIME)
    @Size(max = 19)    
    public String getEventTime() {
        return eventTime;
    }
    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }

    @ApiModelProperty(value = "New state of the token associated to the event.", required = true)
    @Pattern(regexp="\\d+")
    @Size(max = 2)
    public String getNewState() {
        return newState;
    }
    public void setNewState(String newState) {
        this.newState = newState;
    }

    @ApiModelProperty(value = "Branch Office where the event was generates.", required = false)
    @Size(max = 4)
    public String getEventBranchOffice() {
        return eventBranchOffice;
    }
    public void setEventBranchOffice(String eventBranchOffice) {
        this.eventBranchOffice = eventBranchOffice;
    }
    
    @ApiModelProperty(value = "Id of the user that generates the event.", required = false)
    @Size(max = 10)
    public String getEventUserId() {
        return eventUserId;
    }
    public void setEventUserId(String eventUserId) {
        this.eventUserId = eventUserId;
    }

    @ApiModelProperty(value = "Comment associated to the event.", required = false)
    @Size(max = 30)
    public String getComment() {
        return comment;
    }
    public void setComment(String comment) {
        this.comment = comment;
    }
}
