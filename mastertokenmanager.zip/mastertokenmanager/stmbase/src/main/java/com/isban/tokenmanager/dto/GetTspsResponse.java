package com.isban.tokenmanager.dto;

import java.util.List;

public class GetTspsResponse extends ResponseBase {

    private List<TspDto> tsps;

    public GetTspsResponse() {
    }

    public GetTspsResponse(String code, String description) {
        super(code, description);
    }

    public List<TspDto> getTsps() {
        return tsps;
    }

    public void setTsps(List<TspDto> tsps) {
        this.tsps = tsps;
    }

}
