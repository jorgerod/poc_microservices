package com.isban.tokenmanager.dto;

import java.util.List;



public class SearchIssuerDto extends LifeTimeDto {

    private String issuerDescription;
    private Integer timeClearRequestPending;
    private String issuerName;
    private String cardArtPath;
    private String administratorMail;

    private Integer timeClearEvents;// days

    private Integer timeMmSmsDelay; //minutes. Tiempo minimo desde aprobacion a notificacion vía SMS a cliente.
    private String tokenLimitUseHour; //Hora del dia "maxima" para aprobar un token. 
    private Integer timeMaxResolutionToken; //Tiempo maximo para validar un token (en minutos) 0 -> Aprobar directament, 9999 -> Sin límite.
    private Integer timeMaxConsumeToken;//Tiempo maximo para consumir el token tras activarlo (en minutos)
    
    private String tokenInitialStateId;
    private String tokenInitialStateName;
    private String tokenResolutionPerDefaultStateId;
    private String tokenResolutionPerDefaultStateName;
    
    private Boolean activeTokenLimitHourRule;
    private Boolean activeTimeMaxResolutionTokenRule; 
    private Boolean activeTimeMaxConsumeTokenRule;
    
    private List<SearchIssuerTokenTypeTrDto> issuerWalletList;
    
    public String getIssuerDescription() {
        return issuerDescription;
    }

    public void setIssuerDescription(String issuerDescription) {
        this.issuerDescription = issuerDescription;
    }

    public Integer getTimeClearRequestPending() {
        return timeClearRequestPending;
    }

    public void setTimeClearRequestPending(Integer timeClearRequestPending) {
        this.timeClearRequestPending = timeClearRequestPending;
    }

    public String getIssuerName() {
        return issuerName;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public String getCardArtPath() {
        return cardArtPath;
    }

    public void setCardArtPath(String cardArtPath) {
        this.cardArtPath = cardArtPath;
    }

    public List<SearchIssuerTokenTypeTrDto> getIssuerWalletList() {
        return issuerWalletList;
    }

    public void setIssuerWalletList(List<SearchIssuerTokenTypeTrDto> issuerWalletList) {
        this.issuerWalletList = issuerWalletList;
    }

    public String getAdministratorMail() {
        return administratorMail;
    }

    public void setAdministratorMail(String administratorMail) {
        this.administratorMail = administratorMail;
    }

    public Integer getTimeClearEvents() {
        return timeClearEvents;
    }

    public void setTimeClearEvents(Integer timeClearEvents) {
        this.timeClearEvents = timeClearEvents;
    }

    public Integer getTimeMmSmsDelay() {
        return timeMmSmsDelay;
    }

    public void setTimeMmSmsDelay(Integer timeMmSmsDelay) {
        this.timeMmSmsDelay = timeMmSmsDelay;
    }

    public String getTokenLimitUseHour() {
        return tokenLimitUseHour;
    }

    public void setTokenLimitUseHour(String tokenLimitUseHour) {
        this.tokenLimitUseHour = tokenLimitUseHour;
    }

    public Integer getTimeMaxResolutionToken() {
        return timeMaxResolutionToken;
    }

    public void setTimeMaxResolutionToken(Integer timeMaxResolutionToken) {
        this.timeMaxResolutionToken = timeMaxResolutionToken;
    }

    public Integer getTimeMaxConsumeToken() {
        return timeMaxConsumeToken;
    }

    public void setTimeMaxConsumeToken(Integer timeMaxConsumeToken) {
        this.timeMaxConsumeToken = timeMaxConsumeToken;
    }

    public String getTokenInitialStateId() {
        return tokenInitialStateId;
    }

    public void setTokenInitialStateId(String tokenInitialStateId) {
        this.tokenInitialStateId = tokenInitialStateId;
    }

    public String getTokenInitialStateName() {
        return tokenInitialStateName;
    }

    public void setTokenInitialStateName(String tokenInitialStateName) {
        this.tokenInitialStateName = tokenInitialStateName;
    }

    public String getTokenResolutionPerDefaultStateId() {
        return tokenResolutionPerDefaultStateId;
    }

    public void setTokenResolutionPerDefaultStateId(String tokenResolutionPerDefaultStateId) {
        this.tokenResolutionPerDefaultStateId = tokenResolutionPerDefaultStateId;
    }

    public String getTokenResolutionPerDefaultStateName() {
        return tokenResolutionPerDefaultStateName;
    }

    public void setTokenResolutionPerDefaultStateName(String tokenResolutionPerDefaultStateName) {
        this.tokenResolutionPerDefaultStateName = tokenResolutionPerDefaultStateName;
    }

    public Boolean getActiveTokenLimitHourRule() {
        return activeTokenLimitHourRule;
    }

    public void setActiveTokenLimitHourRule(Boolean activeTokenLimitHourRule) {
        this.activeTokenLimitHourRule = activeTokenLimitHourRule;
    }

    public Boolean getActiveTimeMaxResolutionTokenRule() {
        return activeTimeMaxResolutionTokenRule;
    }

    public void setActiveTimeMaxResolutionTokenRule(Boolean activeTimeMaxResolutionTokenRule) {
        this.activeTimeMaxResolutionTokenRule = activeTimeMaxResolutionTokenRule;
    }

    public Boolean getActiveTimeMaxConsumeTokenRule() {
        return activeTimeMaxConsumeTokenRule;
    }

    public void setActiveTimeMaxConsumeTokenRule(Boolean activeTimeMaxConsumeTokenRule) {
        this.activeTimeMaxConsumeTokenRule = activeTimeMaxConsumeTokenRule;
    }


}
