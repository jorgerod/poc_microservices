package com.isban.tokenmanager.integration.dto;

import java.util.ArrayList;
import java.util.List;

import com.isban.tokenmanager.dto.ModelBaseDto;
import com.isban.tokenmanager.dto.TokenRequestorTokenStateDto;

public class UpdateTrTokenStatesHttpRequest extends ModelBaseDto {

    private String tokenRequestorId = null;
    private List<TokenRequestorTokenStateDto> states = new ArrayList<TokenRequestorTokenStateDto>();

    public List<TokenRequestorTokenStateDto> getStates() {
        return states;
    }

    public void setStates(List<TokenRequestorTokenStateDto> states) {
        this.states = states;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

}
