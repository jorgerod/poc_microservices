package com.isban.tokenmanager.integration.hubdigital;

public class HubdigitalCommonResponse {
    
    private HubDigitalInfoResponse info = new HubDigitalInfoResponse();
    private String mac;
    
    
    public HubDigitalInfoResponse getInfo() {
        return info;
    }
    public void setInfo(HubDigitalInfoResponse info) {
        this.info = info;
    }
    public String getMac() {
        return mac;
    }
    public void setMac(String mac) {
        this.mac = mac;
    }
}
