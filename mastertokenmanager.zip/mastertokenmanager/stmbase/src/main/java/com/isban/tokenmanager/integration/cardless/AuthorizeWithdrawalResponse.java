package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class AuthorizeWithdrawalResponse extends WithdrawalResponse {

    private String amount;
    private String currency;

    public AuthorizeWithdrawalResponse(String code, String description) {
        super(code, description);
    }

    public AuthorizeWithdrawalResponse() {
        super();
    }

    @ApiModelProperty(value = "Amount to withdrawal", required = false)
    @Size(max = 12)    
    @Min(0)
    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    @ApiModelProperty(value = "Currency of the amount to withdrawal. (ISO 4217)", required = false)
    @Size(max = 3)   
    @Min(0)
   public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
