package com.isban.tokenmanager.integration.hubdigital;

public class NotificationHttpResponse extends HubdigitalCommonResponse {

}
