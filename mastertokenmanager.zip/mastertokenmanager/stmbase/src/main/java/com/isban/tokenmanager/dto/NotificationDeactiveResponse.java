package com.isban.tokenmanager.dto;

public class NotificationDeactiveResponse extends ResponseBase {

    public NotificationDeactiveResponse() {
    }

    public NotificationDeactiveResponse(String code, String description) {
        super(code, description);
    }
}
