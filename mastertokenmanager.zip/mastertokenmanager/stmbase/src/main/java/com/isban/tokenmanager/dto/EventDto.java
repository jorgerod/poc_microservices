package com.isban.tokenmanager.dto;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.isban.tokenmanager.exception.TokenManagerException;
import com.isban.tokenmanager.model.ModelBase;
import com.isban.tokenmanager.model.enm.EventTypeEnum;
import com.isban.tokenmanager.model.enm.NotificationTypeEnum;
import com.isban.tokenmanager.util.Constants;

public class EventDto extends ModelBaseDto {
    private static final Logger logger = Logger.getLogger(EventDto.class);

    private String transactionId;
    private long operationTime;

    private String eventTypeId;
    private String eventDescription;
    private String issuerName;
    private String serviceId;
    private String serviceName;

    private String notificationTypeId;

    private String data = null;

    private Date operationDate = null;
    private String observations = null;

    /**
     * Default, the value of AlertStateEnum is Not_Resolved
     *
     * @param eventEnum
     */
    public EventDto(EventTypeEnum eventEnum) {
        super();
        this.initEvent();

        this.eventTypeId = eventEnum.getCode();
        this.notificationTypeId = NotificationTypeEnum.OPERATION_PRODUCTION.getId();
    }


    public EventDto(EventTypeEnum eventEnum, Exception e, String issuerId, String tokenTypeId) {
        this(eventEnum, "KO" , issuerId, tokenTypeId, "", NotificationTypeEnum.OPERATION_PRODUCTION);
        
        this.observations = TokenManagerException.class.isInstance(e) ? ((TokenManagerException) e).getDescription()
                : e.getStackTrace() != null ? ExceptionUtils.getStackTrace(e)
                        : e.getMessage() != null ? e.getMessage() : e.getClass().toString();
                        
        this.observations = observations != null && observations.length() > Constants.OBSERVATIONS_LENGTH
                ? observations.substring(0, Constants.OBSERVATIONS_LENGTH) : observations;
    }

    public EventDto(EventTypeEnum eventEnum, Object objData, String issuerId, String tokenTypeId, String observations,
            NotificationTypeEnum notificatioType) {
        super();
        this.initEvent();
        this.eventTypeId = eventEnum.getCode();
        this.setIssuerId(issuerId);
        this.setTokenTypeId(tokenTypeId);
        this.observations = observations;
        this.notificationTypeId = notificatioType.getId();

        try {

            this.data = getMapper(objData).writeValueAsString(objData);
        } catch (JsonProcessingException e) {
            logger.error(objData, e);
        }
    }
    
    public EventDto(EventTypeEnum eventEnum, ModelBaseDto modelBaseDto, String observations,
            NotificationTypeEnum notificatioType) {
        super();
        this.initEvent();
        this.eventTypeId = eventEnum.getCode();
        this.setIssuerId(modelBaseDto.getIssuerId());
        this.setTokenTypeId(modelBaseDto.getTokenTypeId());
        this.observations = observations;
        this.notificationTypeId = notificatioType.getId();

        try {

            this.data = getMapper(modelBaseDto).writeValueAsString(modelBaseDto);
        } catch (JsonProcessingException e) {
            logger.error(modelBaseDto, e);
        }
    }

    private ObjectMapper getMapper(Object objData) {
        ObjectMapper ret = new ObjectMapper();

        if (objData instanceof ModelBase) {
            ret = new ObjectMapper();
            ret.addMixIn(Set.class, StmMixInForSetOrList.class);
            ret.addMixIn(List.class, StmMixInForSetOrList.class);
        }

        ret.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        ret.setSerializationInclusion(Include.NON_NULL);

        return ret;
    }

    // @Deprecated
    // public EventDto(EventTypeEnum eventEnum, Object objData, String issuerId,
    // String observations) {
    // this(eventEnum, objData, issuerId, observations,
    // NotificationTypeEnum.OPERATION_PRODUCTION);
    // }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getEventTypeId() {
        return eventTypeId;
    }

    public void setEventTypeId(String eventTypeId) {
        this.eventTypeId = eventTypeId;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    // public void setOperationDate(Date operationDate) {
    // this.operationDate = operationDate;
    // }

    public String getIssuerName() {
        return issuerName;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getObservations() {
        return observations;
    }

    public void setObservations(String observations) {
        this.observations = observations;
    }

    public String getNotificationTypeId() {
        return notificationTypeId;
    }

    public void setNotificationTypeId(String notificationTypeId) {
        this.notificationTypeId = notificationTypeId;
    }

    public long getOperationTime() {
        return operationTime;
    }

    public void initEvent() {
        DateTime dateTime = new DateTime();

        this.operationTime = dateTime.getMillis();
        this.operationDate = dateTime.toDate();
    }

}
