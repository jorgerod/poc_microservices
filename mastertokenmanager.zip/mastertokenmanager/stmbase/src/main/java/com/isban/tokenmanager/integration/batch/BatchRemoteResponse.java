package com.isban.tokenmanager.integration.batch;

import java.util.ArrayList;
import java.util.List;

import com.isban.tokenmanager.dto.ResponseEvent;
import com.isban.tokenmanager.model.enm.ResponseStateEnum;

public class BatchRemoteResponse extends ResponseEvent {
    public List<Object> data = new ArrayList<>();

    public BatchRemoteResponse() {
        super(ResponseStateEnum.KO);
    }
    
    public BatchRemoteResponse(ResponseStateEnum responseStateEnum) {
        super(responseStateEnum);
    }

    public BatchRemoteResponse(ResponseEvent responseAlert) {
        super(ResponseStateEnum.KO);
        if(responseAlert != null){
            setResponseState(responseAlert.getResponseState());
            setEventsDto(responseAlert.getEventsDto());
        }
    }

    public List<Object> getData() {
        return data;
    }
    public void setData(List<Object> d) {
        data = d;
    }
}
