package com.isban.tokenmanager.util;

import java.nio.charset.Charset;

import org.springframework.core.io.ClassPathResource;

import com.csvreader.CsvReader;

public class FileLoadBase {
    public CsvReader getReader(String fileName) {
        ClassPathResource res = new ClassPathResource( "files/" + fileName );
        CsvReader reader = null;
        try {
            reader = new CsvReader( 
                    res.getInputStream(), 
                    ';', 
                    Charset.forName( "ISO-8859-1" ) );
            reader.readHeaders();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return reader;
    }
}
