package com.isban.tokenmanager.dto.mdes;

import java.util.List;

import javax.validation.constraints.Size;

import com.isban.tokenmanager.dto.mdes.enm.DecisionMdesEnum;

public class DecisioningInfoDto {
 
    @Size(max = 64)
    private DecisionMdesEnum recommendedDecision; // APPROVED, DECLINED, REQUIRE_ADDITIONAL_AUTHENTICATION
    @Size(max = 64)
    private String recommendationStandardVersion; 
    @Size(max = 64)
    private String deviceScore; 
    @Size(max = 64)
    private String accountScore; 
    private List<String> recommendationReasons; //if APPROVED: LONG_ACCOUNT_TENURE, GOOD_ACTIVITY_HISTORY, ADDITIONAL_DEVICE, SOFTWARE_UPDATE
                                                //if REQUIRE_ADDITIONAL_AUTHENTICATION or DECLINED: see APENDIX C.2
    public DecisionMdesEnum getRecommendedDecision() {
        return recommendedDecision;
    }
    public void setRecommendedDecision(DecisionMdesEnum recommendedDecision) {
        this.recommendedDecision = recommendedDecision;
    }
    public String getRecommendationStandardVersion() {
        return recommendationStandardVersion;
    }
    public void setRecommendationStandardVersion(String recommendationStandardVersion) {
        this.recommendationStandardVersion = recommendationStandardVersion;
    }
    public String getDeviceScore() {
        return deviceScore;
    }
    public void setDeviceScore(String deviceScore) {
        this.deviceScore = deviceScore;
    }
    public String getAccountScore() {
        return accountScore;
    }
    public void setAccountScore(String accountScore) {
        this.accountScore = accountScore;
    }
    public List<String> getRecommendationReasons() {
        return recommendationReasons;
    }
    public void setRecommendationReasons(List<String> recommendationReasons) {
        this.recommendationReasons = recommendationReasons;
    }
   
}