package com.isban.tokenmanager.dto;

import java.util.List;

public class BrandBinResponse extends ResponseBase {

    private List<BrandBinDto> brandBins;

    public BrandBinResponse(String code, String description) {
        super(code, description);
    }

    public BrandBinResponse() {
    }

    public List<BrandBinDto> getBrandBins() {
        return brandBins;
    }

    public void setBrandBins(List<BrandBinDto> brandBins) {
        this.brandBins = brandBins;
    }

}   
