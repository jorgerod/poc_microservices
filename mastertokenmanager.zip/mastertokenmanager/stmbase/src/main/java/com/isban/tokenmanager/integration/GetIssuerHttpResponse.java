package com.isban.tokenmanager.integration;

import com.isban.tokenmanager.dto.IssuerDto;
import com.isban.tokenmanager.dto.ResponseBase;
import com.isban.tokenmanager.integration.dto.IntegrationResponseBase;

public class GetIssuerHttpResponse  extends IntegrationResponseBase<IssuerDto> {
    public GetIssuerHttpResponse() {
        super();
    }

    public GetIssuerHttpResponse(String codeResponse, String desResponse) {
        super(codeResponse, desResponse);
    }

    public GetIssuerHttpResponse(ResponseBase responseBase) {
        super(responseBase);
    }
}
