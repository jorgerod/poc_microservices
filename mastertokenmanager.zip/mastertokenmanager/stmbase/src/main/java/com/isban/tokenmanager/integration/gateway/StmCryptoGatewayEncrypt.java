package com.isban.tokenmanager.integration.gateway;

import org.springframework.stereotype.Component;

import com.isban.tokenmanager.config.StmCryptoProperties;
import com.isban.tokenmanager.integration.PostGateway;
import com.isban.tokenmanager.stmcrypto.dto.EncryptDataInput;
import com.isban.tokenmanager.stmcrypto.dto.EncryptDataOutput;

@Component
public class StmCryptoGatewayEncrypt extends PostGateway<EncryptDataInput, EncryptDataOutput> {
    
  private String url = "";
  
  private int connectTimeout = 300000;
  private int readTimeout = 300000;

  public StmCryptoGatewayEncrypt(StmCryptoProperties stmCryptoProperties) {
      super(EncryptDataOutput.class);
      url = stmCryptoProperties.getEncryptEndpointUrl();
  }

  @Override
  public void configureParameters() {
      super.url = this.url;
      super.connectTimeout = this.connectTimeout;
      super.readTimeout = this.readTimeout;
  }
}
