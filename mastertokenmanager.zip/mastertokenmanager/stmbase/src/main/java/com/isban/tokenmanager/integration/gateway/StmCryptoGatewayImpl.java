package com.isban.tokenmanager.integration.gateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.isban.tokenmanager.exception.TokenManagerException;
import com.isban.tokenmanager.stmcrypto.dto.DecryptDataInput;
import com.isban.tokenmanager.stmcrypto.dto.DecryptDataOutput;
import com.isban.tokenmanager.stmcrypto.dto.EncryptDataInput;
import com.isban.tokenmanager.stmcrypto.dto.EncryptDataOutput;
import com.isban.tokenmanager.stmcrypto.dto.GenerateMacInput;
import com.isban.tokenmanager.stmcrypto.dto.GenerateMacOutput;
import com.isban.tokenmanager.stmcrypto.dto.VerifyMacInput;
import com.isban.tokenmanager.stmcrypto.dto.VerifyMacOutput;

@Component
public class StmCryptoGatewayImpl implements StmCryptoGateway {

    @Autowired
    private StmCryptoGatewayEncrypt stmTspGatewayEncrypt;
    
    @Autowired
    private StmCryptoGatewayDecrypt stmTspGatewayDecrypt;

    @Autowired
    private StmCryptoGatewayMac stmTspGatewayMac;

    @Override
    public EncryptDataOutput encryptData(EncryptDataInput request) throws TokenManagerException {
        return stmTspGatewayEncrypt.executePost(request);
    }

    @Override
    public GenerateMacOutput generateMac(GenerateMacInput request) throws TokenManagerException {
        return stmTspGatewayMac.executePost(request);
    }

    @Override
    public DecryptDataOutput decryptMac(DecryptDataInput request) throws TokenManagerException {
        return stmTspGatewayDecrypt.executePost(request);
    }

    @Override
    public VerifyMacOutput verifyMac(VerifyMacInput request) throws TokenManagerException {
        // TODO Auto-generated method stub
        return null;
    }

}
