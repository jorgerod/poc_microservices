package com.isban.tokenmanager.stmcrypto.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.isban.tokenmanager.dto.FlowAndMediaResponse;
import com.isban.tokenmanager.integration.hubdigital.EligibitityHttpRequest;
import com.isban.tokenmanager.integration.hubdigital.HubdigitalCommonRequest;
import com.isban.tokenmanager.service.security.impl.CryptographicBase;
import com.isban.tokenmanager.stmcrypto.dto.DecryptDataInput;
import com.isban.tokenmanager.stmcrypto.dto.EncryptDataInput;
import com.isban.tokenmanager.stmcrypto.dto.GenerateMacInput;
import com.isban.tokenmanager.stmcrypto.dto.KeyData;
import com.isban.tokenmanager.util.CommonUtil;
import com.isban.tokenmanager.util.TcpUtil;

@Component
public class StmCryptoFactoryImpl implements StmCryptoFactory {
    
    @Autowired
    CommonUtil util;
    
    @Autowired
    TcpUtil tcpUtil;;
    
    @Autowired
    CryptographicBase cryptographicBase;
    
    
    @Override
    public GenerateMacInput createMac(EligibitityHttpRequest request) {
        GenerateMacInput ret = new GenerateMacInput();
        
        ret.setIv("");
        
        ret.setMessage(cryptographicBase.stringToHexUpperCase(util.convertObjJavaToJson(request)));
        ret.setPaddingMethod("1");
        ret.setKeyData(createKeyDataMac(request));
        ret.setMacAlgorithm("3");
        ret.setInputFormat("1");
        ret.setMacSize("8");
        
        ret.setKeyData(createKeyDataMac(request));
        
        return ret;
    }

    @Override
    public EncryptDataInput create(EligibitityHttpRequest request) {
        EncryptDataInput ret = new EncryptDataInput();
        ret.setEncryptionMode("CBC");
//        ret.setInputFormat("1");
        ret.setIv("");
        
        String msg = proccessPadding(util.convertObjJavaToJson(request.getInfo().getDecryptedData()));
        
        ret.setMessage(msg);
        ret.setPaddingMethod("");

        ret.setKeyData(createKeyDataEncrypt(request));

        return ret;
    }

    private String proccessPadding(String msg) {
        String ret = cryptographicBase.stringToHexUpperCase(msg) + "80";
        ret = tcpUtil.rightPadding(ret, ret.length() + (16 - ret.length() % 16), "0");
        return ret;
    }

    private KeyData createKeyDataEncrypt(HubdigitalCommonRequest request) {
        KeyData ret = new KeyData();

        ret.setCompanyId(request.getInfo().getIssuerId());
        ret.setAppId("HCE");
        ret.setKeyName("REDSYS01");
        ret.setKeyType("ZEK");
        ret.setKeyVersion(request.getInfo().getKeyVersion());
        
        return ret;
    }

    private KeyData createKeyDataMac(EligibitityHttpRequest request) {
        KeyData ret = new KeyData();

        ret.setCompanyId(request.getInfo().getIssuerId());
        ret.setAppId("HCE");
        ret.setKeyName("REDSYS01");
        ret.setKeyType("ZAK");
        ret.setKeyVersion(request.getInfo().getKeyVersion());
        
        return ret;
    }

    @Override
    public DecryptDataInput createDecryptInput(HubdigitalCommonRequest request) {
        DecryptDataInput ret = new DecryptDataInput();
        
        ret.setKeyData(createKeyDataEncrypt(request));
        ret.setDecryptionMode("CBC");
        ret.setMessage(request.getInfo().getEncryptedData());
        
        return ret;
    }
    
    @Override
    public EncryptDataInput createEncryptInput(EligibitityHttpRequest request, FlowAndMediaResponse flowAndMediaResponse) {
        EncryptDataInput ret = new EncryptDataInput();
        
        ret.setKeyData(createKeyDataEncrypt(request));
        ret.setEncryptionMode("CBC");
        ret.setIv("");
        ret.setPaddingMethod("");
        
        ret.setMessage(proccessPadding(flowAndMediaResponse.getMedia().toString()));
        
        return ret;
    }
}
