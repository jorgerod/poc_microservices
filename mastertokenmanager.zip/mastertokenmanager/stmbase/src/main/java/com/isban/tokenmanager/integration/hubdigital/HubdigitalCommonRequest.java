package com.isban.tokenmanager.integration.hubdigital;

public class HubdigitalCommonRequest {

    private HubDigitalInfoBase info;
    private String mac;
    
    
    public HubDigitalInfoBase getInfo() {
        return info;
    }
    public void setInfo(HubDigitalInfoBase info) {
        this.info = info;
    }
    public String getMac() {
        return mac;
    }
    public void setMac(String mac) {
        this.mac = mac;
    }
}
