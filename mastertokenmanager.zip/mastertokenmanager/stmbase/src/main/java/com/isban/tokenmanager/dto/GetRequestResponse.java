package com.isban.tokenmanager.dto;

import java.util.ArrayList;
import java.util.List;

public class GetRequestResponse extends ResponseBase {

    private List<RequestDto> requests = new ArrayList<>();

    public GetRequestResponse() {
    }

    public GetRequestResponse(String code, String description) {
        super(code, description);
    }

    public List<RequestDto> getRequests() {
        return requests;
    }

    public void setRequests(List<RequestDto> requests) {
        this.requests = requests;
    }

    @Override
    public String toString() {
        return "GetRequestResponse [requests=" + requests + "]";
    }
}
