package com.isban.tokenmanager.dto.cardless;

import java.util.Date;

import com.isban.tokenmanager.dto.ModelBaseDto;

public class ReversalWithdrawalDto extends ModelBaseDto {

    private Date opTime;
    private String item;
    private String dItem;
    private String amount;
    private String currency;
    private String reasonCode;
    private Date withdrawallOpTime;
    private String withdrawalAuthCode;

    public Date getOpTime() {
        return opTime;
    }
    public void setOpTime(Date opTime) {
        this.opTime = opTime;
    }
    public String getItem() {
        return item;
    }
    public void setItem(String item) {
        this.item = item;
    }
    public String getdItem() {
        return dItem;
    }
    public void setdItem(String dItem) {
        this.dItem = dItem;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public String getReasonCode() {
        return reasonCode;
    }
    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }
    public Date getWithdrawallOpTime() {
        return withdrawallOpTime;
    }
    public void setWithdrawallOpTime(Date withdrawallOpTime) {
        this.withdrawallOpTime = withdrawallOpTime;
    }
    public String getWithdrawalAuthCode() {
        return withdrawalAuthCode;
    }
    public void setWithdrawalAuthCode(String withdrawalAuthCode) {
        this.withdrawalAuthCode = withdrawalAuthCode;
    }
    
    @Override
    public String toString() {
        return "ReversalWithdrawalDto [opTime=" + opTime + ", item=" + item + ", dItem=" + dItem + ", amount=" + amount
                + ", currency=" + currency + ", reasonCode=" + reasonCode + ", withdrawallOpTime=" + withdrawallOpTime
                + ", withdrawalAuthCode=" + withdrawalAuthCode + ", issuerId=" + issuerId + ", tokenTypeId="
                + tokenTypeId + "]";
    }

}
