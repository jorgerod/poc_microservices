package com.isban.tokenmanager.integration.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class OTP {
    private String otp;
    private String tickettm;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyMMddHHmm")
    private Date expirationotp;

    public OTP() {
    }

    public OTP(String otp) {
        super();
        this.otp = otp;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getTickettm() {
        return tickettm;
    }

    public void setTickettm(String tickettm) {
        this.tickettm = tickettm;
    }

    public Date getExpirationotp() {
        return expirationotp;
    }

    public void setExpirationotp(Date expirationotp) {
        this.expirationotp = expirationotp;
    }

    @Override
    public String toString() {
        return "OTP [otp=" + otp + ", tickettm=" + tickettm + ", expirationotp=" + expirationotp + "]";
    }

}
