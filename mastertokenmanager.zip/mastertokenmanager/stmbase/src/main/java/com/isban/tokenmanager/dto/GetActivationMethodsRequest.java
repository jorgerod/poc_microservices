package com.isban.tokenmanager.dto;

public class GetActivationMethodsRequest {
    private String idClient;
    private String idIssuer;
    private String idTokenType;
    private String idWallet;
    
    public GetActivationMethodsRequest() {}

    public GetActivationMethodsRequest(String idClient, String idIssuer,
            String idTokenType, String idWallet) {
        super();
        this.idClient = idClient;
        this.idIssuer = idIssuer;
        this.idTokenType = idTokenType;
        this.idWallet = idWallet;
    }

    public String getIdClient() {
        return idClient;
    }

    public void setIdClient(String idClient) {
        this.idClient = idClient;
    }

    public String getIdIssuer() {
        return idIssuer;
    }

    public String getIdTokenType() {
        return idTokenType;
    }

    public void setIdTokenType(String idTokenType) {
        this.idTokenType = idTokenType;
    }

    public void setIdIssuer(String idIssuer) {
        this.idIssuer = idIssuer;
    }

    public String getIdWallet() {
        return idWallet;
    }

    public void setIdWallet(String idWallet) {
        this.idWallet = idWallet;
    }

    @Override
    public String toString() {
        return "GetActivationMethodsRequest [idClient=" + idClient
                + ", idIssuer=" + idIssuer + ", idWallet=" + idWallet
                + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
                + ", toString()=" + super.toString() + "]";
    }
}
