package com.isban.tokenmanager.dto;

public class NotificationCustomerResponse extends ResponseBase {

    public NotificationCustomerResponse() {
    }

    public NotificationCustomerResponse(String code, String description) {
        super(code, description);
    }
}
