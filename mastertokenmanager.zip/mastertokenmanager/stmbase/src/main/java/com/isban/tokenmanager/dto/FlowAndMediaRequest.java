package com.isban.tokenmanager.dto;

import java.util.List;

public class FlowAndMediaRequest extends ModelBaseDto {

    private ItemDataDto itemData = new ItemDataDto();
    private String tokenReferenceId;
    private String correlationId;

    // Token requestor
    private String tokenRequestorId;
    private String tokenRequestorExt;
    private String walletExt = null;

    // Device
    private DeviceDto device = null;

    private String itemSource;

    private String typedoc = null;
    private String doc = null;
    private String customerExt = null;

    private String ipAddress = null;

    // decisionInfo
    private String cardHolderWalletAccount = null;
    private String walletRiskAssessment = null;// APPROVED, DECLINED,
                                               // REQUIRE_ADDITIONAL_AUTHENTICATION
    private String walletRiskAssessmentVersion = null;
    private String walletDeviceScore = null;
    private String walletAccountScore = null;
    private List<String> walletReasonCodes = null;// if APPROVED:
                                                  // LONG_ACCOUNT_TENURE,
                                                  // GOOD_ACTIVITY_HISTORY,
                                                  // ADDITIONAL_DEVICE,
                                                  // SOFTWARE_UPDATE

    private String tokenAssuranceLevel = null;
    private String tokenTypeExt = null;
    private String numberActiveTokensPan = null;
    private String numberInactiveTokens = null;
    private String numberSuspendedTokens = null;
    private String termAndConditions = null;
    private String termAndConditionsDate = null;

    private String secureElement = null;
    private String paymentAppInstanceId = null;
    private String accountIdHash = null;

    public FlowAndMediaRequest() {
    }

    public ItemDataDto getItemData() {
        return itemData;
    }


    public void setItemData(ItemDataDto itemData) {
        this.itemData = itemData;
    }


    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public DeviceDto getDevice() {
        return device;
    }

    public void setDevice(DeviceDto device) {
        this.device = device;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getCardHolderWalletAccount() {
        return cardHolderWalletAccount;
    }

    public void setCardHolderWalletAccount(String cardHolderWalletAccount) {
        this.cardHolderWalletAccount = cardHolderWalletAccount;
    }

    public String getWalletRiskAssessment() {
        return walletRiskAssessment;
    }

    public void setWalletRiskAssessment(String walletRiskAssessment) {
        this.walletRiskAssessment = walletRiskAssessment;
    }

    public String getWalletRiskAssessmentVersion() {
        return walletRiskAssessmentVersion;
    }

    public void setWalletRiskAssessmentVersion(String walletRiskAssessmentVersion) {
        this.walletRiskAssessmentVersion = walletRiskAssessmentVersion;
    }

    public String getWalletDeviceScore() {
        return walletDeviceScore;
    }

    public void setWalletDeviceScore(String walletDeviceScore) {
        this.walletDeviceScore = walletDeviceScore;
    }

    public String getWalletAccountScore() {
        return walletAccountScore;
    }

    public void setWalletAccountScore(String walletAccountScore) {
        this.walletAccountScore = walletAccountScore;
    }

    public List<String> getWalletReasonCodes() {
        return walletReasonCodes;
    }

    public void setWalletReasonCodes(List<String> walletReasonCodes) {
        this.walletReasonCodes = walletReasonCodes;
    }

    public String getTokenAssuranceLevel() {
        return tokenAssuranceLevel;
    }

    public void setTokenAssuranceLevel(String tokenAssuranceLevel) {
        this.tokenAssuranceLevel = tokenAssuranceLevel;
    }

    public String getTokenTypeExt() {
        return tokenTypeExt;
    }

    public void setTokenTypeExt(String tokenTypeExt) {
        this.tokenTypeExt = tokenTypeExt;
    }

    public String getNumberActiveTokensPan() {
        return numberActiveTokensPan;
    }

    public void setNumberActiveTokensPan(String numberActiveTokensPan) {
        this.numberActiveTokensPan = numberActiveTokensPan;
    }

    public String getNumberInactiveTokens() {
        return numberInactiveTokens;
    }

    public void setNumberInactiveTokens(String numberInactiveTokens) {
        this.numberInactiveTokens = numberInactiveTokens;
    }

    public String getNumberSuspendedTokens() {
        return numberSuspendedTokens;
    }

    public void setNumberSuspendedTokens(String numberSuspendedTokens) {
        this.numberSuspendedTokens = numberSuspendedTokens;
    }

    public String getTermAndConditions() {
        return termAndConditions;
    }

    public void setTermAndConditions(String termAndConditions) {
        this.termAndConditions = termAndConditions;
    }

    public String getTermAndConditionsDate() {
        return termAndConditionsDate;
    }

    public void setTermAndConditionsDate(String termAndConditionsDate) {
        this.termAndConditionsDate = termAndConditionsDate;
    }

    public String getItemSource() {
        return itemSource;
    }

    public void setItemSource(String itemSource) {
        this.itemSource = itemSource;
    }

    public String getTypedoc() {
        return typedoc;
    }

    public void setTypedoc(String typedoc) {
        this.typedoc = typedoc;
    }

    public String getDoc() {
        return doc;
    }

    public void setDoc(String doc) {
        this.doc = doc;
    }

    public String getCustomerExt() {
        return customerExt;
    }

    public void setCustomerExt(String customerExt) {
        this.customerExt = customerExt;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getTokenRequestorExt() {
        return tokenRequestorExt;
    }

    public void setTokenRequestorExt(String tokenRequestorExt) {
        this.tokenRequestorExt = tokenRequestorExt;
    }

    public String getWalletExt() {
        return walletExt;
    }

    public void setWalletExt(String walletExt) {
        this.walletExt = walletExt;
    }

    public String getSecureElement() {
        return secureElement;
    }

    public void setSecureElement(String secureElement) {
        this.secureElement = secureElement;
    }

    public String getAccountIdHash() {
        return accountIdHash;
    }

    public void setAccountIdHash(String accountIdHash) {
        this.accountIdHash = accountIdHash;
    }

    public String getPaymentAppInstanceId() {
        return paymentAppInstanceId;
    }

    public void setPaymentAppInstanceId(String paymentAppInstanceId) {
        this.paymentAppInstanceId = paymentAppInstanceId;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("FlowAndMediaRequest [itemData=").append(itemData).append(", tokenReferenceId=")
                .append(tokenReferenceId).append(", correlationId=").append(correlationId).append(", tokenRequestorId=")
                .append(tokenRequestorId).append(", tokenRequestorExt=").append(tokenRequestorExt)
                .append(", walletExt=").append(walletExt).append(", device=").append(device).append(", itemSource=")
                .append(itemSource).append(", typedoc=").append(typedoc).append(", doc=").append(doc)
                .append(", customerExt=").append(customerExt).append(", ipAddress=").append(ipAddress)
                .append(", cardHolderWalletAccount=").append(cardHolderWalletAccount).append(", walletRiskAssessment=")
                .append(walletRiskAssessment).append(", walletRiskAssessmentVersion=")
                .append(walletRiskAssessmentVersion).append(", walletDeviceScore=").append(walletDeviceScore)
                .append(", walletAccountScore=").append(walletAccountScore).append(", walletReasonCodes=")
                .append(walletReasonCodes).append(", tokenAssuranceLevel=").append(tokenAssuranceLevel)
                .append(", tokenTypeExt=").append(tokenTypeExt).append(", numberActiveTokensPan=")
                .append(numberActiveTokensPan).append(", numberInactiveTokens=").append(numberInactiveTokens)
                .append(", numberSuspendedTokens=").append(numberSuspendedTokens).append(", termAndConditions=")
                .append(termAndConditions).append(", termAndConditionsDate=").append(termAndConditionsDate)
                .append(", secureElement=").append(secureElement).append(", paymentAppInstanceId=")
                .append(paymentAppInstanceId).append(", accountIdHash=").append(accountIdHash).append("]");
        return builder.toString();
    }


}
