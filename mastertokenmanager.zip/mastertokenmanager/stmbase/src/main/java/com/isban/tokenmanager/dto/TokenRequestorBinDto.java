package com.isban.tokenmanager.dto;

public class TokenRequestorBinDto extends MultiTenantLifeTimeBaseDto {

    private String tokenRequestorId;
    private String binId;
    private String tspId;

    private String brandId;

    public TokenRequestorBinDto() {
        super(null, null, null);  
    }
    
    public TokenRequestorBinDto(String issuerId, String tokenTypeId, String tokenRequestorId) {
        super(issuerId, tokenTypeId, tokenRequestorId);  
    }
    
    public TokenRequestorBinDto(String issuerId, String tokenTypeId, String tokenRequestorId, String binId,
            String tspId, String brandBinId) {
        super(issuerId, tokenTypeId, tokenRequestorId);
        this.tokenRequestorId = tokenRequestorId;
        this.binId = binId;
        this.tspId = tspId;
        this.brandId = brandBinId;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getBinId() {
        return binId;
    }

    public void setBinId(String binId) {
        this.binId = binId;
    }

    public String getTspId() {
        return tspId;
    }

    public void setTspId(String tspId) {
        this.tspId = tspId;
    }

    public String getBrandId() {
        return brandId;
    }

    public void setBrandId(String brandBinId) {
        this.brandId = brandBinId;
    }

}
