package com.isban.tokenmanager.integration.dto;

public class ActivationCodeDataTcpResponse extends TcpCommonDataResponse {

    public ActivationCodeDataTcpResponse() {
        super();
    }

    public ActivationCodeDataTcpResponse(ActivationCodeDataTcpRequest request) {
        super(request.getOperationId(), request.getOperationDateTime());
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ActivationCodeDataTcpResponse [getOperationId()=").append(getOperationId())
                .append(", getOperationDateTime()=").append(getOperationDateTime()).append("]");
        return builder.toString();
    }

}
