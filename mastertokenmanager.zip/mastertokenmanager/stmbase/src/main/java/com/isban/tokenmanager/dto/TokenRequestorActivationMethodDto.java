package com.isban.tokenmanager.dto;

public class TokenRequestorActivationMethodDto extends MultiTenantLifeTimeBaseDto {

    private String tokenRequestorId;
    private String activationMethodId;
    private String value;
    private Integer priority;

    public TokenRequestorActivationMethodDto() {
        super(null, null, null);  
    }
    
    public TokenRequestorActivationMethodDto(String issuerId, String tokenTypeId, String tokenRequestorId,
            String activationMethodId, String value, Integer priority) {
        super(issuerId, tokenTypeId, tokenRequestorId);
        this.tokenRequestorId = tokenRequestorId;
        this.activationMethodId = activationMethodId;
        this.value = value;
        this.priority = priority;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getActivationMethodId() {
        return activationMethodId;
    }

    public void setActivationMethodId(String activationMethodId) {
        this.activationMethodId = activationMethodId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

}
