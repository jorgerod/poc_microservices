package com.isban.tokenmanager.dto;

public class IncomingDto extends ModelBaseDto {

    private String pan;
    private String token;
    private String tokenRequestorId;
    private String operationId;
    private String operationDate;
    private String operationHour;
    private String authId;
    private String commerceId;
    private String paymentInitChannel;
    private String amount;
    private String currency;
    private String town;
    private String country;
    private String tokenTypeId;

    public IncomingDto(String issuerId, String tokenTypeId, String pan, String token, String tokenRequestorId, String operationId,
            String operationDate, String operationHour, String authId, String commerceId, String paymentInitChannel,
            String amount, String currency, String town, String country) {

        this.issuerId = issuerId;
        this.pan = pan;
        this.token = token;
        this.tokenRequestorId = tokenRequestorId;
        this.operationId = operationId;
        this.operationDate = operationDate;
        this.operationHour = operationHour;
        this.authId = authId;
        this.commerceId = commerceId;
        this.paymentInitChannel = paymentInitChannel;
        this.amount = amount;
        this.currency = currency;
        this.town = town;
        this.country = country;
    }

    public IncomingDto() {
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getItem() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getOperationId() {
        return operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }

    public String getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(String operationDate) {
        this.operationDate = operationDate;
    }

    public String getOperationHour() {
        return operationHour;
    }

    public void setOperationHour(String operationHour) {
        this.operationHour = operationHour;
    }

    public String getAuthId() {
        return authId;
    }

    public void setAuthId(String authId) {
        this.authId = authId;
    }

    public String getCommerceId() {
        return commerceId;
    }

    public void setCommerceId(String commerceId) {
        this.commerceId = commerceId;
    }

    public String getPaymentInitChannel() {
        return paymentInitChannel;
    }

    public void setPaymentInitChannel(String paymentInitChannel) {
        this.paymentInitChannel = paymentInitChannel;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    @Override
    public String toString() {
        return "IncomingDto [issuerId=" + issuerId + ", pan=" + pan + ", token=" + token + ", tokenRequestorId=" + tokenRequestorId
                + ", operationId=" + operationId + ", operationDate=" + operationDate + ", operationHour="
                + operationHour + ", authId=" + authId + ", commerceId=" + commerceId + ", paymentInitChannel="
                + paymentInitChannel + ", amount=" + amount + ", currency=" + currency + ", town=" + town + ", country="
                + country + "]";
    }

}
