package com.isban.tokenmanager.dto;

import java.util.Date;

public class PaymentCancellationRequest extends ModelBaseDto {

    private String ticketTmId;
    private String pan;

    private String ditem;
    // private String issuerId;
    private String tokenRequestorId;

    private Date transactionDate;
    private String operationDate;// aaaammdd
    private String operationHour;// HHmmss
    private String operationId;
    private String resolutorOperation;
    private String resolverCode;
    private String originOperationId;

    public PaymentCancellationRequest() {
    }

    public String getRequestId() {
        return ticketTmId;
    }

    public void setRequestId(String ticketTmId) {
        this.ticketTmId = ticketTmId;
    }

    public String getItem() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(String operationDate) {
        this.operationDate = operationDate;
    }

    public String getOperationHour() {
        return operationHour;
    }

    public void setOperationHour(String operationHour) {
        this.operationHour = operationHour;
    }

    public String getOperationId() {
        return operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }

    public String getResolutorOperation() {
        return resolutorOperation;
    }

    public void setResolutorOperation(String resolutorOperation) {
        this.resolutorOperation = resolutorOperation;
    }

    public String getResolverCode() {
        return resolverCode;
    }

    public void setResolverCode(String resolverCode) {
        this.resolverCode = resolverCode;
    }

    public String getOriginOperationId() {
        return originOperationId;
    }

    public void setOriginOperationId(String originOperationId) {
        this.originOperationId = originOperationId;
    }


    @Override
    public String toString() {
        return "PaymentCancellationRequest [ticketTmId=" + ticketTmId + ", pan=" + pan + ", dpan=" + ditem
                + ", tokenRequestorId=" + tokenRequestorId + ", transactionDate=" + transactionDate + ", operationDate=" + operationDate
                + ", operationHour=" + operationHour + ", operationId=" + operationId + ", resolutorOperation="
                + resolutorOperation + ", resolverCode=" + resolverCode + ", originOperationId=" + originOperationId
                + "]";
    }
}
