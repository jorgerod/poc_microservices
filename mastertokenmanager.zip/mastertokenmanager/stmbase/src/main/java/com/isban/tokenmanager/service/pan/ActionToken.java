package com.isban.tokenmanager.service.pan;

import com.isban.tokenmanager.dto.ResponseBase;
import com.isban.tokenmanager.dto.ResponseEvent;
import com.isban.tokenmanager.dto.TokenDto;
import com.isban.tokenmanager.dto.cardless.AccessTokenDto;
import com.isban.tokenmanager.dto.cardless.AuthorizeWithdrawalResponseDto;
import com.isban.tokenmanager.dto.cardless.ReversalWithdrawalResponseDto;
import com.isban.tokenmanager.dto.pan.ProvisioningDto;

public interface ActionToken {
    ResponseBase suspend(TokenDto panDto);

    ResponseBase cancel(TokenDto panDto);

    ResponseBase resume(TokenDto panDto);

    ResponseBase updatedExpirationPan(TokenDto panDto);

    ResponseBase remap(TokenDto oldPanRequestDto, TokenDto newPanRequestDto);
    
    /* **************** TOKEN TYPE 1 *****************************/
    ProvisioningDto provisioning(TokenDto tokenDto);

    ResponseBase validatedToken(TokenDto tokenDto);

    ResponseBase refuseToken(TokenDto tokenDto);

    AuthorizeWithdrawalResponseDto consumeToken(TokenDto tokenDto);

    ReversalWithdrawalResponseDto reversalConsumedToken(TokenDto tokenDto);

    ResponseBase activateToken(TokenDto tokenDto);

    ResponseBase setSmsSend(TokenDto tokenDto);

    ResponseBase expire(TokenDto panDto);
    
    ResponseBase expire(TokenDto panDto, AccessTokenDto accessTokenDto);
    
    ResponseEvent releaseRetention(TokenDto tokenDto, AccessTokenDto accessTokenDto);    

    ResponseEvent releaseRetention(TokenDto tokenDto);
    
    ResponseBase setReleaseTokenState(TokenDto tokenDto, String stateCode);

    ResponseBase setReleaseTokenState(TokenDto tokenDto, String stateCode, AccessTokenDto accessTokenDto);

    boolean verifyTokenIsExpired(TokenDto tokenDto, String newStateId);
    
}
