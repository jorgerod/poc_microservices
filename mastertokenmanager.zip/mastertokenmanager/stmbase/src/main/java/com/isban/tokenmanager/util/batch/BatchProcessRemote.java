package com.isban.tokenmanager.util.batch;

import com.isban.tokenmanager.integration.batch.BatchRemoteRequestBase;
import com.isban.tokenmanager.integration.batch.BatchRemoteResponse;

public interface BatchProcessRemote<T> {
    public BatchRemoteResponse processData(BatchRemoteRequestBase<T> dataRemote);
    public boolean checkItem(T item);
    public String getIssuerId(BatchRemoteRequestBase<T> dataRemote);
    public String getTokenTypeId(BatchRemoteRequestBase<T> dataRemote);
}
