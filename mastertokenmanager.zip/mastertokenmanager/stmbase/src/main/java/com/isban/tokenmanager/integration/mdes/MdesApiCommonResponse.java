package com.isban.tokenmanager.integration.mdes;


import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.isban.tokenmanager.dto.ResponseBase;

import io.swagger.annotations.ApiModelProperty;

public class MdesApiCommonResponse extends ResponseBase {
    
    @ApiModelProperty(value = "Unique identifier for the response.", required = true)
    @NotNull
    @Size(max = 64)
    private String responseId;
    
    
    public String getResponseId() {
        return responseId;
    }
    public void setResponseId(String responseId) {
        this.responseId = responseId;
    }

    @JsonProperty(value = "errorCode")
    @ApiModelProperty(value = "Error code for the reason the operation failed.", required = false)
    @Size(max = 32)
    @Override
    public String getCode() {
        return super.getCode();
    }
    
    @ApiModelProperty(value = "Error description of the reason the operation failed.", required = false)
    @JsonProperty(value = "errorDescription")
    @Size(max = 256)
    @Override
    public String getDescription() {
        return super.getDescription();
    }
    
    @Override
    public void setCode(String c) {
        super.setCode(c);
    }
    
    @Override
    public void setDescription(String d) {
        super.setDescription(d);
    }
}
