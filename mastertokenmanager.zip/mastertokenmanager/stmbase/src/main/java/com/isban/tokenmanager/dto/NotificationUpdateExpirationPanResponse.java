package com.isban.tokenmanager.dto;


public class NotificationUpdateExpirationPanResponse extends ResponseBase {
    
    public NotificationUpdateExpirationPanResponse() {}

    public NotificationUpdateExpirationPanResponse(String code, String description) {
        super(code, description);
    }
}
