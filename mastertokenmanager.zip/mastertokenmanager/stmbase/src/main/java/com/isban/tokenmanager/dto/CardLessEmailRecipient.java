package com.isban.tokenmanager.dto;

import java.util.List;

public class CardLessEmailRecipient {
    
    List<String> to;
    List<String> cc;
    List<String> bcc;
    
    public List<String> getTo() {
        return to;
    }
    public void setTo(List<String> to) {
        this.to = to;
    }
    public List<String> getCc() {
        return cc;
    }
    public void setCc(List<String> cc) {
        this.cc = cc;
    }
    public List<String> getBcc() {
        return bcc;
    }
    public void setBcc(List<String> bcc) {
        this.bcc = bcc;
    }

    
}
