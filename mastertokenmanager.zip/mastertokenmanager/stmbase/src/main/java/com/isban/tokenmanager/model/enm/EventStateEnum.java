package com.isban.tokenmanager.model.enm;

public enum EventStateEnum {
    NEW("00"), 
    PENDING("01"),
    OK("02"),
    KO("03");

    private String code;

    EventStateEnum(String val) {
        this.code = val;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
