package com.isban.tokenmanager.integration.ppaa;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class ReleaseHttpRequest extends CommonHttpRequest {

    private String retentionId;
    
    @ApiModelProperty(value = "Identifier of the retention to release. (DD-MM-YYYY hh:mm:ss.nnnnnn format)", required = true)
    @Size(max = 26)
    public String getRetentionId() {
        return retentionId;
    }
    
    public void setRetentionId(String retentionId) {
        this.retentionId = retentionId;
    }    
}