package com.isban.tokenmanager.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.isban.tokenmanager.dto.StmMixInForSetOrList;
import com.isban.tokenmanager.model.ModelBase;

@Component
public class CommonUtil {

    private static final Logger logger = Logger.getLogger(CommonUtil.class);

    public Double parseDouble(String value) {
        Double result = 0.0;

        try {
            result = Double.parseDouble(value);
        } catch (Exception ex) {
        }

        return result;
    }

    /**
     * Convert string pan of n chars to bigInteger pan of
     * {@value Constants#ITEM_LENGTH} digits
     * 
     * @param panStr
     *            to convert
     * @return converted pan
     */
    public BigInteger convertStrPanToBigInteger(String panStr) {
        return convertStrPanToBigInteger(panStr, "0");
    }

    public BigInteger convertStrPanToBigInteger(String panStr, String strDigit) {
        BigInteger result = BigInteger.ZERO;

        try {
            if (panStr.length() < Constants.ITEM_LENGTH) {
                panStr = StringUtils.rightPad(panStr, Constants.ITEM_LENGTH, strDigit);
            }

            result = new BigInteger(panStr);
        } catch (Exception ex) {
            logger.error(ex);
        }

        return result;
    }

    public Long parseLong(String value) {
        Long result = 0L;

        try {
            result = Long.parseLong(value);
        } catch (Exception ex) {
            logger.error(ex);
        }

        return result;
    }

    /**
     * Returns a pseudo-random number between min and max, inclusive. The
     * difference between min and max can be at most
     * <code>Integer.MAX_VALUE - 1</code>.
     *
     * @param min
     *            Minimum value
     * @param max
     *            Maximum value. Must be greater than min.
     * @return Integer between min and max, inclusive.
     * @see java.util.Random#nextInt(int)
     */
    public int randInt(int min, int max) {

        // NOTE: Usually this should be a field rather than a method
        // variable so that it is not re-seeded every call.
        Random rand = new Random();

        // add 1 to make it inclusive and finaly return
        return rand.nextInt((max - min) + 1) + min;
    }

    public String parseDateToStr(Date date, String pattern) {
        String ret = "";

        if (date == null) {
            return ret;
        }

        SimpleDateFormat format = new SimpleDateFormat(pattern);
        ret = format.format(date);

        return ret;
    }

    /**
     * Convert string to date
     *
     * @param dateStr
     *            to convert
     * @param pattern
     *            to apply
     * @return Date
     */
    public Date parseStrToDate(String dateStr, String pattern) {
        Date ret = null;
        if (dateStr == null || dateStr.isEmpty()) {
            return ret;
        }

        SimpleDateFormat formatter = new SimpleDateFormat(pattern);
        ret = parseStrToDate(dateStr, formatter);

        return ret;
    }

    public Date parseStrToDate(String dateStr, DateFormat formatter) {
        Date ret = null;
        if (formatter == null) {
            return ret;
        }

        try {
            ret = formatter.parse(dateStr);

        } catch (ParseException e) {
            logger.error(e);
        }

        return ret;
    }

    /**
     * Sum seconds to date
     */
    public Date addSecondsToNow(int seconds) {
        return new DateTime().plusSeconds(seconds).toDate();
    }

    /**
     * Remove seconds to date
     */
    public Date removeSecondsToNow(int seconds) {
        return new DateTime().minusSeconds(seconds).toDate();
    }

    /**
     * Remove recursively all files from specific path
     *
     * @param path
     *            to directory
     */
    public void clearDirectory(Path path) {

        // browsing the file directory and delete recursively
        try {
            FileUtils.deleteDirectory(new File(path.toAbsolutePath().toString()));
        } catch (IOException e) {
            logger.info(e);
        }
    }

    public Path structuredmoveFile(Path sourceBasePath, Path sourceFilePath, Path targetBasePath) {
        Path ret = null;

        String sourceBaseStr = sourceBasePath.toString().replace('\\', '/');
        String sourceFileStr = sourceFilePath.toString().replace('\\', '/');
        String targetBaseStr = targetBasePath.toString().replace('\\', '/');
        String targetFileStr = sourceFileStr.replaceFirst(sourceBaseStr, targetBaseStr);

        try {
            Path targetFilePath = Paths.get(targetFileStr);
            Files.createDirectories(targetFilePath.getParent());
            Files.move(sourceFilePath, targetFilePath, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            ret = targetFilePath;

        } catch (IOException e) {
            logger.error(e);
            logger.error("CommonUtil.structuredmoveFile :: sourceFile=" + sourceFileStr);
            logger.error("CommonUtil.structuredmoveFile :: targetFile=" + targetFileStr);
        }

        return ret;
    }

    /**
     * Validate date with specific format for remap
     *
     * @param date
     *            to validate
     * @return true if date is valid
     */
    public boolean isValidDate(String date, String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        try {
            format.parse(date);
            return true;
        } catch (ParseException e) {
            logger.error(e);
            return false;
        }
    }

    public Integer parseInteger(String value) {
        Integer result = 0;

        try {
            if (value != null && !value.isEmpty()) {
                result = Integer.parseInt(value);
            }
        } catch (Exception ex) {
            logger.error(ex);
        }

        return result;
    }

    /*
     * Converts XMLGregorianCalendar to java.util.Date in Java
     */
    public Date toDate(XMLGregorianCalendar calendar) {
        if (calendar == null) {
            return null;
        }
        return calendar.toGregorianCalendar().getTime();
    }

    public XMLGregorianCalendar toXmlGregorianCalendar(Date date) {
        XMLGregorianCalendar ret = null;

        GregorianCalendar c = new GregorianCalendar();
        c.setTime(date);

        try {
            ret = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
        } catch (DatatypeConfigurationException e) {
            e.printStackTrace();
        }

        return ret;
    }

    public Object clone(Object obj) {
        Object ret = null;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(obj);

            ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
            ObjectInputStream ois = new ObjectInputStream(bais);
            ret = ois.readObject();

        } catch (IOException e) {
            e.printStackTrace();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return ret;
    }

    private ObjectMapper getMapper(Object objData) {
        ObjectMapper ret = new ObjectMapper();

        if (objData instanceof ModelBase) {
            ret = new ObjectMapper();
            ret.addMixIn(Set.class, StmMixInForSetOrList.class);
            ret.addMixIn(List.class, StmMixInForSetOrList.class);
        }

        ret.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        ret.setSerializationInclusion(Include.NON_NULL);

        return ret;
    }

    public String convertObjJavaToJson(Object objData) {
        String ret = null;
        try {
            ret = getMapper(objData).writeValueAsString(objData);
        } catch (JsonProcessingException e) {
            logger.error(objData, e);
        }

        return ret;
    }
    
    public Object convertJsonToObjJava(String json, Class<?> claszzz) {
        Object ret = null;
        try {
            ObjectMapper mapper = new ObjectMapper();
            ret = mapper.readValue(json, claszzz);
        } catch (IOException e) {
            logger.error(json, e);
        }

        return ret;
    }

    public boolean isNumber(Object obj) {
        Boolean ret = false;

        try {
            String value = (String) obj;
            if (value != null && !value.isEmpty()) {
                Integer.parseInt(value);
                ret = true;
            }
        } catch (Exception ex) {
        }

        return ret;
    }

    public String getStringEmptyIfIsNull(String value) {
        return  getDefaultValueIfIsNull(value, "");
    }

    public String getDefaultValueIfIsNull(String value, String defaultValue) {
        return  value!= null ? value : defaultValue;
       
    }
    
    public String getStringEmptyIfIsNull(Integer value) {
        if(value != null) return  getDefaultValueIfIsNull(value.toString(), "");
        return "";
    }
}
