package com.isban.tokenmanager.service.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.file.Path;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.csvreader.CsvReader;
import com.isban.tokenmanager.model.enm.TokenTypeEnum;
import com.isban.tokenmanager.util.CommonUtil;

@Service
public class BaseLoad {
    protected static final Logger logger = Logger.getLogger(BaseLoad.class);
    
    @Autowired
    protected CommonUtil commonUtil;
    
    public  void init(String path) {
        
    };
    
    

    public CsvReader getReader(String fileName) {
        return getReader("db_upload", fileName);
    }

    /**
     * @param path
     *            Example: db_upload/openbank
     * @param fileName
     *            Example: wallet.csv
     * @return
     */
    public CsvReader getReader(String path, String fileName) {
        CsvReader reader = null;
        try {
            if (path == null || path.isEmpty()) {
                return getReader(fileName);
            }
            ClassPathResource res = new ClassPathResource(path + "/" + fileName);
            if (res.exists()) {
                reader = new CsvReader(res.getInputStream(), ';', Charset.forName("UTF-8"));
                reader.setDelimiter(';');
                reader.readHeaders();
            }
        } catch (Exception e) {
            logger.error(e);
        }

        return reader;
    }
    
    public CsvReader getReader(Path file){
        CsvReader reader = null;
        try {
            File res = new File(  
                    file.getParent() + 
                    File.separator +
                    file.getFileName()  );
            InputStream resInputStream = new FileInputStream( res );
            reader = new CsvReader(  
                    resInputStream, 
                    ';', 
                    Charset.forName("ISO-8859-1")  );//ISO-8859-1 //UTF-8
            reader.setDelimiter(';');
            reader.readHeaders();
            
        } catch (Exception e) {
            logger.error(e);
        }

        return reader;
    }
    
    public void closeReader(CsvReader reader) {
        if (reader != null) {
            reader.close();
        }
    }
    
    public String getIssuer(CsvReader reader){
        return "0000";
    }
    
    public String getTokenTypeId(CsvReader reader){
        return TokenTypeEnum.WALLET.getCode();
    }

}