package com.isban.tokenmanager.dto;

import java.util.List;

public class RequestHistoryResponse extends ResponseBase {

    private List<RequestHistoryDto> requestHistory;

    public RequestHistoryResponse(String code, String description) {
        super(code, description);
    }

    public RequestHistoryResponse() {
    }

    public List<RequestHistoryDto> getRequestHistory() {
        return requestHistory;
    }

    public void setRequestHistory(List<RequestHistoryDto> requestHistory) {
        this.requestHistory = requestHistory;
    }
}
