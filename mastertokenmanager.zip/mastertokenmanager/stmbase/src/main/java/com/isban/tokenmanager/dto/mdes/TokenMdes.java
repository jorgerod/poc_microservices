package com.isban.tokenmanager.dto.mdes;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.isban.tokenmanager.dto.mdes.enm.StatusMdesEnum;
import com.isban.tokenmanager.dto.mdes.enm.SuspendedByMdesEnum;

import io.swagger.annotations.ApiModelProperty;

public class TokenMdes {
    
    @ApiModelProperty(name = "The unique reference allocated to the token in the Error! Reference source not found. response (see Section Error! Reference source not found.)", required = true)
    @NotNull
    private String tokenUniqueReference = null;
    
    @ApiModelProperty(name = "The current status of token. Must be one of: INACTIVE, ACTIVE, SUSPENDED or DEACTIVATED", required = true)
    @NotNull
    private StatusMdesEnum status = null;
            
    @ApiModelProperty(name = "Who or what caused the token to be suspended. One or more values of: ISSUER, PAYMENT_APP_PROVIDER, MOBILE_PIN_LOCKED or CARDHOLDER", required = false)
    private List<SuspendedByMdesEnum> suspendedBy = null;
    
    public String getTokenUniqueReference() {
        return tokenUniqueReference;
    }
    public void setTokenUniqueReference(String tokenUniqueReference) {
        this.tokenUniqueReference = tokenUniqueReference;
    }
    public StatusMdesEnum getStatus() {
        return status;
    }
    public void setStatus(StatusMdesEnum status) {
        this.status = status;
    }
    public List<SuspendedByMdesEnum> getSuspendedBy() {
        return suspendedBy;
    }
    public void setSuspendedBy(List<SuspendedByMdesEnum> suspendedBy) {
        this.suspendedBy = suspendedBy;
    }
    
    
}
