package com.isban.tokenmanager.dto;

/**
 * @author Sergey Zlobin
 * @since 28/08/2015
 */
public class RemapDto {

    private String issuerId;
    private String tokenTypeId;
    private String customerId;
    private String panOld;
    private String accountNumOld;
    private String productOld;
    private String expiryDateOld;
    private String panNew;
    private String accountNumNew;
    private String productNew;
    private String expiryDateNew;

    public RemapDto() {
    }

    public RemapDto(String issuerId, String tokenTypeId, String customerId, String panOld, String accountNumOld,
            String productOld, String expiryDateOld, String panNew, String accountNumNew, String productNew,
            String expiryDateNew) {
        this.issuerId = issuerId;
        this.customerId = customerId;
        this.panOld = panOld;
        this.accountNumOld = accountNumOld;
        this.productOld = productOld;
        this.expiryDateOld = expiryDateOld;
        this.panNew = panNew;
        this.accountNumNew = accountNumNew;
        this.productNew = productNew;
        this.expiryDateNew = expiryDateNew;
        this.tokenTypeId = tokenTypeId;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getItemOld() {
        return panOld;
    }

    public void setPanOld(String panOld) {
        this.panOld = panOld;
    }

    public String getAccountNumOld() {
        return accountNumOld;
    }

    public void setAccountNumOld(String accountNumOld) {
        this.accountNumOld = accountNumOld;
    }

    public String getProductOld() {
        return productOld;
    }

    public void setProductOld(String productOld) {
        this.productOld = productOld;
    }

    public String getExpiryDateOld() {
        return expiryDateOld;
    }

    public void setExpiryDateOld(String expiryDateOld) {
        this.expiryDateOld = expiryDateOld;
    }

    public String getItemNew() {
        return panNew;
    }

    public void setPanNew(String panNew) {
        this.panNew = panNew;
    }

    public String getAccountNumNew() {
        return accountNumNew;
    }

    public void setAccountNumNew(String accountNumNew) {
        this.accountNumNew = accountNumNew;
    }

    public String getProductNew() {
        return productNew;
    }

    public void setProductNew(String productNew) {
        this.productNew = productNew;
    }

    public String getExpiryDateNew() {
        return expiryDateNew;
    }

    public void setExpiryDateNew(String expiryDateNew) {
        this.expiryDateNew = expiryDateNew;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    @Override
    public String toString() {
        return "RemapDto [issuerId=" + issuerId + ", customerId=" + customerId + ", panOld=" + panOld
                + ", accountNumOld=" + accountNumOld + ", productOld=" + productOld + ", expiryDateOld=" + expiryDateOld
                + ", panNew=" + panNew + ", accountNumNew=" + accountNumNew + ", productNew=" + productNew
                + ", expiryDateNew=" + expiryDateNew + "]";
    }
}
