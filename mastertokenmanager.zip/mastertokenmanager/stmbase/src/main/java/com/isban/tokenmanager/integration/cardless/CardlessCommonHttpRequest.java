package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.isban.tokenmanager.util.Constants;

import io.swagger.annotations.ApiModelProperty;

public class CardlessCommonHttpRequest {

    @ApiModelProperty(required = true)
    @Pattern(regexp = Constants.PATTERN_DATETIME)
    private String optime;
    
    @ApiModelProperty(required = true)
    @Size(max = 4, min = 2)
    private String nrbe;
    
    @ApiModelProperty(required = true)
    @Size(max = Constants.TOKEN_REQUESTOR_ID_LENGTH, min = Constants.TOKEN_REQUESTOR_ID_LENGTH)    
    private String requestorId;

    public String getOptime() {
        return optime;
    }

    public void setOptime(String optime) {
        this.optime = optime;
    }

    public String getNrbe() {
        return nrbe;
    }

    public void setNrbe(String nrbe) {
        this.nrbe = nrbe;
    }

    public String getRequestorId() {
        return requestorId;
    }

    public void setRequestorId(String requestorId) {
        this.requestorId = requestorId;
    }

}
