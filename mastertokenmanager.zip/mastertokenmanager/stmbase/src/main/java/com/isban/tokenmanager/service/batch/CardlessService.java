package com.isban.tokenmanager.service.batch;

public interface CardlessService {
    void getReportRequestOpenedInDate(String issuerId, String tokenTypeId);
    void getDailyConciliationFile(String issuerId, String tokenTypeId, String executionDate);
}
