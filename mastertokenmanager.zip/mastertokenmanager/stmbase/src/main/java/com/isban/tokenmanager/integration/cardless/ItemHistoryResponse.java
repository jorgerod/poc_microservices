package com.isban.tokenmanager.integration.cardless;

import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.isban.tokenmanager.dto.ResponseBase;
import com.isban.tokenmanager.model.enm.ResponseStateEnum;
import com.isban.tokenmanager.util.Constants;

import io.swagger.annotations.ApiModelProperty;

public class ItemHistoryResponse extends ResponseBase{
    
    String nrbe;
    String tokenState;
    String customerId;
    String contract;
    String branchOffice;
    String requestTime;
    String amount;
    String currency;
    String smsPhone;
    String smsDelay;
    String expireTime;
    Boolean smsSend;
    String atmId;
    
    
    List<TokenEvent> eventList;


    public ItemHistoryResponse(String code, String description) {
        super(code, description);
    }
    
    public ItemHistoryResponse() {
        super();
    }

    public ItemHistoryResponse(ResponseStateEnum stateEnum) {
        super(stateEnum.getCode(), stateEnum.getDescription());
    }

    @ApiModelProperty(value = "Entity code.", required = true)
    @Size(max = 4)
    public String getNrbe() {
        return nrbe;
    }
    public void setNrbe(String nrbe) {
        this.nrbe = nrbe;
    }

    @ApiModelProperty(value = "State of the token.", required = true)
    @Pattern(regexp="\\d+")
    @Size(max = 2)
    public String getTokenState() {
        return tokenState;
    }
    public void setTokenState(String tokenState) {
        this.tokenState = tokenState;
    }

    @ApiModelProperty(value = "Id of the customer associate to the token.", required = true)
    @Size(max = 10)
    public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    @ApiModelProperty(value = "Partenon Contract Number associate to the token.", required = true)
    @Size(max = 18)
    public String getContract() {
        return contract;
    }
    public void setContract(String contract) {
        this.contract = contract;
    }

    @ApiModelProperty(value = "Branch office that asked the token.", required = true)
    @Size(max = 4)
    public String getBranchOffice() {
        return branchOffice;
    }
    public void setBranchOffice(String branchOffice) {
        this.branchOffice = branchOffice;
    }

    @ApiModelProperty(value = "Date and time of token request", required = true)
    @Pattern(regexp = Constants.PATTERN_DATETIME)
    @Size(max = 19)    
    public String getRequestTime() {
        return requestTime;
    }
    public void setRequestTime(String requestTime) {
        this.requestTime = requestTime;
    }

    @ApiModelProperty(value = "Amount requested.", required = true)
    @Pattern(regexp="\\d+")
    @Size(max = 12)
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }

    @ApiModelProperty(value = "Currency associated to the amount. (ISO 4217)", required = true)
    @Pattern(regexp="\\d+")
    @Size(max = 3)
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @ApiModelProperty(value = "Phone number where send the sms.", required = true)
    @Size(max = 15)
    public String getSmsPhone() {
        return smsPhone;
    }
    public void setSmsPhone(String smsPhone) {
        this.smsPhone = smsPhone;
    }

    @ApiModelProperty(value = "Delay between token registration and sms send (expressed in minutes).", required = true)
    @Pattern(regexp="\\d+")
    @Size(max = 6)
    public String getSmsDelay() {
        return smsDelay;
    }
    public void setSmsDelay(String smsDelay) {
        this.smsDelay = smsDelay;
    }

    @ApiModelProperty(value = "Date and time at what the token expires", required = true)
    @Pattern(regexp = Constants.PATTERN_DATETIME)
    @Size(max = 19)    
    public String getExpireTime() {
        return expireTime;
    }
    public void setExpireTime(String expireTime) {
        this.expireTime = expireTime;
    }

    @ApiModelProperty(value = "Flag to indicate if the sms has been sent", required = true)
    @Pattern(regexp="[true|false]")
    @Size(max = 5)
    public Boolean getSmsSend() {
        return smsSend;
    }
    public void setSmsSend(Boolean smsSend) {
        this.smsSend = smsSend;
    }

    @ApiModelProperty(value = "Id of the ATM of the cash withdrawal", required = true)
    @Size(max = 8)
    public String getAtmId() {
        return atmId;
    }
    public void setAtmId(String atmId) {
        this.atmId = atmId;
    }

    public List<TokenEvent> getEventList() {
        return eventList;
    }
    public void setEventList(List<TokenEvent> eventList) {
        this.eventList = eventList;
    }
    
    @JsonProperty(value = "responseCode")
    @ApiModelProperty(value = "Response code indicating the result.", required = true)
    @Size(max = 4)
    @Override
    public String getCode() {
        return super.getCode();
    }
    
    @ApiModelProperty(value = "description.", required = false)
    @JsonProperty(value = "errorDescription")
    @Size(max = 256)
    @Override
    public String getDescription() {
        return super.getDescription();
    }
    
    @Override
    public void setCode(String c) {
        super.setCode(c);
    }
    
    @Override
    public void setDescription(String d) {
        super.setDescription(d);
    }
}
