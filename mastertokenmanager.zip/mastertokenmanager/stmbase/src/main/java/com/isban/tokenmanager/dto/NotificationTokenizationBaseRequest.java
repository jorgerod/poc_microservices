package com.isban.tokenmanager.dto;

public class NotificationTokenizationBaseRequest extends NotificationCommonDataRequest {

    private String clientId = null;
    
    // Device
    private DeviceDto device = new DeviceDto();
    
    private String cardHolderWalletAccount = null;
    private String walletRiskAssessment = null;
    private String walletRiskAssessmentVersion = null;
    private String walletDeviceScore = null;
    private String walletAccountScore = null;
    private String walletReasonCode = null;
    private String panSource = null;


    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public DeviceDto getDevice() {
        return device;
    }

    public void setDevice(DeviceDto device) {
        this.device = device;
    }

    public String getCardHolderWalletAccount() {
        return cardHolderWalletAccount;
    }

    public void setCardHolderWalletAccount(String cardHolderWalletAccount) {
        this.cardHolderWalletAccount = cardHolderWalletAccount;
    }

    public String getWalletRiskAssessment() {
        return walletRiskAssessment;
    }

    public void setWalletRiskAssessment(String walletRiskAssessment) {
        this.walletRiskAssessment = walletRiskAssessment;
    }

    public String getWalletRiskAssessmentVersion() {
        return walletRiskAssessmentVersion;
    }

    public void setWalletRiskAssessmentVersion(String walletRiskAssessmentVersion) {
        this.walletRiskAssessmentVersion = walletRiskAssessmentVersion;
    }

    public String getWalletDeviceScore() {
        return walletDeviceScore;
    }

    public void setWalletDeviceScore(String walletDeviceScore) {
        this.walletDeviceScore = walletDeviceScore;
    }

    public String getWalletAccountScore() {
        return walletAccountScore;
    }

    public void setWalletAccountScore(String walletAccountScore) {
        this.walletAccountScore = walletAccountScore;
    }

    public String getWalletReasonCode() {
        return walletReasonCode;
    }

    public void setWalletReasonCode(String walletReasonCode) {
        this.walletReasonCode = walletReasonCode;
    }

    public String getItemSource() {
        return panSource;
    }

    public void setPanSource(String panSource) {
        this.panSource = panSource;
    }

    public String getPanSource() {
        return panSource;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("NotificationTokenizationBaseRequest [clientId=")
                .append(clientId).append(", device=").append(device).append(", cardHolderWalletAccount=")
                .append(cardHolderWalletAccount).append(", walletRiskAssessment=").append(walletRiskAssessment)
                .append(", walletRiskAssessmentVersion=").append(walletRiskAssessmentVersion)
                .append(", walletDeviceScore=").append(walletDeviceScore).append(", walletAccountScore=")
                .append(walletAccountScore).append(", walletReasonCode=").append(walletReasonCode)
                .append(", panSource=").append(panSource).append("]");
        return builder.toString();
    }

}
