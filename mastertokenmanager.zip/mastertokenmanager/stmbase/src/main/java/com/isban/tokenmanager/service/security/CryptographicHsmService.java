package com.isban.tokenmanager.service.security;

public interface CryptographicHsmService extends CryptographicService {
    public String generateMac(String msgRequest, String tokenBase64);
    public String encrypt(String msgRequest, String tokenBase64);
    public String decrypt(String value, String tokenSecurity);
}
