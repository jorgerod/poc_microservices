package com.isban.tokenmanager.dto.mdes.enm;

public enum DecisionMadeByMdesEnum {
    ELIGIBILITY_REQUEST,
    AUTHORIZATION_REQUEST,
    RULES;
}
