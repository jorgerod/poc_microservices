package com.isban.tokenmanager.dto;

public class UserGetProfileRequest extends ModelBaseDto {

    private String userId;

    public UserGetProfileRequest() {
    }

    public UserGetProfileRequest(String userId, String issuerId) {
        this.userId = userId;
        this.issuerId = issuerId;
    }
    
    public UserGetProfileRequest(String userId, String issuerId, String tokenTypeId) {
        this(userId, issuerId);
        this.tokenTypeId = tokenTypeId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
