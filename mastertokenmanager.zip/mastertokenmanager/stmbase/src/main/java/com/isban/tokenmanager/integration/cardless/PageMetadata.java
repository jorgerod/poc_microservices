package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Pattern;

import io.swagger.annotations.ApiModelProperty;

public class PageMetadata {

    int totalElements;
    int totalPages;
    int size;
    int number;

    public PageMetadata(int size, int totalElements, int number, int totalPages) {
        this.setNumber(number);
        this.setTotalPages(totalPages);
        this.setSize(size);
        this.setTotalElements(totalElements);
    }

    @ApiModelProperty(value = "Indicates total number of elements that the query returns", required = true)
    @Pattern(regexp = "\\d+")
    public int getTotalElements() {
        return totalElements;
    }

    public void setTotalElements(int totalElements) {
        this.totalElements = totalElements;
    }

    @ApiModelProperty(value = "Indicates total number of pages that the query returns", required = true)
    @Pattern(regexp = "\\d+")
    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    @ApiModelProperty(value = "Indicates number of elements returned", required = true)
    @Pattern(regexp = "\\d+")
    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    @ApiModelProperty(value = "Indicates page number returned (0 based index)", required = true)
    @Pattern(regexp = "\\d+")
    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
