package com.isban.tokenmanager.service.security.impl;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.MGF1ParameterSpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource.PSpecified;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Service;

import com.isban.tokenmanager.service.security.CryptographicMdesService;

@Service(value = "cryptographicMdesServiceImpl")
public class CryptographicMdesServiceImpl extends CryptographicBase implements CryptographicMdesService {
    // ///////////////////////////////////////////////////////////////////////
    //CryptographicMdesService - > SKC + PKC
    @Override
    public MdesEncOutput encrypt( EncSkcInput input4encSkc, EncPkcOaepInput input4encPkcOaep ) {
        //initial checks
        MdesEncOutput ret = null;
        if( input4encSkc == null ){ return ret; }
        if( input4encSkc.msg == null ){ return ret; }
        if( input4encPkcOaep == null ){ return ret; }
        if( input4encPkcOaep.publicKey == null ){ return ret; }
        if( input4encPkcOaep.oaepHashingAlgorithm == null ){ return ret; }
        
        //init return object
        ret = new MdesEncOutput();
        ret.input4encSkc = input4encSkc;
        ret.input4encPkcOaep = input4encPkcOaep;
        
        //creates iv+otpSecretKey 
        ret.input4encSkc.otpSecretKey = generateOtpSecretKey();
        ret.input4encSkc.iv = generateIv();
        // ... encrypt msg
        ret.encryptedMsg = encrypt( ret.input4encSkc );
        
        //... AND encrypt otpSecretKey
        ret.input4encPkcOaep.msg = ret.input4encSkc.otpSecretKey;
        ret.encryptedOtpSecretKey = encryptOtpSecretKey( ret.input4encPkcOaep );
        
        //finally returns
        return ret;
    }

    @Override
    public byte[] decrypt( DecPkcOaepInput input4decPkcOaep, DecSkcInput input4decSkc ) {
        //initial checks
        byte ret[] = null;
        if( input4decPkcOaep == null ){ return ret; }
        if( input4decSkc == null ){ return ret; }
        if( input4decSkc.encryptedMsg == null ){ return ret; }
        if( input4decSkc.iv == null ){ return ret; }

        //decrypt otpSecretKey
        input4decSkc.otpSecretKey = decryptOtpSecretKey( input4decPkcOaep );
        
        //... AND decrypt encryptedMsg
        ret = decrypt( input4decSkc );
        
        //finally returns
        return ret;
    }
    
    
    
    
    
    // ///////////////////////////////////////////////////////////////////////
    //SKC = https://en.wikipedia.org/wiki/Cryptography#Symmetric-key_cryptography
    @Override
    public byte[] generateOtpSecretKey() {
        return createRandomBytes(16); //secretKey ... 128 bits
    }

    @Override
    public byte[] generateIv() {
        return createRandomBytes(16); //iv ... 128 bits
    }

    @Override
    public byte[] encrypt(EncSkcInput input4enc) {
        byte ret[] = null;
        if( input4enc == null ){ return ret; }
        if( input4enc.msg == null ){ return ret; }
        if( input4enc.otpSecretKey == null ){ return ret; }
        if( input4enc.iv == null ){ return ret; }
        
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(input4enc.otpSecretKey , "AES");
            IvParameterSpec ivParameterSpec = new IvParameterSpec(input4enc.iv);
            
            Cipher cipher = Cipher.getInstance( "AES/CBC/PKCS5Padding" );
            cipher.init( Cipher.ENCRYPT_MODE, skeySpec, ivParameterSpec );
            ret = cipher.doFinal(input4enc.msg);
            
            
        } catch( InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | 
                 InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e ) {
            e.printStackTrace();
        }

        return ret;
    }

    @Override
    public byte[] decrypt(DecSkcInput input4dec) {
        byte ret[] = null;
        if( input4dec == null ){ return ret; }
        if( input4dec.encryptedMsg == null ){ return ret; }
        if( input4dec.otpSecretKey == null ){ return ret; }
        if( input4dec.iv == null ){ return ret; }
        
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(input4dec.otpSecretKey , "AES");
            IvParameterSpec ivParameterSpec = new IvParameterSpec(input4dec.iv);
            
            Cipher cipher = Cipher.getInstance( "AES/CBC/PKCS5Padding" );
            cipher.init( Cipher.DECRYPT_MODE, skeySpec, ivParameterSpec );
            ret = cipher.doFinal(input4dec.encryptedMsg);
            
            
        } catch( InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | 
                 InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e ) {
            e.printStackTrace();
        }

        return ret;
    }
    
    
    
    
    
    
    // ///////////////////////////////////////////////////////////////////////
    //PKC = https://en.wikipedia.org/wiki/Cryptography#Public-key_cryptography
    @Override
    public byte[] encryptOtpSecretKey(EncPkcOaepInput input4enc) {
        byte ret[] = null;
        if( input4enc == null ){ return ret; }
        if( input4enc.msg == null ){ return ret; }
        if( input4enc.publicKey == null ){ return ret; }
        if( input4enc.oaepHashingAlgorithm == null ){ return ret; }
        
        try {
            RSAPublicKey pubkey = (RSAPublicKey)input4enc.publicKey;
            
            Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWITH" + input4enc.oaepHashingAlgorithm + "ANDMGF1PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, pubkey);
            ret = cipher.doFinal(input4enc.msg);
            
            
        } catch( InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | 
                 IllegalBlockSizeException | BadPaddingException e ) {
            e.printStackTrace();
        }

        return ret;
    }

    @Override
    public byte[] decryptOtpSecretKey(DecPkcOaepInput input4dec) {
        byte ret[] = null;
        if( input4dec == null ){ return ret; }
        if( input4dec.encryptedMsg == null ){ return ret; }
        if( input4dec.privateKey == null ){ return ret; }
        if( input4dec.oaepHashingAlgorithm == null ){ return ret; }
        
        try {
            RSAPrivateKey privkey = (RSAPrivateKey)input4dec.privateKey;
            
            Cipher deCipher = Cipher.getInstance( "RSA/ECB/OAEPPadding" );
            OAEPParameterSpec oaepParams = new OAEPParameterSpec( input4dec.oaepHashingAlgorithm, "MGF1", new MGF1ParameterSpec("SHA-1"), PSpecified.DEFAULT );
            deCipher.init( Cipher.DECRYPT_MODE, privkey, oaepParams );
            ret = deCipher.doFinal(input4dec.encryptedMsg);
            
            
        } catch( InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | 
                 IllegalBlockSizeException | BadPaddingException | InvalidAlgorithmParameterException e ) {
            e.printStackTrace();
        }

        return ret;
    }
}
