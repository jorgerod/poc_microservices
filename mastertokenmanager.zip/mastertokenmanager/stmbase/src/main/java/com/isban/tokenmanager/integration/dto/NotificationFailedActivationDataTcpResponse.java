package com.isban.tokenmanager.integration.dto;

public class NotificationFailedActivationDataTcpResponse extends TcpCommonDataResponse {

    public NotificationFailedActivationDataTcpResponse() {
        super();
    }

    public NotificationFailedActivationDataTcpResponse(NotificationFailedActivationDataTcpRequest request) {
        super(request.getOperationId(), request.getOperationDateTime());
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("NotificationFailedActivationDataTcpResponse [getOperationId()=").append(getOperationId())
                .append(", getOperationDateTime()=").append(getOperationDateTime()).append("]");
        return builder.toString();
    }

}
