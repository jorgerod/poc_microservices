package com.isban.tokenmanager.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isban.tokenmanager.model.enm.RequestStateEnum;

public class RequestDto extends ModelBaseDto {

    private String requestId = null;

    private TokenRequestorDto issuerTokenTypeTr = new TokenRequestorDto();

    private String customerId = null;
    private String clientId = null;

    // Device
    private DeviceDto device = new DeviceDto();
    
    // Request info
    private String cardHolderWalletAccount = null;
    private String walletRiskAssessment = null;
    private String walletRiskAssessmentVersion = null;
    private String walletDeviceScore = null;
    private String walletAccountScore = null;
    private String walletReasonCode = null;
    private String itemSource = null;

    private String typedoc = null;
    private String doc = null;
    private String customerExt = null;

//    private String ticketExt = null;

    private String requestStateId = null;
    private String requestStateName = null;
    public Date dateInit = null;
    private String pan = null;
    private String itemReferenceId = null;
    private String correlationId;
    

    @JsonIgnore
    private RequestStateEnum requestStateEnumCurrent = null;

    @JsonIgnore
    private RequestStateEnum requestStateEnumNew = null;

    private List<TokenDto> tokens = new ArrayList<>();
    private List<String> actions = new ArrayList<>();

    // openbank
    private String channelFrame = null;
    private String centerMultiChannel = null;
    private String productMultiChannel = null;
    private String numberContractMultiChannel = null;

    // security
    @JsonIgnore
    private String tokenBase64 = null;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestStateId() {
        return requestStateId;
    }

    public void setRequestStateId(String requestStateId) {
        this.requestStateId = requestStateId;
    }

    public String getRequestStateName() {
        return requestStateName;
    }

    public void setRequestStateName(String requestStateName) {
        this.requestStateName = requestStateName;
    }

    public Date getDateInit() {
        return dateInit;
    }

    public void setDateInit(Date dateInit) {
        this.dateInit = dateInit;
    }

    public RequestStateEnum getRequestStateEnumCurrent() {
        return requestStateEnumCurrent;
    }

    public void setRequestStateEnumCurrent(RequestStateEnum requestStateEnumCurrent) {
        this.requestStateEnumCurrent = requestStateEnumCurrent;
    }

    public RequestStateEnum getRequestStateEnumNew() {
        return requestStateEnumNew;
    }

    public void setRequestStateEnumNew(RequestStateEnum requestStateEnumNew) {
        this.requestStateEnumNew = requestStateEnumNew;
    }

    public List<String> getActions() {
        return actions;
    }

    public void setActions(List<String> actions) {
        this.actions = actions;
    }

    public List<TokenDto> getTokens() {
        return tokens;
    }

    public void setTokens(List<TokenDto> tokens) {
        this.tokens = tokens;
    }

    public String getItem() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public TokenRequestorDto getIssuerTokenTypeTr() {
        return issuerTokenTypeTr;
    }

    public void setIssuerTokenTypeTr(TokenRequestorDto issuerTokenTypeTr) {
        this.issuerTokenTypeTr = issuerTokenTypeTr;
    }

    public String getCardHolderWalletAccount() {
        return cardHolderWalletAccount;
    }

    public void setCardHolderWalletAccount(String cardHolderWalletAccount) {
        this.cardHolderWalletAccount = cardHolderWalletAccount;
    }

    public String getWalletRiskAssessment() {
        return walletRiskAssessment;
    }

    public void setWalletRiskAssessment(String walletRiskAssessment) {
        this.walletRiskAssessment = walletRiskAssessment;
    }

    public String getWalletRiskAssessmentVersion() {
        return walletRiskAssessmentVersion;
    }

    public void setWalletRiskAssessmentVersion(String walletRiskAssessmentVersion) {
        this.walletRiskAssessmentVersion = walletRiskAssessmentVersion;
    }

    public String getWalletDeviceScore() {
        return walletDeviceScore;
    }

    public void setWalletDeviceScore(String walletDeviceScore) {
        this.walletDeviceScore = walletDeviceScore;
    }

    public String getWalletAccountScore() {
        return walletAccountScore;
    }

    public void setWalletAccountScore(String walletAccountScore) {
        this.walletAccountScore = walletAccountScore;
    }

    public String getWalletReasonCode() {
        return walletReasonCode;
    }

    public void setWalletReasonCode(String walletReasonCode) {
        this.walletReasonCode = walletReasonCode;
    }

    public String getItemSource() {
        return itemSource;
    }

    public void setItemSource(String itemSource) {
        this.itemSource = itemSource;
    }

    public String getTokenBase64() {
        return tokenBase64;
    }

    public void setTokenBase64(String tokenBase64) {
        this.tokenBase64 = tokenBase64;
    }

    public String getTypedoc() {
        return typedoc;
    }

    public void setTypedoc(String typedoc) {
        this.typedoc = typedoc;
    }

    public String getDoc() {
        return doc;
    }

    public void setDoc(String doc) {
        this.doc = doc;
    }

    public String getCustomerExt() {
        return customerExt;
    }

    public void setCustomerExt(String customerExt) {
        this.customerExt = customerExt;
    }

    public String getChannelFrame() {
        return channelFrame;
    }

    public void setChannelFrame(String channelFrame) {
        this.channelFrame = channelFrame;
    }

    public String getCenterMultiChannel() {
        return centerMultiChannel;
    }

    public void setCenterMultiChannel(String centerMultiChannel) {
        this.centerMultiChannel = centerMultiChannel;
    }

    public String getProductMultiChannel() {
        return productMultiChannel;
    }

    public void setProductMultiChannel(String productMultiChannel) {
        this.productMultiChannel = productMultiChannel;
    }

    public String getNumberContractMultiChannel() {
        return numberContractMultiChannel;
    }

    public void setNumberContractMultiChannel(String numberContractMultiChannel) {
        this.numberContractMultiChannel = numberContractMultiChannel;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public DeviceDto getDevice() {
        return device;
    }

    public void setDevice(DeviceDto device) {
        this.device = device;
    }

    public String getPan() {
        return pan;
    }

    public String getItemReferenceId() {
        return itemReferenceId;
    }

    public void setItemReferenceId(String itemReferenceId) {
        this.itemReferenceId = itemReferenceId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

}
