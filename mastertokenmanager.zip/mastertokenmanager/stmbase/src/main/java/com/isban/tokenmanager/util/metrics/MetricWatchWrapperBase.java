package com.isban.tokenmanager.util.metrics;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.boot.actuate.metrics.CounterService;
import org.springframework.boot.actuate.metrics.GaugeService;
import org.springframework.util.StopWatch;

public class MetricWatchWrapperBase<T> implements MetricWatchWrapper<T> {
    protected CounterService counterService;
    protected GaugeService gaugeService;
    protected StopWatch stopWatch;
    protected String sufix;
    protected String okStatus = "200";
    protected String koStatus = "990";
    protected String endSufixToAdd = ".stm";
    
    public MetricWatchWrapperBase( 
            CounterService cS, 
            GaugeService gS, 
            String s ){
        super();
        counterService = cS;
        gaugeService = gS;
        stopWatch = new StopWatch();
        stopWatch.start();
        sufix = s;
    }
    
    @Override
    public T wrap(T wrapped) {
        //add gauge value
        stopWatch.stop();
        String key = getKey("gauge.response." + sufix + "." +  getEndSufixToAdd() );
        gaugeService.submit(key, stopWatch.getTotalTimeMillis());
        
        //add status value
        String status = selectStatus( wrapped );
        key = getKey("counter.status." + status + "." + sufix + "." +  getEndSufixToAdd() );
        counterService.increment(key);

        return wrapped;
    }
    
    @Override
    public String selectStatus(T wrapped) {
        String ret = getKoStatus();
        if( wrapped == null ){ return ret; }
        
        ret = getOkStatus();
        return ret;
    }
    
    @Override
    public String getOkStatus() {
        return okStatus;
    }
    @Override
    public String getKoStatus() {
        return koStatus;
    }
    
    @Override
    public String getEndSufixToAdd() {
        String ret = "";
        if(endSufixToAdd == null){ return ret; }
        
        ret = endSufixToAdd;
        return ret;
    }
    
    public void setOkStatus(String okStatus) {
        this.okStatus = okStatus;
    }
    
    public void setKoStatus(String koStatus) {
        this.koStatus = koStatus;
    }
    
    public void setEndSufixToAdd(String endSufixToAdd) {
        this.endSufixToAdd = endSufixToAdd;
    }
    
    
    
    private static final Set<PatternReplacer> KEY_REPLACERS;
    static {
        Set<PatternReplacer> replacements = new LinkedHashSet<PatternReplacer>();
        replacements.add(new PatternReplacer("/", Pattern.LITERAL, "."));
        replacements.add(new PatternReplacer("..", Pattern.LITERAL, "."));
        KEY_REPLACERS = Collections.unmodifiableSet(replacements);
    }
    
    private String getKey(String string) {
        // graphite compatible metric names
        String key = string;
        for (PatternReplacer replacer : KEY_REPLACERS) {
            key = replacer.apply(key);
        }
        if (key.endsWith(".")) {
            key = key + "root";
        }
        if (key.startsWith("_")) {
            key = key.substring(1);
        }
        return key;
    }
    
    private static class PatternReplacer {
        private final Pattern pattern;
        private final String replacement;

        PatternReplacer(String regex, int flags, String replacement) {
            this.pattern = Pattern.compile(regex, flags);
            this.replacement = replacement;
        }

        public String apply(String input) {
            return this.pattern.matcher(input)
                    .replaceAll(Matcher.quoteReplacement(this.replacement));
        }
    }
}
