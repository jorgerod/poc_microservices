package com.isban.tokenmanager.dto;

public enum DecisionMadeByEnum {
    ELIGIBILITY_REQUEST("00"),
    AUTHORIZATION_REQUEST("01"),
    RULES("02");
    
    private String code;
    
    DecisionMadeByEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
