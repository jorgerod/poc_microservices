package com.isban.tokenmanager.dto;

import java.util.List;

public class GetIssuerSitCardsResponse extends ResponseBase {

    private List<SitCardDto> issuerSitCards;

    public GetIssuerSitCardsResponse() {
    }

    public GetIssuerSitCardsResponse(String code, String description) {
        super(code, description);
    }

    public List<SitCardDto> getIssuerSitCards() {
        return issuerSitCards;
    }

    public void setIssuerSitCards(List<SitCardDto> issuerSitCards) {
        this.issuerSitCards = issuerSitCards;
    }

    @Override
    public String toString() {
        return "GetIssuerSitCardsResponse [issuerSitCards=" + issuerSitCards + "]";
    }

}
