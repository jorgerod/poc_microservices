package com.isban.tokenmanager.dto;


public class NotificationCustomerRequest {

    private String customerid;
    private String messageid;
    private String typemedia;
    private String valuemedia;
    private String language;

    public String getCustomerid() {
        return customerid;
    }

    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }

    public String getMessageid() {
        return messageid;
    }

    public void setMessageid(String messageid) {
        this.messageid = messageid;
    }

    public String getTypemedia() {
        return typemedia;
    }

    public void setTypemedia(String typemedia) {
        this.typemedia = typemedia;
    }

    public String getValuemedia() {
        return valuemedia;
    }

    public void setValuemedia(String valuemedia) {
        this.valuemedia = valuemedia;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }
}
