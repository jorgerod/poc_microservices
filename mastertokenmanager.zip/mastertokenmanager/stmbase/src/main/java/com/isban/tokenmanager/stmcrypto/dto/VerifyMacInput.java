package com.isban.tokenmanager.stmcrypto.dto;

public class VerifyMacInput {

    /*
     * Properties
     */
    private KeyData keyData;

    /*
     * Allowed values for input format data
     * '0': binary
     * '1': hex-encoded binary
     * '2': text
     */
    private String inputFormat;
    
    /*
     * Allowed values for MAC size
     * '0': MAC size of 8 hex digits
     * '1': MAC size of 16 hex digits
     */
    private String macSize;

    /*
     * Allowed values for MAC Algorithm
     * '1': ISO 9797 MAC Algorithm 1 ( = ANSI X9.9 when used with a single-length key)
     * '2': ISO 9797 MAC Algorithm 3 ( = ANSI X9.19 when used with a double-length key)
     */
    private String macAlgorithm;
    
	/* 
	 * Allowed values for THALES padding
	 * 0: No padding
	 * 1: ISO 9797 Padding method 1 (i.e. pad with 0x00)
	 * 2: ISO 9797 Padding method 2 (i.e. add 0x80 and pad with 0x00)
	 */
	private String paddingMethod;
	
	private String iv;
	private String message;
	private String macToVerify;
	
	/*
	 * Getters and setters
	 */
    public KeyData getKeyData() {
        return keyData;
    }
    public void setKeyData(KeyData keyData) {
        this.keyData = keyData;
    }

    public String getInputFormat() {
        return inputFormat;
    }
    public void setInputFormat(String inputFormat) {
        this.inputFormat = inputFormat;
    }
    
    public String getMacSize() {
        return macSize;
    }
    public void setMacSize(String macSize) {
        this.macSize = macSize;
    }
    
    public String getMacAlgorithm() {
        return macAlgorithm;
    }
    public void setMacAlgorithm(String macAlgorithm) {
        this.macAlgorithm = macAlgorithm;
    }
    
    public String getPaddingMethod() {
        return paddingMethod;
    }
    public void setPaddingMethod(String paddingMethod) {
        this.paddingMethod = paddingMethod;
    }

    public String getIv() {
        return iv;
    }
    public void setIv(String iv) {
        this.iv = iv;
    }

    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
	
    public String getMacToVerify() {
        return macToVerify;
    }
    public void setMacToVerify(String macToVerify) {
        this.macToVerify = macToVerify;
    }
}
