package com.isban.tokenmanager.dto.mdes;

public class CardholderData {

    private String sourceIp;
    private String deviceLocation;

    public String getSourceIp() {
        return sourceIp;
    }

    public void setSourceIp(String sourceIp) {
        this.sourceIp = sourceIp;
    }

    public String getDeviceLocation() {
        return deviceLocation;
    }

    public void setDeviceLocation(String deviceLocation) {
        this.deviceLocation = deviceLocation;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CardholderData [sourceIp=").append(sourceIp).append(", deviceLocation=").append(deviceLocation)
                .append("]");
        return builder.toString();
    }

}
