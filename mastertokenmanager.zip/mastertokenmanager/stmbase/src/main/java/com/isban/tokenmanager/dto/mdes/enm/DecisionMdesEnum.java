package com.isban.tokenmanager.dto.mdes.enm;

public enum DecisionMdesEnum {
    APPROVED, 
    DECLINED, 
    REQUIRE_ADDITIONAL_AUTHENTICATION;
}
