package com.isban.tokenmanager.dto;


public class NotificationSuspendResponse extends ResponseBase {
    
    public NotificationSuspendResponse() {}

    public NotificationSuspendResponse(String code, String description) {
        super(code, description);
    }
}
