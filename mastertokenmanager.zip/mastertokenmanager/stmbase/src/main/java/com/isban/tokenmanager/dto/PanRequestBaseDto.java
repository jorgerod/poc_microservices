package com.isban.tokenmanager.dto;

import java.util.Date;

public class PanRequestBaseDto {
    
    private Date operationDate = null;
    private String panRequestStateId = null;
    private String panRequestStateName = null;
    
    public Date getOperationDate() {
        return operationDate;
    }
    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }
    public String getTokenStateId() {
        return panRequestStateId;
    }
    public void setPanRequestStateId(String panRequestStateId) {
        this.panRequestStateId = panRequestStateId;
    }
    public String getTokenStateName() {
        return panRequestStateName;
    }
    public void setPanRequestStateName(String panRequestStateName) {
        this.panRequestStateName = panRequestStateName;
    }
}
