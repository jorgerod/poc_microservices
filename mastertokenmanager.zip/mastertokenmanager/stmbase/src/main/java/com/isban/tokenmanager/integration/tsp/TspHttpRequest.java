package com.isban.tokenmanager.integration.tsp;

public class TspHttpRequest {
    
    private String transactionId;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
    
}
