package com.isban.tokenmanager.dto;

public class SitCardDto extends LifeTimeDto {

    private String sitCardId;
    private String description;

    public SitCardDto() {
        
    }
    
    public SitCardDto(String issuerId, String tokenTypeId, String sitCardId, String description) {
        this.issuerId = issuerId;
        this.tokenTypeId = tokenTypeId;
        this.sitCardId = sitCardId;
        this.description = description;
    }

    public String getSitCardId() {
        return sitCardId;
    }

    public void setSitCardId(String sitCardId) {
        this.sitCardId = sitCardId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    @Override
    public String toString() {
        return "IssuerSitCardDto [sitCardId=" + sitCardId + ", description=" + description + "]";
    }

}
