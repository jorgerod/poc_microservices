package com.isban.tokenmanager.dto;



public class PaymentResponse extends ResponseBase {

    public PaymentResponse() {
        super();
    }

    public PaymentResponse(String code, String description) {
        super(code, description);
    }

    @Override
    public String toString() {
        return "PaymentResponse [getCode()=" + getCode()
                + ", getDescription()=" + getDescription() + "]";
    }
}
