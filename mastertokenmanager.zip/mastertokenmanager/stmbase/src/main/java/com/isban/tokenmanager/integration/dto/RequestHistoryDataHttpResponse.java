package com.isban.tokenmanager.integration.dto;

import com.isban.tokenmanager.dto.RequestHistoryDto;

import java.util.List;

/**
 * @author Sergey Zlobin
 * @since 11/08/2015
 */
public class RequestHistoryDataHttpResponse {

    List<RequestHistoryDto> requestHistory;

    public List<RequestHistoryDto> getRequestHistory() {
        return requestHistory;
    }

    public void setRequestHistory(List<RequestHistoryDto> requestHistory) {
        this.requestHistory = requestHistory;
    }
}
