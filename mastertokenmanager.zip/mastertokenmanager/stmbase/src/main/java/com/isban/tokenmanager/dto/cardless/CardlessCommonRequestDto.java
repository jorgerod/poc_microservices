package com.isban.tokenmanager.dto.cardless;

import com.isban.tokenmanager.dto.ModelBaseDto;

public class CardlessCommonRequestDto extends ModelBaseDto {

    private String requestId;
    private String optime;
    private String customerExt;
    private String item;
    private String tokenRequestorId;
    private String requestStateId = null;

    public String getOptime() {
        return optime;
    }

    public void setOptime(String optime) {
        this.optime = optime;
    }

    public String getCustomerExt() {
        return customerExt;
    }

    public void setCustomerExt(String customerExt) {
        this.customerExt = customerExt;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getRequestStateId() {
        return requestStateId;
    }

    public void setRequestStateId(String requestStateId) {
        this.requestStateId = requestStateId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

}
