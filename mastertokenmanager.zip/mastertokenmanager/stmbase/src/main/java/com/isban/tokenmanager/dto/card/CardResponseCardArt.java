/**
 *
 */
package com.isban.tokenmanager.dto.card;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author realsec
 */
public class CardResponseCardArt extends CardResponse {

    private String expirationdateYYMM; 
    private String cardArtTag;

    @JsonProperty(value = "cardArtUrl")
    public String getCardArt() {
        return super.getCardArt();
    }
    
    public String getCardArtTag() {
        return cardArtTag;
    }

    public void setCardArtTag(String cardArtTag) {
        this.cardArtTag = cardArtTag;
    }

    @JsonProperty(value = "expirationDate")
    public String getExpirationdateYYMM() {
        return expirationdateYYMM;
    }

    @JsonProperty(value = "expirationdate")
    public void setExpirationdateYYMM(String expirationdateYYMM) {
        this.expirationdateYYMM = expirationdateYYMM;
    }

    @ApiModelProperty(required = false, hidden = true) 
    public Date getExpirationdate() {
        return super.getExpirationdate();
    }
    
    /**
     * @return the tyc
     */
    @ApiModelProperty(required = false, hidden = true) 
    public String getTyc() {
        return super.getTyc();
    }

    @ApiModelProperty(required = false, hidden = true) 
    public String getPvv() {
        return super.getPvv();
    }

    @ApiModelProperty(required = false, hidden = true) 
    public String getTicketref() {
        return super.getTicketref();
    }

    @ApiModelProperty(required = false, hidden = true) 
    public Boolean getIsregister() {
        return super.getIsregister();
    }
}
