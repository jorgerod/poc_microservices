package com.isban.tokenmanager.dto.mdes;

import java.util.List;

import javax.validation.constraints.Size;

public class DeviceInfoDto {
 
    @Size(max=64)
    private String deviceName;
    @Size(max=64)
    private String serialNumber; 
    @Size(max=2)
    private String isoDeviceType; 
    @Size(max=64)
    private String formFactor; //PHONE, TABLE or WATCH
    @Size(max=32)
    private String storageTechnology; //DEVICE_MEMORY, DEVICE_MEMORY_PROTECTED_TPM, TEE, SE, SERVER, VEE
    @Size(max=32)
    private String osName; // ANDROID, WINDOWS, TIZEN, IOS
    @Size(max=32)
    private String osVersion;
    private List<String> paymentTypes; //NFC, DSRP, ECOMMERCE
    @Size(min=15, max=15)
    private String imei;
    @Size(max=15)
    private String msisdn;
    
    public String getDeviceName() {
        return deviceName;
    }
    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }
    public String getSerialNumber() {
        return serialNumber;
    }
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
    public String getIsoDeviceType() {
        return isoDeviceType;
    }
    public void setIsoDeviceType(String isoDeviceType) {
        this.isoDeviceType = isoDeviceType;
    }
    public String getFormFactor() {
        return formFactor;
    }
    public void setFormFactor(String formFactor) {
        this.formFactor = formFactor;
    }
    public String getStorageTechnology() {
        return storageTechnology;
    }
    public void setStorageTechnology(String storageTechnology) {
        this.storageTechnology = storageTechnology;
    }
    public String getOsName() {
        return osName;
    }
    public void setOsName(String osName) {
        this.osName = osName;
    }
    public String getOsVersion() {
        return osVersion;
    }
    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }
    public List<String> getPaymentTypes() {
        return paymentTypes;
    }
    public void setPaymentTypes(List<String> paymentTypes) {
        this.paymentTypes = paymentTypes;
    }
    public String getImei() {
        return imei;
    }
    public void setImei(String imei) {
        this.imei = imei;
    }
    public String getMsisdn() {
        return msisdn;
    }
    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }
    
}