package com.isban.tokenmanager.dto;

import java.util.List;

public class GetActivationMethodsResponse extends ResponseBase {

    private List<ActivationMethodDto> activationMethods;

    public GetActivationMethodsResponse() {
    }

    public GetActivationMethodsResponse(String code, String description) {
        super(code, description);
    }

    public List<ActivationMethodDto> getActivationMethods() {
        return activationMethods;
    }

    public void setActivationMethods(List<ActivationMethodDto> activationMethods) {
        this.activationMethods = activationMethods;
    }

    @Override
    public String toString() {
        return "GetActivationMethodsResponse [activationMethods=" + activationMethods + "]";
    }

}
