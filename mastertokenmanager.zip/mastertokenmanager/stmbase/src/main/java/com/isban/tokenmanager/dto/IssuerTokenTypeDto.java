package com.isban.tokenmanager.dto;

public class IssuerTokenTypeDto {

    private String tokenTypeId = null;
    private String issuerId = null;

    public IssuerTokenTypeDto(String issuerId, String tokenTypeId) {
        super();
        this.tokenTypeId = tokenTypeId;
        this.issuerId = issuerId;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

}
