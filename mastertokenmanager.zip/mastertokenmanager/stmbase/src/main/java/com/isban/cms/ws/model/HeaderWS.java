package com.isban.cms.ws.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Security", propOrder = {
    "BinarySecurityToken"    
})
@XmlRootElement(name = "Security",namespace="http://www.isban.com/cms/ws/model/cms.xsd")
public class HeaderWS {

    @XmlElement(required = true)
    protected String BinarySecurityToken;



   public String getBinarySecurityToken() {
        return BinarySecurityToken;
    }
   public void setBinarySecurityToken(String value) {
        this.BinarySecurityToken = value;
    }   

}
