package com.isban.tokenmanager.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreType;

@JsonIgnoreType
public class StmMixInForSetOrList {

}
