package com.isban.tokenmanager.integration.dto;

public class PaymentDataTcpResponse extends TcpCommonDataResponse {

    public PaymentDataTcpResponse() {
        super();
    }

    public PaymentDataTcpResponse(String operationId, String operationDateTime) {
        super(operationId, operationDateTime);
    }

    public PaymentDataTcpResponse(PaymentDataTcpRequest paymentDataRequest) {
        super(paymentDataRequest.getOperationId(), paymentDataRequest.getOperationDateTime());
    }

    @Override
    public String toString() {
        return "PaymentDataTcpResponse [getOperationId()=" + getOperationId() + ", getOperationDate()="
                + getOperationDateTime() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
                + ", hashCode()=" + hashCode() + "]";
    }
}
