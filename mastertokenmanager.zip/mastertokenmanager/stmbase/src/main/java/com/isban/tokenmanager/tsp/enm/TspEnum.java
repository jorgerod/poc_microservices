package com.isban.tokenmanager.tsp.enm;

public enum TspEnum {
    STM("0000"), 
    AETS("0001"),
    MDES("0002"),
    SEGLAN("0004"),
    VEPTS("0006"),
    HUB_DIGITAL("0006"),
    REDSYS("0007");
    

    private String code;

    private TspEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public static TspEnum get(String code) {
        for (TspEnum c : values()) {
          if (c.code.equals(code)) {
            return c;
          }
        }
        // either throw the IAE or return null, your choice.
        throw new IllegalArgumentException(code);
    }
}
