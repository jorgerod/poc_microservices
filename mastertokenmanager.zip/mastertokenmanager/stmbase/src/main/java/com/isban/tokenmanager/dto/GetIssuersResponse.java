package com.isban.tokenmanager.dto;

import java.util.List;

public class GetIssuersResponse extends ResponseBase {

    private List<SearchIssuerDto> issuers;

    public GetIssuersResponse() {
    }

    public GetIssuersResponse(String code, String description) {
        super(code, description);
    }

    public List<SearchIssuerDto> getIssuers() {
        return issuers;
    }

    public void setIssuers(List<SearchIssuerDto> issuers) {
        this.issuers = issuers;
    }

    @Override
    public String toString() {
        return "GetIssuerResponse [issuers=" + issuers + "]";
    }

}
