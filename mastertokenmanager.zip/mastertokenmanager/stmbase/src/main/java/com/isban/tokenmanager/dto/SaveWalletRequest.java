package com.isban.tokenmanager.dto;

public class SaveWalletRequest extends WalletDto {

}
