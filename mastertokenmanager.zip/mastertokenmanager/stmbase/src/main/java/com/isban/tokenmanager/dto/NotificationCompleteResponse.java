package com.isban.tokenmanager.dto;

public class NotificationCompleteResponse extends ResponseBase {

    public NotificationCompleteResponse() {
    }

    public NotificationCompleteResponse(String code, String description) {
        super(code, description);
    }
}
