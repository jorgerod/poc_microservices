package com.isban.tokenmanager.dto;

public class SaveIssuerWalletResponse extends ResponseBase {

    private TokenRequestorDto issuerWalletDto;

    public SaveIssuerWalletResponse() {
    }

    public SaveIssuerWalletResponse(String code, String description) {
        super(code, description);
    }

    public TokenRequestorDto getIssuerWalletDto() {
        return issuerWalletDto;
    }

    public void setIssuerWalletDto(TokenRequestorDto issuerWalletDto) {
        this.issuerWalletDto = issuerWalletDto;
    }

    @Override
    public String toString() {
        return "SaveIssuerWalletResponse [issuerWalletDto=" + issuerWalletDto + "]";
    }

}
