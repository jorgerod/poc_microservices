package com.isban.tokenmanager.dto;

public class NotificationCreatedTokenResponse extends ResponseBase {

    public NotificationCreatedTokenResponse() {
    }

    public NotificationCreatedTokenResponse(String code, String description) {
        super(code, description);
    }
}
