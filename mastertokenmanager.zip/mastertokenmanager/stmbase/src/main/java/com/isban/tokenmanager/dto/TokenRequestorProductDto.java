package com.isban.tokenmanager.dto;

public class TokenRequestorProductDto extends LifeTimeDto {

    private String tokenTypeId = null;
    private String tokenRequestorId = null;
    private String productId;
    private String cartArtWallet;


    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getCartArtWallet() {
        return cartArtWallet;
    }

    public void setCartArtWallet(String cartArtWallet) {
        this.cartArtWallet = cartArtWallet;
    }

    public String getTokenTypeId() {
        return tokenTypeId;
    }

    public void setTokenTypeId(String tokenTypeId) {
        this.tokenTypeId = tokenTypeId;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

}
