package com.isban.tokenmanager.dto;

import java.util.List;

public class SaveBinDigitalResponse extends ResponseBase {

    private List<BinDigitalDto> binDigitals;

    public SaveBinDigitalResponse() {
    }

    public SaveBinDigitalResponse(String code, String description) {
        super(code, description);
    }

    public List<BinDigitalDto> getBinDigitals() {
        return binDigitals;
    }

    public void setBinDigitals(List<BinDigitalDto> binDigitals) {
        this.binDigitals = binDigitals;
    }

    @Override
    public String toString() {
        return "SaveBinDigitalResponse [binDigitals=" + binDigitals + "]";
    }

}
