package com.isban.tokenmanager.dto.metrics;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class GraphMetric {
    public String servicename;
    public long starttime;
    public List<MetricExtended> graph = new CopyOnWriteArrayList<MetricExtended>();
    
    @JsonIgnore
    public MetricExtended lastmetric;
    
    
    
    public String getServicename() {
        return servicename;
    }
    public void setServicename(String servicename) {
        this.servicename = servicename;
    }
    public long getStarttime() {
        return starttime;
    }
    public void setStarttime(long starttime) {
        this.starttime = starttime;
    }
    public MetricExtended getLastmetric() {
        return lastmetric;
    }
    public void setLastmetric(MetricExtended lastmetric) {
        this.lastmetric = lastmetric;
    }
    public List<MetricExtended> getGraph() {
        return graph;
    }
    public void setGraph(List<MetricExtended> graph) {
        this.graph = graph;
    }
}
