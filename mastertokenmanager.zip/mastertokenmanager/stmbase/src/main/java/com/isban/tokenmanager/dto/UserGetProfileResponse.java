package com.isban.tokenmanager.dto;

public class UserGetProfileResponse extends ResponseBase {

    private String roleId;
    private String userId;

    public UserGetProfileResponse(String code, String description) {
        super(code, description);
    }

    public UserGetProfileResponse() {
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
