package com.isban.tokenmanager.integration.dto;

import java.util.Date;
import java.util.List;

public class CardCms {
    
    String id;
    String pan;
    String issuerId;
    String customer;
    String product;
    String cardStatusCode;
    Date lastMovementDate;
    List<String> blockCodes;
    Date expirationDate;
    String accountNum;
    String cardArt;
    
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getPan() {
        return pan;
    }
    public void setPan(String pan) {
        this.pan = pan;
    }
    public String getIssuerId() {
        return issuerId;
    }
    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }
    public String getCustomer() {
        return customer;
    }
    public void setCustomer(String customerId) {
        this.customer = customerId;
    }
    public String getProduct() {
        return product;
    }
    public void setProduct(String product) {
        this.product = product;
    }
    public String getCardStatusCode() {
        return cardStatusCode;
    }
    public void setCardStatusCode(String cardStatusCode) {
        this.cardStatusCode = cardStatusCode;
    }
    public Date getLastMovementDate() {
        return lastMovementDate;
    }
    public void setLastMovementDate(Date lastMovementDate) {
        this.lastMovementDate = lastMovementDate;
    }
    public List<String> getBlockCodes() {
        return blockCodes;
    }
    public void setBlockCodes(List<String> blockCodes) {
        this.blockCodes = blockCodes;
    }
    public Date getExpirationDate() {
        return expirationDate;
    }
    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }
    public String getAccountNum() {
        return accountNum;
    }
    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }
    public String getCardArt() {
        return cardArt;
    }
    public void setCardArt(String cardArt) {
        this.cardArt = cardArt;
    }
    
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CardCms [id=");
        builder.append(id);
        builder.append(", pan=");
        builder.append(pan);
        builder.append(", issuerId=");
        builder.append(issuerId);
        builder.append(", customerId=");
        builder.append(customer);
        builder.append(", product=");
        builder.append(product);
        builder.append(", cardStatusCode=");
        builder.append(cardStatusCode);
        builder.append(", lastMovementDate=");
        builder.append(lastMovementDate);
        builder.append(", blockCodes=");
        builder.append(blockCodes);
        builder.append(", expirationDate=");
        builder.append(expirationDate);
        builder.append(", accountNum=");
        builder.append(accountNum);
        builder.append(", cardArt=");
        builder.append(cardArt);
        builder.append("]");
        return builder.toString();
    }
    
    
    

}
