package com.isban.tokenmanager.dto;

import java.util.List;

public class GetProductCardArtsResponse extends ResponseBase {
    
    private List<ProductCardArtDto> issuerProductCardArts;

    public GetProductCardArtsResponse() {}

    public GetProductCardArtsResponse(String code, String description) {
        super(code, description);
    }

    public List<ProductCardArtDto> getIssuerProductCardArts() {
        return issuerProductCardArts;
    }

    public void setIssuerProductCardArts(List<ProductCardArtDto> issuerProductCardArts) {
        this.issuerProductCardArts = issuerProductCardArts;
    }

    @Override
    public String toString() {
        return "GetIssuerProductCardArtsResponse [issuerProducts=" + issuerProductCardArts + "]";
    }
}
