package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.isban.tokenmanager.dto.ResponseBase;

import io.swagger.annotations.ApiModelProperty;

public class CardlessCommonResponse extends ResponseBase {
    
    @JsonIgnore
    @ApiModelProperty(value = "Unique identifier for the response.", required = true)
    @NotNull
    @Size(max = 64)
    private String responseId;
    
    
    public CardlessCommonResponse(String code, String description) {
        super(code, description);
    }
    public CardlessCommonResponse() {
        super();
    }
    public String getResponseId() {
        return responseId;
    }
    public void setResponseId(String responseId) {
        this.responseId = responseId;
    }

    
    @JsonProperty(value = "responseCode")
    @ApiModelProperty(value = "Error code for the reason the operation failed.", required = false)
    @Size(max = 32)
    @Override
    public String getCode() {
        return super.getCode();
    }
    
//    @JsonIgnore
    @ApiModelProperty(value = "Error description of the reason the operation failed.", required = false)
    @JsonProperty(value = "errorDescription")
    @Size(max = 256)
    @Override
    public String getDescription() {
        return super.getDescription();
    }
    
    @Override
    public void setCode(String c) {
        super.setCode(c);
    }
    
    @Override
    public void setDescription(String d) {
        super.setDescription(d);
    }
}

