package com.isban.tokenmanager.stmcrypto.dto;

public class VerifyMacOutput {

    /*
     * Properties
     */
	private Integer errorCode = 0;
    private String errorDescription = "No error";
	private String iv;
	
	/*
	 * Getters and setters
	 */
	public Integer getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(Integer value) {
		this.errorCode = value;
	}
    public String getErrorDescription() {
        return errorDescription;
    }
    public void setErrorDescription(String value) {
        this.errorDescription = value;
    }	
	public String getIv() {
	    return iv;
	}
	public void setIv(String value) {
	    this.iv = value;
	}
}
