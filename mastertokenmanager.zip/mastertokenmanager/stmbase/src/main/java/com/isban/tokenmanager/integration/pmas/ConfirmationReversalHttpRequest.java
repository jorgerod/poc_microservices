package com.isban.tokenmanager.integration.pmas;

public class ConfirmationReversalHttpRequest extends ConfirmationHttpRequest{
    
    private String reasonCode;
    private String confirmationTime;
    
    public String getReasonCode() {
        return reasonCode;
    }
    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }
    public String getConfirmationTime() {
        return confirmationTime;
    }
    public void setConfirmationTime(String confirmationTime) {
        this.confirmationTime = confirmationTime;
    }
    
    

}
