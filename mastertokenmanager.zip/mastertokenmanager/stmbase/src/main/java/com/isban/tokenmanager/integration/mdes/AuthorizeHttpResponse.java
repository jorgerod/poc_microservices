package com.isban.tokenmanager.integration.mdes;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.isban.tokenmanager.dto.mdes.ActivationMethodDto;
import com.isban.tokenmanager.dto.mdes.enm.MDESServiceEnum;
import com.isban.tokenmanager.dto.mdes.enm.DecisionMdesEnum;

public class AuthorizeHttpResponse extends MdesApiCommonResponse {

    @NotNull
    private List<MDESServiceEnum> services = null;
    
    @NotNull
    @Size(max = 64)
    private DecisionMdesEnum decision = null; 
    
    @NotNull
    private List<ActivationMethodDto> activationMethods = new ArrayList<>();
    
   
    @Size(max = 3)
    @Min(0)
    private String panSequenceNumber = null;

    @Size(max = 10)
    private String issuerProductConfigId = null;

    public List<MDESServiceEnum> getServices() {
        return services;
    }

    public void setServices(List<MDESServiceEnum> services) {
        this.services = services;
    }

    public DecisionMdesEnum getDecision() {
        return decision;
    }

    public void setDecision(DecisionMdesEnum decision) {
        this.decision = decision;
    }

    public List<ActivationMethodDto> getActivationMethods() {
        return activationMethods;
    }

    public void setActivationMethods(List<ActivationMethodDto> activationMethods) {
        this.activationMethods = activationMethods;
    }

    public String getPanSequenceNumber() {
        return panSequenceNumber;
    }

    public void setPanSequenceNumber(String panSequenceNumber) {
        this.panSequenceNumber = panSequenceNumber;
    }

    public String getIssuerProductConfigId() {
        return issuerProductConfigId;
    }

    public void setIssuerProductConfigId(String issuerProductConfigId) {
        this.issuerProductConfigId = issuerProductConfigId;
    }
}
