package com.isban.tokenmanager.model.enm;

public enum SftpProcessEnum {
    /* All sftp process*/
    REMAP("0", "REMAP", ProcessName.REMAP),
    CANCEL_MASSIVE("1", "CANCEL MASSIVE", ProcessName.CANCEL_MASSIVE),
    ISSUER_BLOCK("3", "ISSUER_BLOCK", ProcessName.ISSUER_BLOCK),
    ISSUER_SIT_CARD("4", "ISSUER_SIT_CARD", ProcessName.ISSUER_SIT_CARD),
    ISSUER_PRODUCT("5", "ISSUER_PRODUCT", ProcessName.ISSUER_PRODUCT),
    ISSUER_BIN("6", "ISSUER_BIN", ProcessName.ISSUER_BIN),
    INCOMING("7", "INCOMING", ProcessName.INCOMING),
    OUTBOUND("8", "OUTBOUND", ProcessName.OUTBOUND);

    private String code;
    private String description;
    private String processNameInFile;

    SftpProcessEnum(String code, String description, String processNameInFile) {
        this.code = code;
        this.description = description;
        this.processNameInFile = processNameInFile;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProcessNameInFile() {
        return processNameInFile;
    }

    public void setProcessNameInFile(String processNameInFile) {
        this.processNameInFile = processNameInFile;
    }

    public class ProcessName {
        public static final String REMAP = "REM";
        public static final String CANCEL_MASSIVE = "CAN";
        public static final String ISSUER_BLOCK = "BLO";
        public static final String ISSUER_SIT_CARD = "SIT";
        public static final String ISSUER_PRODUCT = "PRO";
        public static final String ISSUER_BIN = "BIN";
        public static final String INCOMING = "INC";
        public static final String OUTBOUND = "OUT";
    }
}
