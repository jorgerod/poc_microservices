package com.isban.tokenmanager.dto.mdes.enm;

public enum SuspendedByMdesEnum {
    ISSUER, 
    PAYMENT_APP_PROVIDER, 
    MOBILE_PIN_LOCKED, 
    CARDHOLDER;
}
