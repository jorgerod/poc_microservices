package com.isban.tokenmanager.dto.enm;

public enum ItemSourceEnum {
    
    CARD_ON_FILE("01"),
    CARD_ADDED_MANUALLY("02"),
    CARD_ADDED_VIA_APPLICATION("03");
    
    private String code;
    
    ItemSourceEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
