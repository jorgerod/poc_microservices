package com.isban.tokenmanager.dto;

import com.isban.tokenmanager.dto.card.ItemDitemDataDto;

public class NotificationRemapRequest extends NotificationCommonDataRequest {

    private ItemDitemDataDto oldCard;
    private ItemDitemDataDto newCard;

    public NotificationRemapRequest() {
    }

    public ItemDitemDataDto getOldCard() {
        return oldCard;
    }

    public void setOldCard(ItemDitemDataDto oldCard) {
        this.oldCard = oldCard;
    }

    public ItemDitemDataDto getNewCard() {
        return newCard;
    }

    public void setNewCard(ItemDitemDataDto newCard) {
        this.newCard = newCard;
    }

}
