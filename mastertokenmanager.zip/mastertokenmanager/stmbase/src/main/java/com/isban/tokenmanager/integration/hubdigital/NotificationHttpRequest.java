package com.isban.tokenmanager.integration.hubdigital;

public class NotificationHttpRequest extends HubdigitalCommonRequest {

}
