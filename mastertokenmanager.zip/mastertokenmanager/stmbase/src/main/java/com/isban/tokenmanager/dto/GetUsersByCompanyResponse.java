package com.isban.tokenmanager.dto;

import java.util.List;

public class GetUsersByCompanyResponse extends ResponseBase {

    private List<UserDto> users;

    public GetUsersByCompanyResponse(String code, String description) {
        super(code, description);
    }

    public GetUsersByCompanyResponse() {
    }

    public List<UserDto> getUsers() {
        return users;
    }

    public void setUsers(List<UserDto> users) {
        this.users = users;
    }
}
