package com.isban.tokenmanager.dto.cardless;

import java.util.Date;

import com.isban.tokenmanager.dto.LifeTimeDto;

public class DailyConciliationDto extends LifeTimeDto {
    
    // HEAD TODO revisar si sobra
    String source="TK"; // TODO
    String recordType;
    String communicationData; // TODO ¿?

    // SECTION 1
    String receptionDate;
    String fileSequence;
    String entityCode;
    String entitySupport;
    String franchiseType;
    String tapeType;
    
    // SECTION 2
    String tokenStateId;
    Date requestDate;
    String requestId; // identificador unico en sTM de la operacion
    String customerId;
    String issuerId;
    String item;
    String amount;
    String currency;
    String operationDate;
    String tokenReferenceId;  // TODO ¿?
    String responseCode;
    String withdrawalAuthCode;
    String retentionId;
    String terminalId;
    String commerceId;
    String commerceName;
    String commerceAddress;
    String commerceCity;
    String commerceState;
    String commerceCountry;
    String commercePostalCode;
    String adquirerId;
    String forwardingID;
    
    // only for annulation
    String reversalWithdrawalReasonCode;
    Date withdrawalOpTime;
    String deviceCompanyCode;
    String deviceContractCenterCode;
    String deviceContractProductCode;
    String deviceNumberContract;
    
    // FOOT // TODO revisar si sobra
    String numberOfOperations;
    String totalOperationAmount;
    String numberOfRecords;
    
    
    
    public String getOperationDate() {
        return operationDate;
    }
    public void setOperationDate(String operationDate) {
        this.operationDate = operationDate;
    }
    public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }
    public String getRecordType() {
        return recordType;
    }
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }
    public String getCommunicationData() {
        return communicationData;
    }
    public void setCommunicationData(String communicationData) {
        this.communicationData = communicationData;
    }
    public String getReceptionDate() {
        return receptionDate;
    }
    public void setReceptionDate(String receptionDate) {
        this.receptionDate = receptionDate;
    }
    public String getFileSequence() {
        return fileSequence;
    }
    public void setFileSequence(String fileSequence) {
        this.fileSequence = fileSequence;
    }
    public String getEntityCode() {
        return entityCode;
    }
    public void setEntityCode(String entityCode) {
        this.entityCode = entityCode;
    }
    public String getEntitySupport() {
        return entitySupport;
    }
    public void setEntitySupport(String entitySupport) {
        this.entitySupport = entitySupport;
    }
    public String getFranchiseType() {
        return franchiseType;
    }
    public void setFranchiseType(String franchiseType) {
        this.franchiseType = franchiseType;
    }
    public String getTapeType() {
        return tapeType;
    }
    public void setTapeType(String tapeType) {
        this.tapeType = tapeType;
    }
    public String getTokenStateId() {
        return tokenStateId;
    }
    public void setTokenStateId(String operationType) {
        this.tokenStateId = operationType;
    }
    public Date getRequestDate() {
        return requestDate;
    }
    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }
    public String getRequestId() {
        return requestId;
    }
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
    public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    public String getIssuerId() {
        return issuerId;
    }
    public void setIssuerId(String issuer) {
        this.issuerId = issuer;
    }
    public String getItem() {
        return item;
    }
    public void setItem(String item) {
        this.item = item;
    }
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public String getTokenReferenceId() {
        return tokenReferenceId;
    }
    public void setTokenReferenceId(String correlationId) {
        this.tokenReferenceId = correlationId;
    }
    public String getResponseCode() {
        return responseCode;
    }
    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }
    public String getWithdrawalAuthCode() {
        return withdrawalAuthCode;
    }
    public void setWithdrawalAuthCode(String withdrawalAuthCode) {
        this.withdrawalAuthCode = withdrawalAuthCode;
    }
    public String getRetentionId() {
        return retentionId;
    }
    public void setRetentionId(String retentionId) {
        this.retentionId = retentionId;
    }
    public String getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
    public String getCommerceId() {
        return commerceId;
    }
    public void setCommerceId(String commerceId) {
        this.commerceId = commerceId;
    }
    public String getCommerceAddress() {
        return commerceAddress;
    }
    public void setCommerceAddress(String commerceAddress) {
        this.commerceAddress = commerceAddress;
    }
    public String getCommerceCity() {
        return commerceCity;
    }
    public void setCommerceCity(String commerceCity) {
        this.commerceCity = commerceCity;
    }
    public String getCommerceState() {
        return commerceState;
    }
    public void setCommerceState(String commerceState) {
        this.commerceState = commerceState;
    }
    public String getCommerceCountry() {
        return commerceCountry;
    }
    public void setCommerceCountry(String commerceCountry) {
        this.commerceCountry = commerceCountry;
    }
    public String getCommercePostalCode() {
        return commercePostalCode;
    }
    public void setCommercePostalCode(String commercePostalCode) {
        this.commercePostalCode = commercePostalCode;
    }
    public String getAdquirerId() {
        return adquirerId;
    }
    public void setAdquirerId(String adquirerId) {
        this.adquirerId = adquirerId;
    }
    public String getForwardingID() {
        return forwardingID;
    }
    public void setForwardingID(String forwardingID) {
        this.forwardingID = forwardingID;
    }
    public String getReversalWithdrawalReasonCode() {
        return reversalWithdrawalReasonCode;
    }
    public void setReversalWithdrawalReasonCode(String reversalWithdrawalReasonCode) {
        this.reversalWithdrawalReasonCode = reversalWithdrawalReasonCode;
    }
    public Date getWithdrawalOpTime() {
        return withdrawalOpTime;
    }
    public void setWithdrawalOpTime(Date cancellationDateAdquirerPoint) {
        this.withdrawalOpTime = cancellationDateAdquirerPoint;
    }
    public String getDeviceCompanyCode() {
        return deviceCompanyCode;
    }
    public void setDeviceCompanyCode(String deviceCompanyCode) {
        this.deviceCompanyCode = deviceCompanyCode;
    }
    public String getDeviceContractCenterCode() {
        return deviceContractCenterCode;
    }
    public void setDeviceContractCenterCode(String deviceContractCenterCode) {
        this.deviceContractCenterCode = deviceContractCenterCode;
    }
    public String getDeviceContractProductCode() {
        return deviceContractProductCode;
    }
    public void setDeviceContractProductCode(String deviceContractProductCode) {
        this.deviceContractProductCode = deviceContractProductCode;
    }
    public String getDeviceNumberContract() {
        return deviceNumberContract;
    }
    public void setDeviceNumberContract(String deviceNumberContract) {
        this.deviceNumberContract = deviceNumberContract;
    }
    public String getNumberOfOperations() {
        return numberOfOperations;
    }
    public void setNumberOfOperations(String numberOfOperations) {
        this.numberOfOperations = numberOfOperations;
    }
    public String getTotalOperationAmount() {
        return totalOperationAmount;
    }
    public void setTotalOperationAmount(String totalOperationAmount) {
        this.totalOperationAmount = totalOperationAmount;
    }
    public String getNumberOfRecords() {
        return numberOfRecords;
    }
    public void setNumberOfRecords(String numberOfRecords) {
        this.numberOfRecords = numberOfRecords;
    }
    public String getCommerceName() {
        return commerceName;
    }
    public void setCommerceName(String commerceName) {
        this.commerceName = commerceName;
    }
    
    
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DailyConciliationDto [source=");
        builder.append(source);
        builder.append(", recordType=");
        builder.append(recordType);
        builder.append(", communicationData=");
        builder.append(communicationData);
        builder.append(", receptionDate=");
        builder.append(receptionDate);
        builder.append(", fileSequence=");
        builder.append(fileSequence);
        builder.append(", entityCode=");
        builder.append(entityCode);
        builder.append(", entitySupport=");
        builder.append(entitySupport);
        builder.append(", franchiseType=");
        builder.append(franchiseType);
        builder.append(", tapeType=");
        builder.append(tapeType);
        builder.append(", tokenStateId=");
        builder.append(tokenStateId);
        builder.append(", requestDate=");
        builder.append(requestDate);
        builder.append(", requestId=");
        builder.append(requestId);
        builder.append(", customerId=");
        builder.append(customerId);
        builder.append(", issuer=");
        builder.append(issuerId);
        builder.append(", item=");
        builder.append(item);
        builder.append(", amount=");
        builder.append(amount);
        builder.append(", currency=");
        builder.append(currency);
        builder.append(", operationDate=");
        builder.append(operationDate);
        builder.append(", tokenReferenceId=");
        builder.append(tokenReferenceId);
        builder.append(", responseCode=");
        builder.append(responseCode);
        builder.append(", withdrawalAuthCode=");
        builder.append(withdrawalAuthCode);
        builder.append(", retentionId=");
        builder.append(retentionId);
        builder.append(", terminalId=");
        builder.append(terminalId);
        builder.append(", commerceId=");
        builder.append(commerceId);
        builder.append(", commerceName=");
        builder.append(commerceName);
        builder.append(", commerceAddress=");
        builder.append(commerceAddress);
        builder.append(", commerceCity=");
        builder.append(commerceCity);
        builder.append(", commerceState=");
        builder.append(commerceState);
        builder.append(", commerceCountry=");
        builder.append(commerceCountry);
        builder.append(", commercePostalCode=");
        builder.append(commercePostalCode);
        builder.append(", adquirerId=");
        builder.append(adquirerId);
        builder.append(", forwardingID=");
        builder.append(forwardingID);
        builder.append(", reversalWithdrawalReasonCode=");
        builder.append(reversalWithdrawalReasonCode);
        builder.append(", cancellationDateAdquirerPoint=");
        builder.append(withdrawalOpTime);
        builder.append(", deviceCompanyCode=");
        builder.append(deviceCompanyCode);
        builder.append(", deviceContractCenterCode=");
        builder.append(deviceContractCenterCode);
        builder.append(", deviceContractProductCode=");
        builder.append(deviceContractProductCode);
        builder.append(", deviceNumberContract=");
        builder.append(deviceNumberContract);
        builder.append(", numberOfOperations=");
        builder.append(numberOfOperations);
        builder.append(", totalOperationAmount=");
        builder.append(totalOperationAmount);
        builder.append(", numberOfRecords=");
        builder.append(numberOfRecords);
        builder.append("]");
        return builder.toString();
    }
    
    

}
