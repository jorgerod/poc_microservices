package com.isban.tokenmanager.dto;


public class ActivationCodeResponse extends ResponseBase {

    public ActivationCodeResponse() {
    }

    public ActivationCodeResponse(String code, String description) {
        super(code, description);
    }
}
