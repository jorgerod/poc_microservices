package com.isban.tokenmanager.service.metrics;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.springframework.boot.actuate.endpoint.PublicMetrics;
import org.springframework.boot.actuate.metrics.Metric;

import com.isban.tokenmanager.dto.metrics.GraphMetric;
import com.isban.tokenmanager.dto.metrics.GraphMetrics;
import com.isban.tokenmanager.dto.metrics.MetricExtended;

public class GraphMetricsServiceImpl implements GraphMetricsService {
    private static final Logger logger = Logger.getLogger(GraphMetricsServiceImpl.class);
    
    private GraphMetrics graphMetrics = null;
    
    @Override
    public GraphMetrics addMetrics(PublicMetrics publicMetrics){
        getGraphMetrics();//ensure init graphMetrics
        
        if( getEnabled() ){
            //create util data
            Set<String> servicenames = getServiceNames( graphMetrics, publicMetrics );
            Map<String,Set<Metric<?>>> publicMetricsMap = createPublicMetricsMap( publicMetrics, servicenames );

            //add, actualize graphMetrics data
            graphMetrics = addNewServicenames( graphMetrics, servicenames );
            graphMetrics = extendServicenamesMetrics( graphMetrics, publicMetricsMap, servicenames );
        }
        
        return graphMetrics;
    }
    
    @Override
    public boolean getEnabled() {
        return true;
    }
    
    @Override
    public GraphMetrics getGraphMetrics() {
        if(graphMetrics!=null){ return graphMetrics; }
        graphMetrics = createGraphMetrics();
        return graphMetrics;
    }
    
    @Override
    public String getGraphMetricsNodebase(){
        return "http://localhost:8080";
    }
    
    @Override
    public String getGraphMetricsPath(){
        return "/graphmetrics";
    }
    
    @Override
    public String getGraphMetricsCron(){
        return "0 */30 * * * *";
        // avaiable options:
        //    */5 * * * * *   (very higth latency)
        //    */6 * * * * *
        //    */10 * * * * *
        //    */15 * * * * *
        //    */20 * * * * *
        //    */30 * * * * *
        //    0 */1 * * * *
        //    0 */5 * * * *
        //    0 */6 * * * *
        //    0 */10 * * * *
        //    0 */15 * * * *
        //    0 */20 * * * *
        //    0 */30 * * * *   (default low latency)
    }

    @Override
    public int getGraphMetricsSize(){
        return 12;
    }

    private GraphMetrics createGraphMetrics(){ 
        GraphMetrics ret = new GraphMetrics();
        ret.nodebase = getGraphMetricsNodebase();
        ret.path = getGraphMetricsPath();
        ret.cron = getGraphMetricsCron();
        ret.size = getGraphMetricsSize();
        ret.starttime = (new Date()).getTime();
        
        return ret;
    }
    
    private GraphMetric createGraphMetric(String servicename){
        GraphMetric ret = new GraphMetric();
        ret.servicename = servicename;
        ret.starttime = (new Date()).getTime();
        return ret;
    }
    
    private Map<String, Set<Metric<?>>> createPublicMetricsMap(PublicMetrics publicMetrics, Set<String> servicenames) {
        Map<String, Set<Metric<?>>> ret = new HashMap<String, Set<Metric<?>>>();
        Set<Metric<?>> serviceMetrics;
        Collection<Metric<?>> publicMetricsMetrics = publicMetrics.metrics();
        String metricName, tmpServicename;
        for( Metric<?> metric : publicMetricsMetrics ){
            metricName = metric.getName();
            tmpServicename = createServiceNameByUnknowntypeKey(metricName);
            if(tmpServicename != null && servicenames.contains(tmpServicename)) {
                serviceMetrics = ret.get(tmpServicename);
                if(serviceMetrics == null){
                    serviceMetrics = new HashSet<Metric<?>>();
                    ret.put(tmpServicename, serviceMetrics);
                }
                serviceMetrics.add(metric);
                
            } else if (!metricName.contains("Hystrix")) {
                logger.error("unstable metrics values, service=" + tmpServicename );
            }
        }
        
        return ret;
    }
    
    private GraphMetrics extendServicenamesMetrics( 
            GraphMetrics gMetrics, 
            Map<String, Set<Metric<?>>> publicMetricsMap, 
            Set<String> servicenames ) {
        GraphMetric graphMetric;
        MetricExtendedChanges metricExtendedChanges;
        for( String servicename : servicenames ){
            graphMetric = gMetrics.metricstable.get(servicename);
            if( graphMetric != null ){
                metricExtendedChanges = new MetricExtendedChanges();
                if( graphMetric.graph.isEmpty() ){
                    metricExtendedChanges.lastMetricToChange = createMetricExtended( publicMetricsMap, servicename );
                    metricExtendedChanges.metricToAdd = metricExtendedChanges.lastMetricToChange;
                    
                } else {
                    metricExtendedChanges = createMetricExtended( graphMetric, publicMetricsMap, servicename );
                }
                
                addNewMetricExtended( gMetrics, graphMetric, metricExtendedChanges );
            }
        }
        
        return gMetrics;
    }
    
    private MetricExtended createMetricExtended( 
            Map<String, Set<Metric<?>>> publicMetricsMap, String servicename ) {
        MetricExtended ret = new MetricExtended();
        ret.time = (new Date()).getTime();
        
        Set<Metric<?>> serviceMetrics = publicMetricsMap.get(servicename);
        String metricKey;
        for( Metric<?> metric : serviceMetrics ){
            metricKey = metric.getName();
            if( isMetricGaugeKey(metricKey) ){
                ret.gauge = (Double)metric.getValue();
                
            } else if( isMetricCounterstatusnumKey(metricKey) ){
                if( isMetricCounterstatus200Key(metricKey) ){
                    ret.okcount = (Long)metric.getValue();
                    
                } else {
                    ret.kocount = ret.kocount + (Long)metric.getValue();
                }
            }
        }
        
        return ret;
    }
    
    private MetricExtended createMetricExtended( MetricExtended newAbsoluteMet, MetricExtended oldAbsoluteMet ){
        MetricExtended ret = new MetricExtended();
        ret.time = newAbsoluteMet.time;
        ret.okcount = newAbsoluteMet.okcount - oldAbsoluteMet.okcount;
        ret.kocount = newAbsoluteMet.kocount - oldAbsoluteMet.kocount;
        ret.gauge = newAbsoluteMet.gauge;
        return ret;
    }
    
    private MetricExtendedChanges createMetricExtended( 
            GraphMetric graphMetric, 
            Map<String, Set<Metric<?>>> publicMetricsMap, String servicename ) {
        MetricExtendedChanges ret = new MetricExtendedChanges();
        MetricExtended newAbsoluteMet = createMetricExtended( publicMetricsMap, servicename );
        ret.metricToAdd = createMetricExtended( newAbsoluteMet, graphMetric.lastmetric );
        ret.lastMetricToChange = newAbsoluteMet;
        
        return ret;
    }
    
    private void addNewMetricExtended( 
            GraphMetrics gMetrics, 
            GraphMetric graphMetric,
            MetricExtendedChanges metricExtendedChanges ) {
        //update
        graphMetric.lastmetric = metricExtendedChanges.lastMetricToChange;
        //add
        graphMetric.graph.add(metricExtendedChanges.metricToAdd);
        
        //ensure limit size
        if( gMetrics.size > 0 ){
            if( graphMetric.graph.size() > gMetrics.size ){
                graphMetric.graph.remove(0);
            }
        }
    }
    
    class MetricExtendedChanges{
        public MetricExtended lastMetricToChange;
        public MetricExtended metricToAdd;
    }
    
    private GraphMetrics addNewServicenames( 
            GraphMetrics gMetrics, 
            Set<String> servicenames ) {
        for( String servicename : servicenames ){
            if( !gMetrics.metricstable.containsKey(servicename) ){
                gMetrics.metricstable.put( servicename, createGraphMetric( servicename ) );
            }
        }
        
        return gMetrics;
    }
    
    private Set<String> getServiceNames(GraphMetrics gMetrics, PublicMetrics publicMetrics) {
        Set<String> ret = new TreeSet<String>();
        ret.addAll(getServiceNames(gMetrics));
        ret.addAll(getServiceNames(publicMetrics));
        return ret;
    }
    
    private Set<String> getServiceNames(GraphMetrics gMetrics) {
        Set<String> ret = new TreeSet<String>( gMetrics.metricstable.keySet() );
        return ret;
    }
    
    private Set<String> getServiceNames(PublicMetrics publicMetrics) {
        Set<String> ret = new TreeSet<String>();
        
        //gets/adds via "gauge.response.*" or "counter.status.nnn.*" values
        for( Metric<?> metric : publicMetrics.metrics() ){
            String metricName = metric.getName();
            String serviceName = createServiceNameByUnknowntypeKey( metricName );
            if( serviceName != null ){
                ret.add( serviceName );
            }
        }
        
        return ret;
    }
    
    private Pattern gaugeKeyPattern4replace = Pattern.compile( "^gauge\\.response\\." );
    private String createServiceNameByGaugeKey( String gaugeMetricsKey ){
        String ret = gaugeKeyPattern4replace.matcher(gaugeMetricsKey).replaceAll("");
        return ret;
    }
    private Pattern gaugeKeyPattern4matches = Pattern.compile( "^gauge\\.response\\..+" );
    private boolean isMetricGaugeKey( String metricsKey ){
        Matcher matcher = gaugeKeyPattern4matches.matcher(metricsKey);
        boolean ret = matcher.matches();
        return ret;
    }
    
    private Pattern counterstatusnumKeyPattern4replace = Pattern.compile( "^counter\\.status\\.\\d+\\." );
    private String createServiceNameByCounterstatusnumKey( String counterstatusnumMetricsKey ){
        String ret = counterstatusnumKeyPattern4replace.matcher(counterstatusnumMetricsKey).replaceAll("");
        return ret;
    }
    private Pattern counterstatusnumKeyPattern4matches = Pattern.compile( "^counter\\.status\\.\\d+\\..+" );
    private boolean isMetricCounterstatusnumKey( String metricsKey ){
        Matcher matcher = counterstatusnumKeyPattern4matches.matcher(metricsKey);
        boolean ret = matcher.matches();
        return ret;
    }
    private Pattern counterstatus200KeyPattern4matches = Pattern.compile( "^counter\\.status\\.200\\..+" );
    private boolean isMetricCounterstatus200Key( String metricsKey ){
        Matcher matcher = counterstatus200KeyPattern4matches.matcher(metricsKey);
        boolean ret = matcher.matches();
        return ret;
    }
    
    private String createServiceNameByUnknowntypeKey( String metricsKey ){
        String tmpVal, ret = null;
        
        tmpVal = createServiceNameByGaugeKey(metricsKey); //1st attempt. is gauge value? 
        if( !tmpVal.equals(metricsKey) ){
            ret = tmpVal;
            
        } else {
            tmpVal = createServiceNameByCounterstatusnumKey(metricsKey); //2nd attempt. is counter.status.nnn value?  
            if( !tmpVal.equals(metricsKey) ){
                ret = tmpVal;
            }
        }
        
        return ret;
    }
}
