/**
 * 
 */
package com.isban.tokenmanager.integration.dto;

/**
 * @author josejavierblecuadepedro1
 *
 */
public class GetFlowVeptsResponse {

}
