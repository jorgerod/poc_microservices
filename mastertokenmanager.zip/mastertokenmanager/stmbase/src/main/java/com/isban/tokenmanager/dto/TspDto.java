package com.isban.tokenmanager.dto;


public class TspDto extends LifeTimeDto {

    private String id;
    private String shortDescription = null;
    private String description = null;
    private Integer expiration = null;
    private Boolean ownerTsp = null;
    private Boolean ownerStmTsp = null;
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getShortDescription() {
        return shortDescription;
    }
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public Integer getExpiration() {
        return expiration;
    }
    public void setExpiration(Integer expiration) {
        this.expiration = expiration;
    }
    public Boolean getOwnerTsp() {
        return ownerTsp;
    }
    public void setOwnerTsp(Boolean sanTsp) {
        this.ownerTsp = sanTsp;
    }
    public Boolean getOwnerStmTsp() {
        return ownerStmTsp;
    }
    public void setOwnerStmTsp(Boolean ownerStmTsp) {
        this.ownerStmTsp = ownerStmTsp;
    }

}
