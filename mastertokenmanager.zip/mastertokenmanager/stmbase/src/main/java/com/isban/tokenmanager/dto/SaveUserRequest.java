package com.isban.tokenmanager.dto;

import java.util.List;

public class SaveUserRequest extends UserDto {

    private String userOperatorId = null;
    private String issuerOperatorId = null;

   
    public SaveUserRequest() {
        super(null, null, null, null);
    }

    public SaveUserRequest(String issuerId, String tokenTypeId, String userId,
            List<IssuerTokenTypeUserDto> issuerUsersList) {
        super(issuerId, tokenTypeId, userId, issuerUsersList);
    }

    public SaveUserRequest(String issuerId, String userId, String tokenTypeId,
            List<IssuerTokenTypeUserDto> issuerUsersList, String userOperatorId, String issuerOperatorId) {
        super(issuerId, userId, tokenTypeId, issuerUsersList);
        this.userOperatorId = userOperatorId;
        this.issuerOperatorId = issuerOperatorId;
    }

    public String getUserOperatorId() {
        return userOperatorId;
    }

    public void setUserOperatorId(String userOperatorId) {
        this.userOperatorId = userOperatorId;
    }

    public String getIssuerOperatorId() {
        return issuerOperatorId;
    }

    public void setIssuerOperatorId(String issuerOperatorId) {
        this.issuerOperatorId = issuerOperatorId;
    }

}
