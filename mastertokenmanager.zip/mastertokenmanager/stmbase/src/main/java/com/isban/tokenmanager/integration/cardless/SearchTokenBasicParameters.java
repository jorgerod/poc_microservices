package com.isban.tokenmanager.integration.cardless;

public class SearchTokenBasicParameters {
    
    String nrbe;
    String tokenId;
    
    public String getNrbe() {
        return nrbe;
    }
    public void setNrbe(String nrbe) {
        this.nrbe = nrbe;
    }
    public String getTokenId() {
        return tokenId;
    }
    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }
    
    

}
