package com.isban.tokenmanager.integration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.isban.tokenmanager.dto.cardless.AccessTokenDto;
import com.isban.tokenmanager.exception.TokenManagerException;

public abstract class PostGateway<I, O> {
    
    
    

    protected String url;
    protected int connectTimeout;
    protected int readTimeout;
    protected HttpHeaders commonHeaders;

    private final Class<O> typeOutputClass;

    @Autowired
    private RestTemplate restTemplate;

    public PostGateway(Class<O> typeOutputParamClass) {
        this.typeOutputClass = typeOutputParamClass;
    }

    public abstract void configureParameters();
    
    
    public void configureSecurity(AccessTokenDto accessTokenDto){
        
    }

    public O executePost(I request) throws TokenManagerException {
        configureParameters();
        HttpMethod method = HttpMethod.POST;
        return execute(request, method);
    }
    
    public O executeDelete() throws TokenManagerException {
        configureParameters();
        HttpMethod method = HttpMethod.DELETE;
        return execute(null, method);
    }
    
    public O executeSecure(I body, HttpMethod method) throws TokenManagerException {
        O ret = null;
        try {

            configureParameters();
            RestTemplate restTemplate1 = new RestTemplate();
            NullHostNameVerifier   nhnv=new NullHostNameVerifier  ();
            final StmSimpleClientHttpRequestFactory factory = new StmSimpleClientHttpRequestFactory(nhnv);
            factory.setConnectTimeout(connectTimeout);
            factory.setReadTimeout(readTimeout);
            restTemplate1.setRequestFactory(factory);
            
            HttpHeaders headers = new HttpHeaders();
            headers.add("Accept", "application/json");
            
            HttpEntity<?> request = new HttpEntity<Object>(body, headers);
            ResponseEntity<O> httpResponse = restTemplate1.exchange(url, method, request, typeOutputClass);
            ret = httpResponse.getBody();
            
        } catch (Exception ex) {
            throw new TokenManagerException(TokenManagerException.CONNECT_EXCEPTION, ex.getMessage(), ex);
        }
        return ret;
    }
    
    public O executeSecure(I body, HttpMethod method, AccessTokenDto accessTokenDto) throws TokenManagerException {
        O ret = null;
        try {
            configureParameters();
            
            configureSecurity(accessTokenDto);

            RestTemplate restTemplate1 = new RestTemplate();
            
            NullHostNameVerifier   nhnv=new NullHostNameVerifier  ();
            final StmSimpleClientHttpRequestFactory factory = new StmSimpleClientHttpRequestFactory(nhnv);
            factory.setConnectTimeout(connectTimeout);
            factory.setReadTimeout(readTimeout);
            restTemplate1.setRequestFactory(factory);

            
            HttpEntity<?> request = new HttpEntity<Object>(body, commonHeaders);
            ResponseEntity<O> httpResponse = restTemplate1.exchange(url, method, request, typeOutputClass);
            ret = httpResponse.getBody();
            
        } catch (Exception ex) {
            throw new TokenManagerException(TokenManagerException.CONNECT_EXCEPTION, ex.getMessage(), ex);
        }
        return ret;
    }    
    

    private O execute(I body, HttpMethod method) throws TokenManagerException {
        O ret = null;
        
        try {
            if (restTemplate.getRequestFactory() instanceof SimpleClientHttpRequestFactory) {
                
                ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(readTimeout);
                ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(connectTimeout);
                
            } else {
                SimpleClientHttpRequestFactory s = new SimpleClientHttpRequestFactory();
                s.setReadTimeout(readTimeout);
                s.setConnectTimeout(connectTimeout);
                
                restTemplate.setRequestFactory(s);
            }
                
            HttpHeaders headers = new HttpHeaders();
            headers.add("Accept", "application/json");
            headers.add("Content-Type", "application/json");
            
            HttpEntity<Object> request = new HttpEntity<Object>(body, headers);
            
            
            ResponseEntity<O> httpResponse = restTemplate.exchange(url, method, request, typeOutputClass);

            ret = httpResponse.getBody();
        } catch (Exception ex) {
            throw new TokenManagerException(TokenManagerException.CONNECT_EXCEPTION, ex.getMessage(), ex);
        }
        return ret;
    }
    

    public  O executeGet(String extendedUri, String keysValues) throws TokenManagerException {
        
        configureParameters(); // TODO
        
        O ret = null;
        try {
            ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(readTimeout);
            ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(connectTimeout);
         
         url=url+"/1/";
         
         UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                 .queryParam("lang", "lang")
                 .queryParam("text_type", "text_type")
                 .queryParam("params", keysValues);
         
         ret = restTemplate.getForObject(builder.toUriString(), typeOutputClass);    
         
        } catch (Exception ex) {
            System.out.println();
            throw new TokenManagerException(TokenManagerException.CONNECT_EXCEPTION, ex.getMessage(), ex);
        }
        return ret;
    }    
    
    public  O executeGetTextMessage(String textId, String keysValues) throws TokenManagerException {
        
        configureParameters(); // TODO
        
        O ret = null;
        try {
            ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(readTimeout);
            ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(connectTimeout);
         
         url=url+"/"+textId+"/";
         
         UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                 .queryParam("lang", "lang")
                 .queryParam("text_type", "text_type")
                 .queryParam("params", keysValues);
         
         ret = restTemplate.getForObject(builder.toUriString(), typeOutputClass);    
         
        } catch (Exception ex) {
            System.out.println();
            throw new TokenManagerException(TokenManagerException.CONNECT_EXCEPTION, ex.getMessage(), ex);
        }
        return ret;
    }   
    
    public  O executeGetTextMessage(String textId) throws TokenManagerException {
        
        configureParameters(); // TODO
        
        O ret = null;
        try {
            ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(readTimeout);
            ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(connectTimeout);
         
         url=url+"/"+textId+"/";
         
         UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                 .queryParam("lang", "lang")
                 .queryParam("text_type", "text_type");

         
         ret = restTemplate.getForObject(builder.toUriString(), typeOutputClass);    
         
        } catch (Exception ex) {
            System.out.println();
            throw new TokenManagerException(TokenManagerException.CONNECT_EXCEPTION, ex.getMessage(), ex);
        }
        return ret;
    }
    
}
