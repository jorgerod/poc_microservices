package com.isban.tokenmanager.dto;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class TokenHistoryDto {

    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssZZZ")
    private Date date;
    private String stateId;
    private String stateDescription;
    private String tspStateDescription;
    private String tokenReferenceId;
    
    private String branchOffice;
    private String comments;
    private String userId;

    private String tokenStateId;
    private String tokenStateDescription;

    private String externalTransactionId;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getStateId() {
        return stateId;
    }

    public void setStateId(String stateId) {
        this.stateId = stateId;
    }

    public String getStateDescription() {
        return stateDescription;
    }

    public void setStateDescription(String stateDescription) {
        this.stateDescription = stateDescription;
    }

    public String getTokenReferenceId() {
        return tokenReferenceId;
    }

    public void setTokenReferenceId(String ticketExt) {
        this.tokenReferenceId = ticketExt;
    }

    public String getTspStateDescription() {
        return tspStateDescription;
    }

    public void setTspStateDescription(String tspStateDescription) {
        this.tspStateDescription = tspStateDescription;
    }

    public String getBranchOffice() {
        return branchOffice;
    }

    public void setBranchOffice(String branchOffice) {
        this.branchOffice = branchOffice;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
    

    public String getTokenStateId() {
        return tokenStateId;
    }

    public void setTokenStateId(String tokenStateId) {
        this.tokenStateId = tokenStateId;
    }

    public String getTokenStateDescription() {
        return tokenStateDescription;
    }

    public void setTokenStateDescription(String tokenStateDescription) {
        this.tokenStateDescription = tokenStateDescription;
    }

    public String getExternalTransactionId() {
        return externalTransactionId;
    }

    public void setExternalTransactionId(String externalTransactionId) {
        this.externalTransactionId = externalTransactionId;
    }
}
