package com.isban.tokenmanager.integration.dto;

import java.util.List;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.isban.tokenmanager.dto.ResponseBase;
import com.isban.tokenmanager.dto.TokenRequestorTokenStateDto;
import com.isban.tokenmanager.model.enm.ResponseStateEnum;

import io.swagger.annotations.ApiModelProperty;

public class TokenRequestorTokenStateHttpResponse extends ResponseBase {

    private List<TokenRequestorTokenStateDto> states;

    public TokenRequestorTokenStateHttpResponse() {
        super();
    }

    public TokenRequestorTokenStateHttpResponse(ResponseStateEnum state) {
        super(state);
    }

    @ApiModelProperty(value = "Data associated to returned tokens.", required = false)
    public List<TokenRequestorTokenStateDto> getStates() {
        return states;
    }

    public void setStates(List<TokenRequestorTokenStateDto> states) {
        this.states = states;
    }
    
    @JsonProperty(value = "codeResponse")
    @ApiModelProperty(value = "Response code indicating the result.", required = true)
    @Size(max = 4)
    @Override
    public String getCode() {
        return super.getCode();
    }

    @ApiModelProperty(value = "description.", required = false)
    @JsonProperty(value = "desResponse")
    @Size(max = 256)
    @Override
    public String getDescription() {
        return super.getDescription();
    }

    @Override
    public void setCode(String c) {
        super.setCode(c);
    }

    @Override
    public void setDescription(String d) {
        super.setDescription(d);
    }
}
