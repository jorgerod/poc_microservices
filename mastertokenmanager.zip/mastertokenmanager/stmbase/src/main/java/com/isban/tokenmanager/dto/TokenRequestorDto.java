package com.isban.tokenmanager.dto;

import java.util.List;

public class TokenRequestorDto extends LifeTimeDto {

    private String tokenRequestorId;
    private String issuerName;
    private String walletName;
    private String termsAndConditions;
    private Boolean allowActivationSelectionByClient;
    private Integer numDaysValidity; // numero de dias que la tarjeta tiene que
    // ser valido antes de expirar para ser
    // elegible
    private Integer numDaysUsage; // maximo numero de dias que la tarjeta tiene
    // que haber sido usada

    private Integer numMaxTokens;//Cantidad maxima permitida solicitar en un token.
    private Integer numMaxAmount;//Numero de tokens cuyo estado es pendiente, aprobado o activos
    private Integer numMaxActivationAttemps;

    private WalletDto wallet;

    private Boolean activeBinRule;
    private Boolean activeProductRule;
    private Boolean activeSitCardRule;
    private Boolean activeBlockRule;
    private Boolean activeValidityRule;
    private Boolean activeUsageRule;
    
    private Boolean activeMaxTokensRule;
    private Boolean activeMaxAmountRule;
    private Boolean activeMaxActivationAttempsRule;

    private List<TokenRequestorBlockDto> issuerWalletBlockList;
    private List<TokenRequestorSitCardDto> issuerWalletSitCardList;
    private List<TokenRequestorProductDto> issuerWalletProductList;
    private List<TokenRequestorBinDto> walletBinList;
    private List<TokenRequestorActivationMethodDto> issuerWalletActMethodList;

    private List<TokenRequestorBrandDto> walletBrandBinList;

    public TokenRequestorDto() {

    }

    public TokenRequestorDto(String issuerId, String tokenTypeId, String tokenRequestorId) {
        super();
        this.issuerId = issuerId;
        this.tokenRequestorId = tokenRequestorId;
        this.tokenTypeId = tokenTypeId;
    }

    public TokenRequestorDto(String issuerId, String tokenTypeId, String tokenRequestorId, String termsAndConditions,
            Boolean allowActivationSelectionByClient) {
        super();
        this.issuerId = issuerId;
        this.tokenRequestorId = tokenRequestorId;
        this.termsAndConditions = termsAndConditions;
        this.tokenTypeId = tokenTypeId;
        this.allowActivationSelectionByClient = allowActivationSelectionByClient;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getIssuerName() {
        return issuerName;
    }

    public void setIssuerName(String issuerName) {
        this.issuerName = issuerName;
    }

    public String getWalletName() {
        return walletName;
    }

    public void setWalletName(String walletName) {
        this.walletName = walletName;
    }

    public String getTermsAndConditions() {
        return termsAndConditions;
    }

    public void setTermsAndConditions(String termsAndConditions) {
        this.termsAndConditions = termsAndConditions;
    }

    public Boolean getAllowActivationSelectionByClient() {
        return allowActivationSelectionByClient;
    }

    public void setAllowActivationSelectionByClient(Boolean allowActivationSelectionByClient) {
        this.allowActivationSelectionByClient = allowActivationSelectionByClient;
    }

    public WalletDto getWallet() {
        return wallet;
    }

    public void setWallet(WalletDto wallet) {
        this.wallet = wallet;
    }

    public List<TokenRequestorBlockDto> getIssuerWalletBlockList() {
        return issuerWalletBlockList;
    }

    public void setIssuerWalletBlockList(List<TokenRequestorBlockDto> issuerWalletBlockList) {
        this.issuerWalletBlockList = issuerWalletBlockList;
    }

    public List<TokenRequestorSitCardDto> getIssuerWalletSitCardList() {
        return issuerWalletSitCardList;
    }

    public void setIssuerWalletSitCardList(List<TokenRequestorSitCardDto> issuerWalletSitCardList) {
        this.issuerWalletSitCardList = issuerWalletSitCardList;
    }

    public List<TokenRequestorProductDto> getIssuerWalletProductList() {
        return issuerWalletProductList;
    }

    public void setIssuerWalletProductList(List<TokenRequestorProductDto> issuerWalletProductList) {
        this.issuerWalletProductList = issuerWalletProductList;
    }

    public List<TokenRequestorBinDto> getWalletBinList() {
        return walletBinList;
    }

    public void setWalletBinList(List<TokenRequestorBinDto> walletBinList) {
        this.walletBinList = walletBinList;
    }

    public List<TokenRequestorActivationMethodDto> getIssuerWalletActMethodList() {
        return issuerWalletActMethodList;
    }

    public void setIssuerWalletActMethodList(List<TokenRequestorActivationMethodDto> issuerWalletActMethodList) {
        this.issuerWalletActMethodList = issuerWalletActMethodList;
    }

    public Integer getNumDaysValidity() {
        return numDaysValidity;
    }

    public void setNumDaysValidity(Integer numDaysValidity) {
        this.numDaysValidity = numDaysValidity;
    }

    public Integer getNumDaysUsage() {
        return numDaysUsage;
    }

    public void setNumDaysUsage(Integer numDaysUsage) {
        this.numDaysUsage = numDaysUsage;
    }

    public Boolean getActiveBinRule() {
        return activeBinRule;
    }

    public void setActiveBinRule(Boolean activeBinRule) {
        this.activeBinRule = activeBinRule;
    }

    public Boolean getActiveProductRule() {
        return activeProductRule;
    }

    public void setActiveProductRule(Boolean activeProductRule) {
        this.activeProductRule = activeProductRule;
    }

    public Boolean getActiveSitCardRule() {
        return activeSitCardRule;
    }

    public void setActiveSitCardRule(Boolean activeSitCardRule) {
        this.activeSitCardRule = activeSitCardRule;
    }

    public Boolean getActiveBlockRule() {
        return activeBlockRule;
    }

    public void setActiveBlockRule(Boolean activeBlockRule) {
        this.activeBlockRule = activeBlockRule;
    }

    public Boolean getActiveValidityRule() {
        return activeValidityRule;
    }

    public void setActiveValidityRule(Boolean activeValidityRule) {
        this.activeValidityRule = activeValidityRule;
    }

    public Boolean getActiveUsageRule() {
        return activeUsageRule;
    }

    public void setActiveUsageRule(Boolean activeUsageRule) {
        this.activeUsageRule = activeUsageRule;
    }

    public List<TokenRequestorBrandDto> getWalletBrandBinList() {
        return walletBrandBinList;
    }

    public void setWalletBrandBinList(List<TokenRequestorBrandDto> walletBrandBinList) {
        this.walletBrandBinList = walletBrandBinList;
    }

    public Integer getNumMaxTokens() {
        return numMaxTokens;
    }

    public void setNumMaxTokens(Integer numMaxTokens) {
        this.numMaxTokens = numMaxTokens;
    }

    public Integer getNumMaxAmount() {
        return numMaxAmount;
    }

    public void setNumMaxAmount(Integer numMaxAmount) {
        this.numMaxAmount = numMaxAmount;
    }

    public Integer getNumMaxActivationAttemps() {
        return numMaxActivationAttemps;
    }

    public void setNumMaxActivationAttemps(Integer numMaxActivationAttemps) {
        this.numMaxActivationAttemps = numMaxActivationAttemps;
    }

    public Boolean getActiveMaxTokensRule() {
        return activeMaxTokensRule;
    }

    public void setActiveMaxTokensRule(Boolean activeMaxTokensRule) {
        this.activeMaxTokensRule = activeMaxTokensRule;
    }

    public Boolean getActiveMaxAmountRule() {
        return activeMaxAmountRule;
    }

    public void setActiveMaxAmountRule(Boolean activeMaxAmountRule) {
        this.activeMaxAmountRule = activeMaxAmountRule;
    }

    public Boolean getActiveMaxActivationAttempsRule() {
        return activeMaxActivationAttempsRule;
    }

    public void setActiveMaxActivationAttempsRule(Boolean activeMaxActivationAttempsRule) {
        this.activeMaxActivationAttempsRule = activeMaxActivationAttempsRule;
    }

}
