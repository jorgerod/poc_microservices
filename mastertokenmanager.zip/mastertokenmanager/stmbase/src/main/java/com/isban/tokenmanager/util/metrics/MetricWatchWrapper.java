package com.isban.tokenmanager.util.metrics;

public interface MetricWatchWrapper<T> {
    public String selectStatus(T wrapped);
    public T wrap( T wrapped );
    //
    public String getOkStatus();
    public String getKoStatus();
    public String getEndSufixToAdd();
}
