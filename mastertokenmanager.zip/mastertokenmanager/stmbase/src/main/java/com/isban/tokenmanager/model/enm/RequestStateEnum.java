package com.isban.tokenmanager.model.enm;

public enum RequestStateEnum {
    REGISTRATION_PENDING("00"),
    ACTIVATED("01"),
    DELETED("02");

    private String code;

    RequestStateEnum(String val) {
        this.code = val;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
