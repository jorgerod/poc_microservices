package com.isban.tokenmanager.dto;

import java.util.List;

public class GetIssuerWalletsResponse extends ResponseBase {

    private List<TokenRequestorDto> issuerWallets;

    public GetIssuerWalletsResponse() {
    }

    public GetIssuerWalletsResponse(String code, String description) {
        super(code, description);
    }

    public List<TokenRequestorDto> getIssuerWallets() {
        return issuerWallets;
    }

    public void setIssuerWallets(List<TokenRequestorDto> issuerWallets) {
        this.issuerWallets = issuerWallets;
    }

    @Override
    public String toString() {
        return "GetWalletsResponse [issuerWallets=" + issuerWallets + "]";
    }

}
