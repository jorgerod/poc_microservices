package com.isban.tokenmanager.dto;

public class SaveIssuerWalletRequest{

    private TokenRequestorDto issuerWalletDto;

    public TokenRequestorDto getIssuerWalletDto() {
        return issuerWalletDto;
    }

    public void setIssuerWalletDto(TokenRequestorDto issuerWalletDto) {
        this.issuerWalletDto = issuerWalletDto;
    }


}
