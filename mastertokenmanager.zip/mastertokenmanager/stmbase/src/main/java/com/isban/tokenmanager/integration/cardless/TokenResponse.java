package com.isban.tokenmanager.integration.cardless;

public class TokenResponse {
    
    String tokenid;
    String tokenKey;
    String expireTime;
    
    
    
    public TokenResponse(String tokenid, String tokenKey, String expireTime) {
        super();
        this.tokenid = tokenid;
        this.tokenKey = tokenKey;
        this.expireTime = expireTime;
    }
    
    public String getTokenid() {
        return tokenid;
    }
    public void setTokenid(String tokenid) {
        this.tokenid = tokenid;
    }
    public String getTokenKey() {
        return tokenKey;
    }
    public void setTokenKey(String tokenKey) {
        this.tokenKey = tokenKey;
    }
    public String getExpireTime() {
        return expireTime;
    }
    public void setExpireTime(String expireTime) {
        this.expireTime = expireTime;
    }
    
    

}
