package com.isban.tokenmanager.integration.ppaa;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class RetentionHttpRequest extends CommonHttpRequest {

    private RetentionLifeTimeDto validity;
    private String description;

    @ApiModelProperty(value = "Date and Time of validity of the retention", required = false)
    public RetentionLifeTimeDto getValidity() {
        return validity;
    }

    public void setValidity(RetentionLifeTimeDto validity) {
        this.validity = validity;
    }

    @ApiModelProperty(value = "Description text associated to the retention", required = true)
    @Size(max = 30)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}