
package com.isban.tokenmanager.ws.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codResponse" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="descResponse" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cards" type="{http://www.isban.com/tokenmanager/ws/model}ListCardType" minOccurs="0"/>
 *         &lt;element name="userext" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "codResponse",
    "descResponse",
    "cards",
    "userext"
})
@XmlRootElement(name = "getCardsResponse")
public class GetCardsResponse {

    @XmlElement(required = true)
    protected String codResponse;
    protected String descResponse;
    protected ListCardType cards;
    protected String userext;

    /**
     * Obtiene el valor de la propiedad codResponse.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodResponse() {
        return codResponse;
    }

    /**
     * Define el valor de la propiedad codResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodResponse(String value) {
        this.codResponse = value;
    }

    /**
     * Obtiene el valor de la propiedad descResponse.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescResponse() {
        return descResponse;
    }

    /**
     * Define el valor de la propiedad descResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescResponse(String value) {
        this.descResponse = value;
    }

    /**
     * Obtiene el valor de la propiedad cards.
     * 
     * @return
     *     possible object is
     *     {@link ListCardType }
     *     
     */
    public ListCardType getCards() {
        return cards;
    }

    /**
     * Define el valor de la propiedad cards.
     * 
     * @param value
     *     allowed object is
     *     {@link ListCardType }
     *     
     */
    public void setCards(ListCardType value) {
        this.cards = value;
    }

    /**
     * Obtiene el valor de la propiedad userext.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserext() {
        return userext;
    }

    /**
     * Define el valor de la propiedad userext.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserext(String value) {
        this.userext = value;
    }

}
