package com.isban.tokenmanager.integration.dto;

public class PaymentCancellationDataTcpRequest extends TcpCommonDataRequest {

    private String ditem;
    private String expirationDPanDate;
    private String resolutorOperation;
    private String resolverCode;
    private String originOperationId;

    public PaymentCancellationDataTcpRequest() {
        super();
    }

    public PaymentCancellationDataTcpRequest(String operationId, String operationDateTime, String issuerId, String tokenTypeId,
            String tokenRequestorId, String pan, String expirationDatePan, String dataEntryMode, String ditem,
            String expirationDPanDate, String resolutorOperation, String resolverCode, String originOperationId) {
        super(operationId, operationDateTime, issuerId, tokenTypeId, tokenRequestorId, pan, expirationDatePan, dataEntryMode);
        this.ditem = ditem;
        this.expirationDPanDate = expirationDPanDate;
        this.resolutorOperation = resolutorOperation;
        this.resolverCode = resolverCode;
        this.originOperationId = originOperationId;
    }

    public String getDitem() {
        return ditem;
    }

    public void setDitem(String ditem) {
        this.ditem = ditem;
    }

    public String getExpirationDPanDate() {
        return expirationDPanDate;
    }

    public void setExpirationDPanDate(String expirationDPanDate) {
        this.expirationDPanDate = expirationDPanDate;
    }

    public String getResolutorOperation() {
        return resolutorOperation;
    }

    public void setResolutorOperation(String resolutorOperation) {
        this.resolutorOperation = resolutorOperation;
    }

    public String getResolverCode() {
        return resolverCode;
    }

    public void setResolverCode(String resolverCode) {
        this.resolverCode = resolverCode;
    }

    public String getOriginOperationId() {
        return originOperationId;
    }

    public void setOriginOperationId(String originOperationId) {
        this.originOperationId = originOperationId;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("PaymentCancellationDataTcpRequest [dpan=").append(ditem).append(", expirationDPanDate=")
                .append(expirationDPanDate).append(", resolutorOperation=").append(resolutorOperation)
                .append(", resolverCode=").append(resolverCode).append(", originOperationId=").append(originOperationId)
                .append("]");
        return builder.toString();
    }

}
