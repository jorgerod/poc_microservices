package com.isban.tokenmanager.integration.hubdigital;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class HubDigitalInfoBase {

    @ApiModelProperty(required = true, value = "Timestamp: format RFC 3339.")
    @NotNull
    @Size(min = 16, max = 28)
    private String timestamp;

    @ApiModelProperty(required = true, value = "Issuer Id")
    @NotNull
    @Size(min = 4, max = 4)
    private String issuerId;

    @ApiModelProperty(required = true, value = "Version of the set of keys used for cryptography.")
    @NotNull
    private String keyVersion;

    @ApiModelProperty(required = false, value = "Json object with the data sent in the message.This field is transmitted without encryption.")
    private HubDigitalData data;

    @ApiModelProperty(required = false, value = "Json object with the data sent in the message. This field is transmitted encrypted.")
    private String encryptedData;

    @ApiModelProperty(hidden = true)
    private DecryptedData decryptedData = null;

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getKeyVersion() {
        return keyVersion;
    }

    public void setKeyVersion(String keyVersion) {
        this.keyVersion = keyVersion;
    }

    public HubDigitalData getData() {
        return data;
    }

    public void setData(HubDigitalData data) {
        this.data = data;
    }

    public String getEncryptedData() {
        return encryptedData;
    }

    public void setEncryptedData(String encryptedData) {
        this.encryptedData = encryptedData;
    }

    public DecryptedData getDecryptedData() {
        return decryptedData;
    }

    public void setDecryptedData(DecryptedData decryptedData) {
        this.decryptedData = decryptedData;
    }

}
