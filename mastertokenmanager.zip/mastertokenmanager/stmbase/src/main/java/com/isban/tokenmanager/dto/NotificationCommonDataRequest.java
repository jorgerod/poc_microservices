package com.isban.tokenmanager.dto;

import com.isban.tokenmanager.dto.card.ItemDitemDataDto;

public class NotificationCommonDataRequest extends ModelBaseDto {

    private ItemDitemDataDto itemDitemData;
    
    private String correlationId;
    private String operationDateTime;
    private String tokenRequestorId;
    private String dataEntryMode;

    public NotificationCommonDataRequest() {
    }


    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getDataEntryMode() {
        return dataEntryMode;
    }

    public void setDataEntryMode(String dataEntryMode) {
        this.dataEntryMode = dataEntryMode;
    }

    public String getOperationDateTime() {
        return operationDateTime;
    }

    public void setOperationDateTime(String operationDateTime) {
        this.operationDateTime = operationDateTime;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }


    public ItemDitemDataDto getItemDitemData() {
        return itemDitemData;
    }

    public void setItemDitemData(ItemDitemDataDto itemDitemData) {
        this.itemDitemData = itemDitemData;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("NotificationCommonDataRequest [itemDitemData=").append(itemDitemData).append(", correlationId=")
                .append(correlationId).append(", operationDateTime=").append(operationDateTime)
                .append(", tokenRequestorId=").append(tokenRequestorId).append(", dataEntryMode=").append(dataEntryMode)
                .append("]");
        return builder.toString();
    }

}
