package com.isban.tokenmanager.dto;

public class TypeMessageDto {

    private String id;

    private String description;

    private OriginMessageDto originMessage;
    private ServiceDto service;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public OriginMessageDto getOriginMessage() {
        return originMessage;
    }

    public void setOriginMessage(OriginMessageDto originMessage) {
        this.originMessage = originMessage;
    }

    public ServiceDto getService() {
        return service;
    }

    public void setService(ServiceDto service) {
        this.service = service;
    }

}
