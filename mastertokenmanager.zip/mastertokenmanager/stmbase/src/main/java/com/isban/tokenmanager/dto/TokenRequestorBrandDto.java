package com.isban.tokenmanager.dto;

public class TokenRequestorBrandDto extends LifeTimeDto {

    private String tokenRequestorId;
    private String tokenRequestorName;
    private String brandBinId;
    private String brandBinName;
    private String tspId;
    private String tspName;
    private String tspDescription;

    public TokenRequestorBrandDto() {
    }
    
    public TokenRequestorBrandDto(String issuerId, String tokenTypeId) {
        this.issuerId = issuerId;
        this.tokenTypeId = tokenTypeId;
    }
    
    public TokenRequestorBrandDto(String issuerId, String tokenTypeId, String tokenRequestorId, String walletName,
            String brandBinId, String brandBinName, String tspId, String tspName, String tspDescription) {
        this(issuerId, tokenTypeId);
        this.tokenRequestorId = tokenRequestorId;
        this.tokenRequestorName = walletName;
        this.brandBinId = brandBinId;
        this.brandBinName = brandBinName;
        this.tspId = tspId;
        this.tspName = tspName;
        this.tspDescription = tspDescription;
    }

    public String getTokenRequestorId() {
        return tokenRequestorId;
    }

    public void setTokenRequestorId(String tokenRequestorId) {
        this.tokenRequestorId = tokenRequestorId;
    }

    public String getBrandBinId() {
        return brandBinId;
    }

    public void setBrandBinId(String brandBinId) {
        this.brandBinId = brandBinId;
    }

    public String getTspId() {
        return tspId;
    }

    public void setTspId(String tspId) {
        this.tspId = tspId;
    }

    public String getTspName() {
        return tspName;
    }

    public void setTspName(String tspName) {
        this.tspName = tspName;
    }

    public String getTokenRequestorName() {
        return tokenRequestorName;
    }

    public void setTokenRequestorName(String walletName) {
        this.tokenRequestorName = walletName;
    }

    public String getBrandBinName() {
        return brandBinName;
    }

    public void setBrandBinName(String brandBinName) {
        this.brandBinName = brandBinName;
    }

    public String getTspDescription() {
        return tspDescription;
    }

    public void setTspDescription(String tspDescription) {
        this.tspDescription = tspDescription;
    }

}
