package com.isban.tokenmanager.dto;

import java.util.List;

public class ClientResponse extends ResponseBase {

    private List<String> clients;

    public ClientResponse(String code, String description) {
        super(code, description);
    }

    public ClientResponse() {
    }

    public List<String> getClients() {
        return clients;
    }

    public void setClients(List<String> clients) {
        this.clients = clients;
    }
}
