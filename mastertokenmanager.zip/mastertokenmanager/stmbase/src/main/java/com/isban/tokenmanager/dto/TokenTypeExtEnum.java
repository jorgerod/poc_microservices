package com.isban.tokenmanager.dto;

public enum TokenTypeExtEnum {
    CLOUD("01"), 
    EMBEDDED_SE("02"), 
    HCE("03"),
    STATIC("04");
    
    private String code;
    
    TokenTypeExtEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
    
}
