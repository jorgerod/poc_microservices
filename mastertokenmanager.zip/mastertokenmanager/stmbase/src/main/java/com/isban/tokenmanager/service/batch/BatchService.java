package com.isban.tokenmanager.service.batch;

import java.nio.file.Path;
import java.util.Date;

import com.isban.tokenmanager.dto.IssuerDto;

public interface BatchService {
    void startBatchProcess(String issuerId);
    void startBatchProcess(IssuerDto issuerDto);
    void startBatchFileProcess(IssuerDto issuerDto, Path path);
    //void startOutboundProcess(String issuerId);//TODO REVISAR, posiblemente esta funcionalidad no se este utilizando
    
    void getReportRequestOpenedInDate(String issuerId, String tokenTypeId, Date date);
}
