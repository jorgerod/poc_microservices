package com.isban.tokenmanager.integration.cardless;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.isban.tokenmanager.util.Constants;

import io.swagger.annotations.ApiModelProperty;

public class Token {

    String requestTime;
    String customerId;
    String contract;
    String tokenReferenceId;
    String branchOffice;
    String state;
    String amount;
    String currency;
    Boolean smsSend;
    String smsPhone;
    String requestorId;
    
    @ApiModelProperty(value = "Date and time of token request", required = true)
    @Pattern(regexp = Constants.PATTERN_DATETIME)
    @Size(max = 19)    
    public String getRequestTime() {
        return requestTime;
    }
    public void setRequestTime(String requestTime) {
        this.requestTime = requestTime;
    }

    @ApiModelProperty(value = "ID of the customer associated to the token", required = true)
    @Size(max = 10)    
    public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    @ApiModelProperty(value = "Partenon Contract Number associated to the token", required = true)
    @Size(max = 18)    
    public String getContract() {
        return contract;
    }
    public void setContract(String contract) {
        this.contract = contract;
    }

    @ApiModelProperty(value = "ID of the token", required = true)
    @Size(max = 32)    
    public String getTokenReferenceId() {
        return tokenReferenceId;
    }
    public void setTokenReferenceId(String tokenReferenceId) {
        this.tokenReferenceId = tokenReferenceId;
    }

    @ApiModelProperty(value = "Branch Office that asked the token", required = true)
    @Size(max = 4)    
    public String getBranchOffice() {
        return branchOffice;
    }
    public void setBranchOffice(String branchOffice) {
        this.branchOffice = branchOffice;
    }

    @ApiModelProperty(value = "State of the token", required = true)
    @Size(max = 2)    
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }

    @ApiModelProperty(value = "Amount requested", required = true)
    @Pattern(regexp="\\d+")
    @Size(max = 12)    
    public String getAmount() {
        return amount;
    }
    public void setAmount(String amount) {
        this.amount = amount;
    }

    @ApiModelProperty(value = "Currency associated to the amount", required = true)
    @Size(max = 3)    
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @ApiModelProperty(value = "Flag to indicate if the sms has been sent", required = true)
    @Pattern(regexp="[true|false]")
    @Size(max = 5)    
    public Boolean getSmsSend() {
        return smsSend;
    }
    public void setSmsSend(Boolean smsSend) {
        this.smsSend = smsSend;
    }
    
    @ApiModelProperty(value = "Phone where send the sms", required = true)
    @Size(max = 15)    
    public String getSmsPhone() {
        return smsPhone;
    }
    public void setSmsPhone(String smsPhone) {
        this.smsPhone = smsPhone;
    }
    public String getRequestorId() {
        return requestorId;
    }
    public void setRequestorId(String requestorId) {
        this.requestorId = requestorId;
    }
}

