package com.isban.tokenmanager.dto;

import com.isban.tokenmanager.model.enm.ResponseStateEnum;

public class ResponseBase {
    
    private String code;
    private String description;

    public ResponseBase() {
    }

    public ResponseBase(String c, String d) {
        super();
        code = c;
        description = d;
    }
    
    public ResponseBase(ResponseStateEnum responseState) {
        super();
        setResponseState(responseState);
    }
    //ResponseStateEnum
    
    public void setResponseState(ResponseStateEnum responseState){
        if(responseState == null){ return; }
        code = responseState.getCode();
        description = responseState.getDescription();
    }
    
    public String getCode() {
        return code;
    }

    public void setCode(String c) {
        code = c;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String d) {
        description = d;
    }

    @Override
    public String toString() {
        return "ResponseBase [code=" + code + ", description=" + description + "]";
    }
}
