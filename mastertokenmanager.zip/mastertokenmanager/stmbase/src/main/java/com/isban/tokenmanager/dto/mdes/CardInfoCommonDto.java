package com.isban.tokenmanager.dto.mdes;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

public class CardInfoCommonDto {

    @NotNull
    @Size(max = 256000)
    private String encryptedData; // Max length: 256 K

    @NotNull
    @Size(max = 64)
    private String publicKeyFingerprint; // Hex-encoded data (case-insensitive)
    
    @NotNull
    @Size(max = 512)
    private String encryptedKey; // Hex-encoded data (case-insensitive)
    
    @NotNull
    @Size(max = 6)
    private String oaepHashingAlgorithm; // SHA256 or SHA512
    
    @Size(min = 32, max = 32)
    private String iv; // Hex-encoded data (case-insensitive)
    
    @ApiModelProperty(value = "Reference to the PAN that is unique per Wallet Provider.", required = true)
    @Size(max = 64)
    private String panUniqueReference;
    
    
    public String getEncryptedData() {
        return encryptedData;
    }
    public void setEncryptedData(String encryptedData) {
        this.encryptedData = encryptedData;
    }
    public String getPublicKeyFingerprint() {
        return publicKeyFingerprint;
    }
    public void setPublicKeyFingerprint(String publicKeyFingerprint) {
        this.publicKeyFingerprint = publicKeyFingerprint;
    }
    public String getEncryptedKey() {
        return encryptedKey;
    }
    public void setEncryptedKey(String encryptedKey) {
        this.encryptedKey = encryptedKey;
    }
    public String getOaepHashingAlgorithm() {
        return oaepHashingAlgorithm;
    }
    public void setOaepHashingAlgorithm(String oaepHashingAlgorithm) {
        this.oaepHashingAlgorithm = oaepHashingAlgorithm;
    }
    public String getIv() {
        return iv;
    }
    public void setIv(String iv) {
        this.iv = iv;
    }
    public String getPanUniqueReference() {
        return panUniqueReference;
    }
    public void setPanUniqueReference(String panUniqueReference) {
        this.panUniqueReference = panUniqueReference;
    }
    
}
