package com.isban.tokenmanager.service.security.impl;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.math.BigInteger;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.Provider.Service;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;

import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;

import com.isban.tokenmanager.service.security.CryptographicService;
import com.isban.tokenmanager.util.Base58;

@Component(value = "cryptographicBase")
public class CryptographicBase implements CryptographicService {
    
//    @Value("${crypto.mdes.pwd}")
    private String pwd;
    
//    @Value("${crypto.mdes.alias}")
    private String mdesalias;    
    
    Base58 base58 = new Base58();
    SecureRandom random = new SecureRandom( ("" + (new java.util.Date()).getTime()).getBytes() );
//    @SuppressWarnings("restriction")
//    sun.misc.BASE64Decoder base64Decoder = new sun.misc.BASE64Decoder();
//    @SuppressWarnings("restriction")
//    sun.misc.BASE64Encoder base64Encoder = new sun.misc.BASE64Encoder();
    
    @Override
    public String describeSecuritySystem(){
        StringBuffer sbRet = new StringBuffer();
        
        for( Provider provider : Security.getProviders() ) {
            sbRet.append( "Provider: " + provider.getName() + "\n" );
            for( String key: provider.stringPropertyNames() ){
                sbRet.append( "\t" + key + "=" + provider.getProperty(key) + "\n" );
            }
            for( Service service : provider.getServices()) {
                sbRet.append( "\t\tAlgorithm=" + service.getAlgorithm() + "\n" );
            }
        }
        
        sbRet.append( "\n" );
        return sbRet.toString();
    }
    
    @Override
    public byte[] createRandomBytes( int length ){
        byte ret[] = null;
        if( length < 0 ){ return ret; }
        
        //get random bytes
        ret = new byte[length];
        random.nextBytes( ret );

        return ret;
    }
    
    @Override
    public String bytesToBase64( byte[] bytes ) {
        String ret = null;
        if( bytes == null ){ return ret; }
        
        try {
            //ret = base64Encoder.encodeBuffer(bytes);
            //ret = Base64.getEncoder().encodeToString(bytes);
            ret = Base64Utils.encodeToString(bytes);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    @Override
    public byte[] base64ToBytes( String base64 ) {
        byte ret[] = null;
        if( base64 == null ){ return ret; }
        
        try {
            //ret = base64Decoder.decodeBuffer( base64 );
            //ret = Base64.getDecoder().decode(base64);
            ret = Base64Utils.decodeFromString(base64);
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    @Override
    public String stringToBase64( String value ) {
        String ret = bytesToBase64( value.getBytes() );
        return ret;
    }
    
    @Override
    public String base64ToString( String base64 ){
        String ret = null;
        byte retTmp[] = base64ToBytes( base64 );
        if( retTmp == null ){ return ret; }
                
        ret = new String( retTmp );
        return ret;
    }
    
    @Override
    public String bytesToBase58( byte[] bytes ) {
        String ret = null;
        if( bytes == null ){ return ret; }
        
        try {
            ret = base58.encodeFromBytes(bytes);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    @Override
    public byte[] base58ToBytes(String value) {
        byte ret[] = null;
        if( value == null ){ return ret; }
        
        try {
            ret = base58.decodeToBytes(value);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    @Override
    public String stringToBase58( String value ) {
        String ret = null;
        if( value == null ){ return ret; }
        
        try {
            ret = base58.encode(value);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    @Override
    public String base58ToString( String value ) {
        String ret = null;
        if( value == null ){ return ret; }
        
        try {
            ret = base58.decode(value);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    @Override
    public String createBase58RandomId( int length ){
        String ret = null;
        if( length < 0 ){ return ret; }
        
        //get random bytes
        byte bytes4id[] = new byte[length];
        random.nextBytes( bytes4id );
        //convert to base58 and cut to length
        ret = base58.encodeFromBytes( bytes4id );
        ret = ret.substring( 0, length );
        
        return ret;
    }
    
    @Override
    public String bytesToHex( byte[] bytes ){
        String ret = null;
        if( bytes == null ){ return ret; }
        
        try {
            ret = String.format("%x", new BigInteger(1, bytes));
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    @Override
    public String bytesToHexUpperCase( byte[] bytes ){
        String ret = null;
        String retTmp = bytesToHex( bytes );
        if( retTmp == null ){ return ret; }
        
        ret = retTmp.toUpperCase();
        return ret;
    }
    
    @Override
    public byte[] hexToBytes(String hex) {
        byte ret[] = null;
        if( hex == null ){ return ret; }
        
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int sz = hex.length();
            for( int i=0 ; i<sz ; i+=2 ) {
                String str = hex.substring(i, i+2);
                baos.write((byte)Integer.parseInt(str, 16));
            }
            ret = baos.toByteArray();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    @Override
    public String stringToHex(String value) {
        String ret = null;
        if( value == null ){ return ret; }
        
        ret = bytesToHex( value.getBytes(/*YOUR_CHARSET?*/) );
        return ret;
    }
    
    @Override
    public String stringToHexUpperCase(String value) {
        String ret = null;
        String retTmp = stringToHex( value );
        if( retTmp == null ){ return ret; }
        
        ret = retTmp.toUpperCase();
        return ret;
    }
    
    @Override
    public String hexToString(String hex) {
        String ret = null;
        byte retTmp[] = hexToBytes( hex );
        if( retTmp == null ){ return ret; }
        
        ret = new String( retTmp );
        return ret;
    }

    public PublicKey getPublicKeyFromFile(String filename) {
        PublicKey ret = null;
        //http://stackoverflow.com/questions/18757114/java-security-rsa-public-key-private-key-code-issue
        try {
            URL url = this.getClass().getClassLoader().getResource(filename);
            URI uri = url.toURI();
            File f = new File(uri);
          
            FileInputStream fis = new FileInputStream(f);
            ObjectInputStream oin = new ObjectInputStream(new BufferedInputStream(
                    fis));
            try {
                BigInteger m = (BigInteger) oin.readObject();
                BigInteger e = (BigInteger) oin.readObject();
                KeyFactory fact = KeyFactory.getInstance("RSA");
                return fact.generatePublic(new RSAPublicKeySpec(m, e));
            } catch (Exception e) {
                throw new RuntimeException("Spurious serialisation error", e);
            } finally {
                oin.close();
                System.out.println("Closed reading file.");
            }
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    public PrivateKey getPrivateKeyFromFile(String filename) {
        PrivateKey ret = null;
        //http://stackoverflow.com/questions/18757114/java-security-rsa-public-key-private-key-code-issue
        try {
        //        
        //        File f = new File(filename);
        //        FileInputStream fis = new FileInputStream(f);
        //        DataInputStream dis = new DataInputStream(fis);
        //        byte[] keyBytes = new byte[(int)f.length()];
        //        dis.readFully(keyBytes);
        //        dis.close();
        //       
        //        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        //        KeyFactory kf = KeyFactory.getInstance("RSA");
        //        
        //        return kf.generatePrivate(spec);
                
                URL url = this.getClass().getClassLoader().getResource(filename);
                URI uri = url.toURI();
                File f = new File(uri);
                
                InputStream in = new FileInputStream(f);
                ObjectInputStream oin = new ObjectInputStream(new BufferedInputStream(
                        in));
                try {
                    BigInteger m = (BigInteger) oin.readObject();
                    BigInteger e = (BigInteger) oin.readObject();
                    KeyFactory fact = KeyFactory.getInstance("RSA");
                    ret = fact.generatePrivate(new RSAPrivateKeySpec(m, e));
                } catch (Exception e) {
                    throw new RuntimeException("Spurious serialisation error", e);
                } finally {
                    oin.close();
                    System.out.println("Closed reading file.");
                }
        } catch (URISyntaxException | IOException e) {
            e.printStackTrace();
        }
        
        return ret;
    }
    
    public PrivateKey getPrivateKeyFromPKCS12(String fileName) {
        PrivateKey ret = null;

        try {

            URL url = this.getClass().getClassLoader().getResource(fileName);
            URI uri = url.toURI();
            File f = new File(uri);                     
            
            KeyStore store = KeyStore.getInstance("PKCS12");
            store.load(new FileInputStream(f), pwd.toCharArray());
            ret = (PrivateKey) store.getKey(mdesalias, pwd.toCharArray());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }    
    
    public PublicKey getPublicKeyFromPKCS12(String fileName) {

        PublicKey ret = null;
        try {
            
            URL url = this.getClass().getClassLoader().getResource(fileName);
            URI uri = url.toURI();
            File f = new File(uri);            
            
            
            KeyStore store = KeyStore.getInstance("PKCS12");
            store.load(new FileInputStream(f), pwd.toCharArray());
            ret = ((Certificate) store.getCertificate(mdesalias)).getPublicKey();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return ret;
    }     
    
    
}
