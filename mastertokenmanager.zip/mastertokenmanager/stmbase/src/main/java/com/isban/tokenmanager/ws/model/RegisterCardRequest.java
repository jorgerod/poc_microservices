
package com.isban.tokenmanager.ws.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="issuerid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="client" type="{http://www.isban.com/tokenmanager/ws/model}ClientType"/>
 *         &lt;element name="walletid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pan" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="expirationdate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="typedoc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="doc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ticketref" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="userext" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="deviceid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="devicetype" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="devicename" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="devicelanguage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="devicelocation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="channelframe" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="multichannelcontract" type="{http://www.isban.com/tokenmanager/ws/model}MultiChannelContractType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "issuerid",
    "client",
    "walletid",
    "pan",
    "expirationdate",
    "typedoc",
    "doc",
    "ticketref",
    "userext",
    "deviceid",
    "devicetype",
    "devicename",
    "devicelanguage",
    "devicelocation",
    "channelframe",
    "multichannelcontract"
})
@XmlRootElement(name = "registerCardRequest")
public class RegisterCardRequest {

    @XmlElement(required = true)
    protected String issuerid;
    @XmlElement(required = true)
    protected ClientType client;
    @XmlElement(required = true)
    protected String walletid;
    @XmlElement(required = true)
    protected String pan;
    @XmlElement(required = true)
    protected String expirationdate;
    @XmlElement(required = true)
    protected String typedoc;
    @XmlElement(required = true)
    protected String doc;
    @XmlElement(required = true)
    protected String ticketref;
    @XmlElement(required = true)
    protected String userext;
    @XmlElement(required = true)
    protected String deviceid;
    protected String devicetype;
    protected String devicename;
    protected String devicelanguage;
    protected String devicelocation;
    protected String channelframe;
    protected MultiChannelContractType multichannelcontract;

    /**
     * Obtiene el valor de la propiedad issuerid.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuerid() {
        return issuerid;
    }

    /**
     * Define el valor de la propiedad issuerid.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuerid(String value) {
        this.issuerid = value;
    }

    /**
     * Obtiene el valor de la propiedad client.
     * 
     * @return
     *     possible object is
     *     {@link ClientType }
     *     
     */
    public ClientType getClient() {
        return client;
    }

    /**
     * Define el valor de la propiedad client.
     * 
     * @param value
     *     allowed object is
     *     {@link ClientType }
     *     
     */
    public void setClient(ClientType value) {
        this.client = value;
    }

    /**
     * Obtiene el valor de la propiedad walletid.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWalletid() {
        return walletid;
    }

    /**
     * Define el valor de la propiedad walletid.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWalletid(String value) {
        this.walletid = value;
    }

    /**
     * Obtiene el valor de la propiedad pan.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPan() {
        return pan;
    }

    /**
     * Define el valor de la propiedad pan.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPan(String value) {
        this.pan = value;
    }

    /**
     * Obtiene el valor de la propiedad expirationdate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpirationdate() {
        return expirationdate;
    }

    /**
     * Define el valor de la propiedad expirationdate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpirationdate(String value) {
        this.expirationdate = value;
    }

    /**
     * Obtiene el valor de la propiedad typedoc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypedoc() {
        return typedoc;
    }

    /**
     * Define el valor de la propiedad typedoc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypedoc(String value) {
        this.typedoc = value;
    }

    /**
     * Obtiene el valor de la propiedad doc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDoc() {
        return doc;
    }

    /**
     * Define el valor de la propiedad doc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDoc(String value) {
        this.doc = value;
    }

    /**
     * Obtiene el valor de la propiedad ticketref.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTicketref() {
        return ticketref;
    }

    /**
     * Define el valor de la propiedad ticketref.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTicketref(String value) {
        this.ticketref = value;
    }

    /**
     * Obtiene el valor de la propiedad userext.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserext() {
        return userext;
    }

    /**
     * Define el valor de la propiedad userext.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserext(String value) {
        this.userext = value;
    }

    /**
     * Obtiene el valor de la propiedad deviceid.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceid() {
        return deviceid;
    }

    /**
     * Define el valor de la propiedad deviceid.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceid(String value) {
        this.deviceid = value;
    }

    /**
     * Obtiene el valor de la propiedad devicetype.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDevicetype() {
        return devicetype;
    }

    /**
     * Define el valor de la propiedad devicetype.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDevicetype(String value) {
        this.devicetype = value;
    }

    /**
     * Obtiene el valor de la propiedad devicename.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDevicename() {
        return devicename;
    }

    /**
     * Define el valor de la propiedad devicename.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDevicename(String value) {
        this.devicename = value;
    }

    /**
     * Obtiene el valor de la propiedad devicelanguage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDevicelanguage() {
        return devicelanguage;
    }

    /**
     * Define el valor de la propiedad devicelanguage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDevicelanguage(String value) {
        this.devicelanguage = value;
    }

    /**
     * Obtiene el valor de la propiedad devicelocation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDevicelocation() {
        return devicelocation;
    }

    /**
     * Define el valor de la propiedad devicelocation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDevicelocation(String value) {
        this.devicelocation = value;
    }

    /**
     * Obtiene el valor de la propiedad channelframe.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelframe() {
        return channelframe;
    }

    /**
     * Define el valor de la propiedad channelframe.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelframe(String value) {
        this.channelframe = value;
    }

    /**
     * Obtiene el valor de la propiedad multichannelcontract.
     * 
     * @return
     *     possible object is
     *     {@link MultiChannelContractType }
     *     
     */
    public MultiChannelContractType getMultichannelcontract() {
        return multichannelcontract;
    }

    /**
     * Define el valor de la propiedad multichannelcontract.
     * 
     * @param value
     *     allowed object is
     *     {@link MultiChannelContractType }
     *     
     */
    public void setMultichannelcontract(MultiChannelContractType value) {
        this.multichannelcontract = value;
    }

}
