package com.isban.tokenmanager.stmcrypto.dto;

public class KeyData {

    private String companyId;
    private String appId;
    private String keyName;
    private String keyType; 
    private String keyVersion;

    public String getCompanyId() {
        return companyId;
    }
    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getKeyName() {
        return keyName;
    }
    public void setKeyName(String keyName) {
        this.keyName = keyName;
    }
    
    public String getKeyType() {
        return keyType;
    }
    public void setKeyType(String keyType) {
        this.keyType = keyType;
    }
    
    public String getKeyVersion() {
        return keyVersion;
    }
    public void setKeyVersion(String keyVersion) {
        this.keyVersion = keyVersion;
    }
}

