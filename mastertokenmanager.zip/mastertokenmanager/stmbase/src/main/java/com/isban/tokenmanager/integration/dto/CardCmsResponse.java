package com.isban.tokenmanager.integration.dto;


public class CardCmsResponse {

    String codRes;
    String desRes;
    CardCms card;

    public CardCmsResponse() {

    }

    public CardCmsResponse(String codRes, String desRes) {
        this.codRes = codRes;
        this.desRes = desRes;
    }


    public CardCmsResponse(String codRes, String desRes, CardCms card) {
        this.codRes = codRes;
        this.desRes = desRes;
        this.card = card;
    }

    public String getCodRes() {
        return codRes;
    }

    public void setCodRes(String codRes) {
        this.codRes = codRes;
    }

    public String getDesRes() {
        return desRes;
    }

    public void setDesRes(String desRes) {
        this.desRes = desRes;
    }

    public CardCms getCard() {
        return card;
    }

    public void setCard(CardCms card) {
        this.card = card;
    }

    @Override
    public String toString() {
        return "CardCmsResponse [codRes=" + codRes + ", desRes=" + desRes
                + ", card=" + card + "]";
    }


}
