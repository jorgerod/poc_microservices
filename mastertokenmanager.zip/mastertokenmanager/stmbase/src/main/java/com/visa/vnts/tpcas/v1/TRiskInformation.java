
package com.visa.vnts.tpcas.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para tRiskInformation complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="tRiskInformation">
 *   &lt;complexContent>
 *     &lt;extension base="{http://vnts.visa.com/tpcas/v1}tRiskInformationCommon">
 *       &lt;sequence>
 *         &lt;element name="finalProvisioningDecision" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="dateAndTimeTokenActivated" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tRiskInformation", propOrder = {
    "finalProvisioningDecision",
    "dateAndTimeTokenActivated"
})
public class TRiskInformation
    extends TRiskInformationCommon
{

    protected String finalProvisioningDecision;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateAndTimeTokenActivated;

    /**
     * Obtiene el valor de la propiedad finalProvisioningDecision.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinalProvisioningDecision() {
        return finalProvisioningDecision;
    }

    /**
     * Define el valor de la propiedad finalProvisioningDecision.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinalProvisioningDecision(String value) {
        this.finalProvisioningDecision = value;
    }

    /**
     * Obtiene el valor de la propiedad dateAndTimeTokenActivated.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateAndTimeTokenActivated() {
        return dateAndTimeTokenActivated;
    }

    /**
     * Define el valor de la propiedad dateAndTimeTokenActivated.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateAndTimeTokenActivated(XMLGregorianCalendar value) {
        this.dateAndTimeTokenActivated = value;
    }

}
