
package com.visa.vnts.tpcas.v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para tCardMetaData complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="tCardMetaData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cardIssuer" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="128"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="foreGroundColor" type="{http://vnts.visa.com/tpcas/v1}tForeGroundColor" minOccurs="0"/>
 *         &lt;element name="backGroundColor" type="{http://vnts.visa.com/tpcas/v1}tBackGroundColor" minOccurs="0"/>
 *         &lt;element name="labelColor" type="{http://vnts.visa.com/tpcas/v1}tLabelColor" minOccurs="0"/>
 *         &lt;element name="shortDescription" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="32"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="longDescription" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="64"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="cardMetadataProfileId" type="{http://vnts.visa.com/tpcas/v1}tCardMetadataProfileId" minOccurs="0"/>
 *         &lt;element name="supportsTokenNotification" type="{http://vnts.visa.com/tpcas/v1}tSupportsTokenNotification" minOccurs="0"/>
 *         &lt;element name="cardArt" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="issuerCardArtRefId" type="{http://vnts.visa.com/tpcas/v1}tFixedString32" maxOccurs="5" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="issuerTAndCRefId" type="{http://vnts.visa.com/tpcas/v1}tFixedString32" minOccurs="0"/>
 *         &lt;element name="contactWebSite" type="{http://vnts.visa.com/tpcas/v1}tOptionalString128" minOccurs="0"/>
 *         &lt;element name="contactEmail" type="{http://vnts.visa.com/tpcas/v1}tOptionalString32" minOccurs="0"/>
 *         &lt;element name="contactNumber" type="{http://vnts.visa.com/tpcas/v1}tOptionalString32" minOccurs="0"/>
 *         &lt;element name="contactName" type="{http://vnts.visa.com/tpcas/v1}tOptionalString32" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tCardMetaData", propOrder = {
    "cardIssuer",
    "foreGroundColor",
    "backGroundColor",
    "labelColor",
    "shortDescription",
    "longDescription",
    "cardMetadataProfileId",
    "supportsTokenNotification",
    "cardArt",
    "issuerTAndCRefId",
    "contactWebSite",
    "contactEmail",
    "contactNumber",
    "contactName"
})
public class TCardMetaData {

    protected String cardIssuer;
    protected String foreGroundColor;
    protected String backGroundColor;
    protected String labelColor;
    protected String shortDescription;
    protected String longDescription;
    protected String cardMetadataProfileId;
    protected Boolean supportsTokenNotification;
    protected TCardMetaData.CardArt cardArt;
    protected String issuerTAndCRefId;
    protected String contactWebSite;
    protected String contactEmail;
    protected String contactNumber;
    protected String contactName;

    /**
     * Obtiene el valor de la propiedad cardIssuer.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardIssuer() {
        return cardIssuer;
    }

    /**
     * Define el valor de la propiedad cardIssuer.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardIssuer(String value) {
        this.cardIssuer = value;
    }

    /**
     * Obtiene el valor de la propiedad foreGroundColor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForeGroundColor() {
        return foreGroundColor;
    }

    /**
     * Define el valor de la propiedad foreGroundColor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForeGroundColor(String value) {
        this.foreGroundColor = value;
    }

    /**
     * Obtiene el valor de la propiedad backGroundColor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackGroundColor() {
        return backGroundColor;
    }

    /**
     * Define el valor de la propiedad backGroundColor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackGroundColor(String value) {
        this.backGroundColor = value;
    }

    /**
     * Obtiene el valor de la propiedad labelColor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLabelColor() {
        return labelColor;
    }

    /**
     * Define el valor de la propiedad labelColor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLabelColor(String value) {
        this.labelColor = value;
    }

    /**
     * Obtiene el valor de la propiedad shortDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShortDescription() {
        return shortDescription;
    }

    /**
     * Define el valor de la propiedad shortDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShortDescription(String value) {
        this.shortDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad longDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongDescription() {
        return longDescription;
    }

    /**
     * Define el valor de la propiedad longDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongDescription(String value) {
        this.longDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad cardMetadataProfileId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardMetadataProfileId() {
        return cardMetadataProfileId;
    }

    /**
     * Define el valor de la propiedad cardMetadataProfileId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardMetadataProfileId(String value) {
        this.cardMetadataProfileId = value;
    }

    /**
     * Obtiene el valor de la propiedad supportsTokenNotification.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSupportsTokenNotification() {
        return supportsTokenNotification;
    }

    /**
     * Define el valor de la propiedad supportsTokenNotification.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSupportsTokenNotification(Boolean value) {
        this.supportsTokenNotification = value;
    }

    /**
     * Obtiene el valor de la propiedad cardArt.
     * 
     * @return
     *     possible object is
     *     {@link TCardMetaData.CardArt }
     *     
     */
    public TCardMetaData.CardArt getCardArt() {
        return cardArt;
    }

    /**
     * Define el valor de la propiedad cardArt.
     * 
     * @param value
     *     allowed object is
     *     {@link TCardMetaData.CardArt }
     *     
     */
    public void setCardArt(TCardMetaData.CardArt value) {
        this.cardArt = value;
    }

    /**
     * Obtiene el valor de la propiedad issuerTAndCRefId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuerTAndCRefId() {
        return issuerTAndCRefId;
    }

    /**
     * Define el valor de la propiedad issuerTAndCRefId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuerTAndCRefId(String value) {
        this.issuerTAndCRefId = value;
    }

    /**
     * Obtiene el valor de la propiedad contactWebSite.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactWebSite() {
        return contactWebSite;
    }

    /**
     * Define el valor de la propiedad contactWebSite.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactWebSite(String value) {
        this.contactWebSite = value;
    }

    /**
     * Obtiene el valor de la propiedad contactEmail.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactEmail() {
        return contactEmail;
    }

    /**
     * Define el valor de la propiedad contactEmail.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactEmail(String value) {
        this.contactEmail = value;
    }

    /**
     * Obtiene el valor de la propiedad contactNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactNumber() {
        return contactNumber;
    }

    /**
     * Define el valor de la propiedad contactNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactNumber(String value) {
        this.contactNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad contactName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Define el valor de la propiedad contactName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactName(String value) {
        this.contactName = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="issuerCardArtRefId" type="{http://vnts.visa.com/tpcas/v1}tFixedString32" maxOccurs="5" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "issuerCardArtRefId"
    })
    public static class CardArt {

        protected List<String> issuerCardArtRefId;

        /**
         * Gets the value of the issuerCardArtRefId property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the issuerCardArtRefId property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getIssuerCardArtRefId().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getIssuerCardArtRefId() {
            if (issuerCardArtRefId == null) {
                issuerCardArtRefId = new ArrayList<String>();
            }
            return this.issuerCardArtRefId;
        }

    }

}
