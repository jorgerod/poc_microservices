@javax.xml.bind.annotation.XmlSchema(namespace = "http://vnts.visa.com/tpcas/v1", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.visa.vnts.tpcas.v1;
