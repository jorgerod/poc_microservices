
package com.visa.vnts.tpcas.v1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para tRiskInformationCommon complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="tRiskInformationCommon">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="wpReasonCodes" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="panSource" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;length value="2"/>
 *               &lt;enumeration value="01"/>
 *               &lt;enumeration value="02"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="wpDeviceScore" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}positiveInteger">
 *               &lt;totalDigits value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="wpAccountScore" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}positiveInteger">
 *               &lt;totalDigits value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="riskAssessmentScore" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger">
 *               &lt;totalDigits value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="tokenProvisioningScore" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger">
 *               &lt;totalDigits value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tRiskInformationCommon", propOrder = {
    "wpReasonCodes",
    "panSource",
    "wpDeviceScore",
    "wpAccountScore",
    "riskAssessmentScore",
    "tokenProvisioningScore"
})
@XmlSeeAlso({
    TRiskInformation.class
})
public class TRiskInformationCommon {

    protected String wpReasonCodes;
    protected String panSource;
    protected BigInteger wpDeviceScore;
    protected BigInteger wpAccountScore;
    protected BigInteger riskAssessmentScore;
    protected BigInteger tokenProvisioningScore;

    /**
     * Obtiene el valor de la propiedad wpReasonCodes.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWpReasonCodes() {
        return wpReasonCodes;
    }

    /**
     * Define el valor de la propiedad wpReasonCodes.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWpReasonCodes(String value) {
        this.wpReasonCodes = value;
    }

    /**
     * Obtiene el valor de la propiedad panSource.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanSource() {
        return panSource;
    }

    /**
     * Define el valor de la propiedad panSource.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanSource(String value) {
        this.panSource = value;
    }

    /**
     * Obtiene el valor de la propiedad wpDeviceScore.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getWpDeviceScore() {
        return wpDeviceScore;
    }

    /**
     * Define el valor de la propiedad wpDeviceScore.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setWpDeviceScore(BigInteger value) {
        this.wpDeviceScore = value;
    }

    /**
     * Obtiene el valor de la propiedad wpAccountScore.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getWpAccountScore() {
        return wpAccountScore;
    }

    /**
     * Define el valor de la propiedad wpAccountScore.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setWpAccountScore(BigInteger value) {
        this.wpAccountScore = value;
    }

    /**
     * Obtiene el valor de la propiedad riskAssessmentScore.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRiskAssessmentScore() {
        return riskAssessmentScore;
    }

    /**
     * Define el valor de la propiedad riskAssessmentScore.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRiskAssessmentScore(BigInteger value) {
        this.riskAssessmentScore = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenProvisioningScore.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTokenProvisioningScore() {
        return tokenProvisioningScore;
    }

    /**
     * Define el valor de la propiedad tokenProvisioningScore.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTokenProvisioningScore(BigInteger value) {
        this.tokenProvisioningScore = value;
    }

}
