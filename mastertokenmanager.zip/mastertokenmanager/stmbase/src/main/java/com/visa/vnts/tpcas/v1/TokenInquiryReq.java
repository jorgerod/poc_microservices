
package com.visa.vnts.tpcas.v1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="requestID" type="{http://vnts.visa.com/tpcas/v1}tRequestID"/>
 *         &lt;element name="operatorID" type="{http://vnts.visa.com/tpcas/v1}tOtionalOperatorID" minOccurs="0"/>
 *         &lt;element name="token" type="{http://vnts.visa.com/tpcas/v1}tDPan" minOccurs="0"/>
 *         &lt;element name="tokenReferenceID" type="{http://vnts.visa.com/tpcas/v1}tOptionalTokenReferenceID" minOccurs="0"/>
 *         &lt;element name="tokenRequestorID" type="{http://vnts.visa.com/tpcas/v1}tTokenRequestorID" minOccurs="0"/>
 *         &lt;element name="panReferenceID" type="{http://vnts.visa.com/tpcas/v1}tPanReferenceID" minOccurs="0"/>
 *         &lt;element name="cardholderInfo" type="{http://vnts.visa.com/tpcas/v1}tCardholderInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "requestID",
    "operatorID",
    "token",
    "tokenReferenceID",
    "tokenRequestorID",
    "panReferenceID",
    "cardholderInfo"
})
@XmlRootElement(name = "tokenInquiryReq")
public class TokenInquiryReq {

    @XmlElement(required = true)
    protected String requestID;
    protected String operatorID;
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger token;
    protected String tokenReferenceID;
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger tokenRequestorID;
    protected String panReferenceID;
    protected TCardholderInfo cardholderInfo;

    /**
     * Obtiene el valor de la propiedad requestID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestID() {
        return requestID;
    }

    /**
     * Define el valor de la propiedad requestID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestID(String value) {
        this.requestID = value;
    }

    /**
     * Obtiene el valor de la propiedad operatorID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperatorID() {
        return operatorID;
    }

    /**
     * Define el valor de la propiedad operatorID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatorID(String value) {
        this.operatorID = value;
    }

    /**
     * Obtiene el valor de la propiedad token.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getToken() {
        return token;
    }

    /**
     * Define el valor de la propiedad token.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setToken(BigInteger value) {
        this.token = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenReferenceID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTokenReferenceID() {
        return tokenReferenceID;
    }

    /**
     * Define el valor de la propiedad tokenReferenceID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenReferenceID(String value) {
        this.tokenReferenceID = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenRequestorID.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTokenRequestorID() {
        return tokenRequestorID;
    }

    /**
     * Define el valor de la propiedad tokenRequestorID.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTokenRequestorID(BigInteger value) {
        this.tokenRequestorID = value;
    }

    /**
     * Obtiene el valor de la propiedad panReferenceID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanReferenceID() {
        return panReferenceID;
    }

    /**
     * Define el valor de la propiedad panReferenceID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanReferenceID(String value) {
        this.panReferenceID = value;
    }

    /**
     * Obtiene el valor de la propiedad cardholderInfo.
     * 
     * @return
     *     possible object is
     *     {@link TCardholderInfo }
     *     
     */
    public TCardholderInfo getCardholderInfo() {
        return cardholderInfo;
    }

    /**
     * Define el valor de la propiedad cardholderInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link TCardholderInfo }
     *     
     */
    public void setCardholderInfo(TCardholderInfo value) {
        this.cardholderInfo = value;
    }

}
