
package com.visa.vnts.tpcas.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para deviceInformationWithSNo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="deviceInformationWithSNo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://vnts.visa.com/tpcas/v1}secureElementID" minOccurs="0"/>
 *         &lt;element ref="{http://vnts.visa.com/tpcas/v1}deviceType" minOccurs="0"/>
 *         &lt;element ref="{http://vnts.visa.com/tpcas/v1}deviceNumber" minOccurs="0"/>
 *         &lt;element ref="{http://vnts.visa.com/tpcas/v1}deviceName" minOccurs="0"/>
 *         &lt;element ref="{http://vnts.visa.com/tpcas/v1}serialNumber" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "deviceInformationWithSNo", propOrder = {
    "secureElementID",
    "deviceType",
    "deviceNumber",
    "deviceName",
    "serialNumber"
})
public class DeviceInformationWithSNo {

    protected String secureElementID;
    protected String deviceType;
    protected String deviceNumber;
    protected String deviceName;
    protected String serialNumber;

    /**
     * Obtiene el valor de la propiedad secureElementID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecureElementID() {
        return secureElementID;
    }

    /**
     * Define el valor de la propiedad secureElementID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecureElementID(String value) {
        this.secureElementID = value;
    }

    /**
     * Obtiene el valor de la propiedad deviceType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceType() {
        return deviceType;
    }

    /**
     * Define el valor de la propiedad deviceType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceType(String value) {
        this.deviceType = value;
    }

    /**
     * Obtiene el valor de la propiedad deviceNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceNumber() {
        return deviceNumber;
    }

    /**
     * Define el valor de la propiedad deviceNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceNumber(String value) {
        this.deviceNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad deviceName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * Define el valor de la propiedad deviceName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviceName(String value) {
        this.deviceName = value;
    }

    /**
     * Obtiene el valor de la propiedad serialNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Define el valor de la propiedad serialNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSerialNumber(String value) {
        this.serialNumber = value;
    }

}
