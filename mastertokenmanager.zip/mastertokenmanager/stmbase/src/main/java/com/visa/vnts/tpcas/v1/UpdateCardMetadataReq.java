
package com.visa.vnts.tpcas.v1;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.NormalizedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="requestID" type="{http://vnts.visa.com/tpcas/v1}tURequestID"/>
 *         &lt;element name="responseURL" type="{http://vnts.visa.com/tpcas/v1}tResponseURL"/>
 *         &lt;element name="operatorID" type="{http://vnts.visa.com/tpcas/v1}tOperatorID" minOccurs="0"/>
 *         &lt;element name="operationType" type="{http://vnts.visa.com/tpcas/v1}tOperationType"/>
 *         &lt;element name="operationReason" type="{http://vnts.visa.com/tpcas/v1}tString128"/>
 *         &lt;element name="tokenReferenceID" type="{http://vnts.visa.com/tpcas/v1}tOptionalTokenReferenceID" minOccurs="0"/>
 *         &lt;element name="tokenRequestorID" type="{http://vnts.visa.com/tpcas/v1}tTokenRequestorID" minOccurs="0"/>
 *         &lt;element name="token" type="{http://vnts.visa.com/tpcas/v1}tDPan" minOccurs="0"/>
 *         &lt;element name="panReferenceID" type="{http://vnts.visa.com/tpcas/v1}tPanReferenceID" minOccurs="0"/>
 *         &lt;element name="cardholderInfo" type="{http://vnts.visa.com/tpcas/v1}tCardholderInfo" minOccurs="0"/>
 *         &lt;element name="cardMetaData" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="foreGroundColor" type="{http://vnts.visa.com/tpcas/v1}tForeGroundColorUCMD" minOccurs="0"/>
 *                   &lt;element name="backGroundColor" type="{http://vnts.visa.com/tpcas/v1}tBackGroundColorUCMD" minOccurs="0"/>
 *                   &lt;element name="labelColor" type="{http://vnts.visa.com/tpcas/v1}tLabelColorUCMD" minOccurs="0"/>
 *                   &lt;element name="shortDescription" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="32"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="longDescription" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="64"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="issuerCardArtRefID" maxOccurs="5" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;length value="32"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="contactWebsite" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="128"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="contactEmail" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="32"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="contactNumber" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="32"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="contactName" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="32"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="associatedStoreIdentifiers" maxOccurs="10" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}normalizedString">
 *                         &lt;pattern value="[0-9]{1,20}"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="associatedApplicationdentifiers" maxOccurs="10" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="128"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="applaunchURL" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="128"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="applaunchURLScheme" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="32"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="supportsTokenNotification" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *                   &lt;element name="supportsFPanNotification" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *                   &lt;element name="transactionServiceURL" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="128"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="transactionPushTopic" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="128"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="privacyPolicyURL" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="128"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="termsAndConditionURL" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="128"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="cardMetadataProfileId" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;length value="32"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="messageServiceURL" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="128"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="messagePushTopic" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="128"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "requestID",
    "responseURL",
    "operatorID",
    "operationType",
    "operationReason",
    "tokenReferenceID",
    "tokenRequestorID",
    "token",
    "panReferenceID",
    "cardholderInfo",
    "cardMetaData"
})
@XmlRootElement(name = "updateCardMetadataReq")
public class UpdateCardMetadataReq {

    @XmlElement(required = true)
    protected String requestID;
    @XmlElement(required = true)
    protected String responseURL;
    protected String operatorID;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected TOperationType operationType;
    @XmlElement(required = true)
    protected String operationReason;
    protected String tokenReferenceID;
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger tokenRequestorID;
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger token;
    protected String panReferenceID;
    protected TCardholderInfo cardholderInfo;
    protected UpdateCardMetadataReq.CardMetaData cardMetaData;

    /**
     * Obtiene el valor de la propiedad requestID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestID() {
        return requestID;
    }

    /**
     * Define el valor de la propiedad requestID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestID(String value) {
        this.requestID = value;
    }

    /**
     * Obtiene el valor de la propiedad responseURL.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseURL() {
        return responseURL;
    }

    /**
     * Define el valor de la propiedad responseURL.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseURL(String value) {
        this.responseURL = value;
    }

    /**
     * Obtiene el valor de la propiedad operatorID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperatorID() {
        return operatorID;
    }

    /**
     * Define el valor de la propiedad operatorID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatorID(String value) {
        this.operatorID = value;
    }

    /**
     * Obtiene el valor de la propiedad operationType.
     * 
     * @return
     *     possible object is
     *     {@link TOperationType }
     *     
     */
    public TOperationType getOperationType() {
        return operationType;
    }

    /**
     * Define el valor de la propiedad operationType.
     * 
     * @param value
     *     allowed object is
     *     {@link TOperationType }
     *     
     */
    public void setOperationType(TOperationType value) {
        this.operationType = value;
    }

    /**
     * Obtiene el valor de la propiedad operationReason.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperationReason() {
        return operationReason;
    }

    /**
     * Define el valor de la propiedad operationReason.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperationReason(String value) {
        this.operationReason = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenReferenceID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTokenReferenceID() {
        return tokenReferenceID;
    }

    /**
     * Define el valor de la propiedad tokenReferenceID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenReferenceID(String value) {
        this.tokenReferenceID = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenRequestorID.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTokenRequestorID() {
        return tokenRequestorID;
    }

    /**
     * Define el valor de la propiedad tokenRequestorID.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTokenRequestorID(BigInteger value) {
        this.tokenRequestorID = value;
    }

    /**
     * Obtiene el valor de la propiedad token.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getToken() {
        return token;
    }

    /**
     * Define el valor de la propiedad token.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setToken(BigInteger value) {
        this.token = value;
    }

    /**
     * Obtiene el valor de la propiedad panReferenceID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanReferenceID() {
        return panReferenceID;
    }

    /**
     * Define el valor de la propiedad panReferenceID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanReferenceID(String value) {
        this.panReferenceID = value;
    }

    /**
     * Obtiene el valor de la propiedad cardholderInfo.
     * 
     * @return
     *     possible object is
     *     {@link TCardholderInfo }
     *     
     */
    public TCardholderInfo getCardholderInfo() {
        return cardholderInfo;
    }

    /**
     * Define el valor de la propiedad cardholderInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link TCardholderInfo }
     *     
     */
    public void setCardholderInfo(TCardholderInfo value) {
        this.cardholderInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad cardMetaData.
     * 
     * @return
     *     possible object is
     *     {@link UpdateCardMetadataReq.CardMetaData }
     *     
     */
    public UpdateCardMetadataReq.CardMetaData getCardMetaData() {
        return cardMetaData;
    }

    /**
     * Define el valor de la propiedad cardMetaData.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateCardMetadataReq.CardMetaData }
     *     
     */
    public void setCardMetaData(UpdateCardMetadataReq.CardMetaData value) {
        this.cardMetaData = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="foreGroundColor" type="{http://vnts.visa.com/tpcas/v1}tForeGroundColorUCMD" minOccurs="0"/>
     *         &lt;element name="backGroundColor" type="{http://vnts.visa.com/tpcas/v1}tBackGroundColorUCMD" minOccurs="0"/>
     *         &lt;element name="labelColor" type="{http://vnts.visa.com/tpcas/v1}tLabelColorUCMD" minOccurs="0"/>
     *         &lt;element name="shortDescription" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="32"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="longDescription" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="64"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="issuerCardArtRefID" maxOccurs="5" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;length value="32"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="contactWebsite" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="128"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="contactEmail" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="32"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="contactNumber" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="32"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="contactName" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="32"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="associatedStoreIdentifiers" maxOccurs="10" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}normalizedString">
     *               &lt;pattern value="[0-9]{1,20}"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="associatedApplicationdentifiers" maxOccurs="10" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="128"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="applaunchURL" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="128"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="applaunchURLScheme" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="32"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="supportsTokenNotification" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
     *         &lt;element name="supportsFPanNotification" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
     *         &lt;element name="transactionServiceURL" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="128"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="transactionPushTopic" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="128"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="privacyPolicyURL" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="128"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="termsAndConditionURL" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="128"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="cardMetadataProfileId" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;length value="32"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="messageServiceURL" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="128"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="messagePushTopic" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="128"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "foreGroundColor",
        "backGroundColor",
        "labelColor",
        "shortDescription",
        "longDescription",
        "issuerCardArtRefID",
        "contactWebsite",
        "contactEmail",
        "contactNumber",
        "contactName",
        "associatedStoreIdentifiers",
        "associatedApplicationdentifiers",
        "applaunchURL",
        "applaunchURLScheme",
        "supportsTokenNotification",
        "supportsFPanNotification",
        "transactionServiceURL",
        "transactionPushTopic",
        "privacyPolicyURL",
        "termsAndConditionURL",
        "cardMetadataProfileId",
        "messageServiceURL",
        "messagePushTopic"
    })
    public static class CardMetaData {

        protected String foreGroundColor;
        protected String backGroundColor;
        protected String labelColor;
        protected String shortDescription;
        protected String longDescription;
        protected List<String> issuerCardArtRefID;
        protected String contactWebsite;
        protected String contactEmail;
        protected String contactNumber;
        protected String contactName;
        @XmlJavaTypeAdapter(NormalizedStringAdapter.class)
        protected List<String> associatedStoreIdentifiers;
        protected List<String> associatedApplicationdentifiers;
        protected String applaunchURL;
        protected String applaunchURLScheme;
        protected Boolean supportsTokenNotification;
        protected Boolean supportsFPanNotification;
        protected String transactionServiceURL;
        protected String transactionPushTopic;
        protected String privacyPolicyURL;
        protected String termsAndConditionURL;
        protected String cardMetadataProfileId;
        protected String messageServiceURL;
        protected String messagePushTopic;

        /**
         * Obtiene el valor de la propiedad foreGroundColor.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getForeGroundColor() {
            return foreGroundColor;
        }

        /**
         * Define el valor de la propiedad foreGroundColor.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setForeGroundColor(String value) {
            this.foreGroundColor = value;
        }

        /**
         * Obtiene el valor de la propiedad backGroundColor.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBackGroundColor() {
            return backGroundColor;
        }

        /**
         * Define el valor de la propiedad backGroundColor.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBackGroundColor(String value) {
            this.backGroundColor = value;
        }

        /**
         * Obtiene el valor de la propiedad labelColor.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLabelColor() {
            return labelColor;
        }

        /**
         * Define el valor de la propiedad labelColor.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLabelColor(String value) {
            this.labelColor = value;
        }

        /**
         * Obtiene el valor de la propiedad shortDescription.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getShortDescription() {
            return shortDescription;
        }

        /**
         * Define el valor de la propiedad shortDescription.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setShortDescription(String value) {
            this.shortDescription = value;
        }

        /**
         * Obtiene el valor de la propiedad longDescription.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLongDescription() {
            return longDescription;
        }

        /**
         * Define el valor de la propiedad longDescription.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLongDescription(String value) {
            this.longDescription = value;
        }

        /**
         * Gets the value of the issuerCardArtRefID property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the issuerCardArtRefID property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getIssuerCardArtRefID().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getIssuerCardArtRefID() {
            if (issuerCardArtRefID == null) {
                issuerCardArtRefID = new ArrayList<String>();
            }
            return this.issuerCardArtRefID;
        }

        /**
         * Obtiene el valor de la propiedad contactWebsite.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getContactWebsite() {
            return contactWebsite;
        }

        /**
         * Define el valor de la propiedad contactWebsite.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setContactWebsite(String value) {
            this.contactWebsite = value;
        }

        /**
         * Obtiene el valor de la propiedad contactEmail.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getContactEmail() {
            return contactEmail;
        }

        /**
         * Define el valor de la propiedad contactEmail.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setContactEmail(String value) {
            this.contactEmail = value;
        }

        /**
         * Obtiene el valor de la propiedad contactNumber.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getContactNumber() {
            return contactNumber;
        }

        /**
         * Define el valor de la propiedad contactNumber.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setContactNumber(String value) {
            this.contactNumber = value;
        }

        /**
         * Obtiene el valor de la propiedad contactName.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getContactName() {
            return contactName;
        }

        /**
         * Define el valor de la propiedad contactName.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setContactName(String value) {
            this.contactName = value;
        }

        /**
         * Gets the value of the associatedStoreIdentifiers property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the associatedStoreIdentifiers property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAssociatedStoreIdentifiers().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getAssociatedStoreIdentifiers() {
            if (associatedStoreIdentifiers == null) {
                associatedStoreIdentifiers = new ArrayList<String>();
            }
            return this.associatedStoreIdentifiers;
        }

        /**
         * Gets the value of the associatedApplicationdentifiers property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the associatedApplicationdentifiers property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAssociatedApplicationdentifiers().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getAssociatedApplicationdentifiers() {
            if (associatedApplicationdentifiers == null) {
                associatedApplicationdentifiers = new ArrayList<String>();
            }
            return this.associatedApplicationdentifiers;
        }

        /**
         * Obtiene el valor de la propiedad applaunchURL.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getApplaunchURL() {
            return applaunchURL;
        }

        /**
         * Define el valor de la propiedad applaunchURL.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setApplaunchURL(String value) {
            this.applaunchURL = value;
        }

        /**
         * Obtiene el valor de la propiedad applaunchURLScheme.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getApplaunchURLScheme() {
            return applaunchURLScheme;
        }

        /**
         * Define el valor de la propiedad applaunchURLScheme.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setApplaunchURLScheme(String value) {
            this.applaunchURLScheme = value;
        }

        /**
         * Obtiene el valor de la propiedad supportsTokenNotification.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isSupportsTokenNotification() {
            return supportsTokenNotification;
        }

        /**
         * Define el valor de la propiedad supportsTokenNotification.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setSupportsTokenNotification(Boolean value) {
            this.supportsTokenNotification = value;
        }

        /**
         * Obtiene el valor de la propiedad supportsFPanNotification.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isSupportsFPanNotification() {
            return supportsFPanNotification;
        }

        /**
         * Define el valor de la propiedad supportsFPanNotification.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setSupportsFPanNotification(Boolean value) {
            this.supportsFPanNotification = value;
        }

        /**
         * Obtiene el valor de la propiedad transactionServiceURL.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTransactionServiceURL() {
            return transactionServiceURL;
        }

        /**
         * Define el valor de la propiedad transactionServiceURL.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTransactionServiceURL(String value) {
            this.transactionServiceURL = value;
        }

        /**
         * Obtiene el valor de la propiedad transactionPushTopic.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTransactionPushTopic() {
            return transactionPushTopic;
        }

        /**
         * Define el valor de la propiedad transactionPushTopic.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTransactionPushTopic(String value) {
            this.transactionPushTopic = value;
        }

        /**
         * Obtiene el valor de la propiedad privacyPolicyURL.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPrivacyPolicyURL() {
            return privacyPolicyURL;
        }

        /**
         * Define el valor de la propiedad privacyPolicyURL.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPrivacyPolicyURL(String value) {
            this.privacyPolicyURL = value;
        }

        /**
         * Obtiene el valor de la propiedad termsAndConditionURL.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTermsAndConditionURL() {
            return termsAndConditionURL;
        }

        /**
         * Define el valor de la propiedad termsAndConditionURL.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTermsAndConditionURL(String value) {
            this.termsAndConditionURL = value;
        }

        /**
         * Obtiene el valor de la propiedad cardMetadataProfileId.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCardMetadataProfileId() {
            return cardMetadataProfileId;
        }

        /**
         * Define el valor de la propiedad cardMetadataProfileId.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCardMetadataProfileId(String value) {
            this.cardMetadataProfileId = value;
        }

        /**
         * Obtiene el valor de la propiedad messageServiceURL.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMessageServiceURL() {
            return messageServiceURL;
        }

        /**
         * Define el valor de la propiedad messageServiceURL.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMessageServiceURL(String value) {
            this.messageServiceURL = value;
        }

        /**
         * Obtiene el valor de la propiedad messagePushTopic.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMessagePushTopic() {
            return messagePushTopic;
        }

        /**
         * Define el valor de la propiedad messagePushTopic.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMessagePushTopic(String value) {
            this.messagePushTopic = value;
        }

    }

}
