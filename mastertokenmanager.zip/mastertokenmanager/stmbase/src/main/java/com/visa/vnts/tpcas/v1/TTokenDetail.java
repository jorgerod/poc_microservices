
package com.visa.vnts.tpcas.v1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.HexBinaryAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para tTokenDetail complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="tTokenDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="token" type="{http://vnts.visa.com/tpcas/v1}tDPan" minOccurs="0"/>
 *         &lt;element name="panReferenceID" type="{http://vnts.visa.com/tpcas/v1}tPanReferenceID" minOccurs="0"/>
 *         &lt;element name="tokenReferenceID" type="{http://vnts.visa.com/tpcas/v1}tTokenReferenceID" minOccurs="0"/>
 *         &lt;element name="tokenRequestorID" type="{http://vnts.visa.com/tpcas/v1}tTokenRequestorID" minOccurs="0"/>
 *         &lt;element name="tokenRequestorName" type="{http://vnts.visa.com/tpcas/v1}tTokenRequestorName" minOccurs="0"/>
 *         &lt;element name="walletAccountID" type="{http://vnts.visa.com/tpcas/v1}tOptionalString32" minOccurs="0"/>
 *         &lt;element name="walletEmailAddress" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}hexBinary">
 *               &lt;maxLength value="64"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="tokenAssuranceLevel" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;length value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="tokenExpiration" type="{http://www.w3.org/2001/XMLSchema}gYearMonth" minOccurs="0"/>
 *         &lt;element name="tokenState" type="{http://vnts.visa.com/tpcas/v1}tTokenStatus" minOccurs="0"/>
 *         &lt;element name="tokenType" type="{http://vnts.visa.com/tpcas/v1}tTokenType" minOccurs="0"/>
 *         &lt;element name="deActivationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="lastTokenStatusUpdatedTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="entityOfLastAction" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="11"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="operatorID" type="{http://vnts.visa.com/tpcas/v1}tOtionalOperatorID" minOccurs="0"/>
 *         &lt;element name="deviceInformation" type="{http://vnts.visa.com/tpcas/v1}deviceInformationWithSNo" minOccurs="0"/>
 *         &lt;element name="otpCodeIndicator" type="{http://vnts.visa.com/tpcas/v1}tOTPCodeIndicator" minOccurs="0"/>
 *         &lt;element name="otpCodeExpiration" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}dateTime">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="otpVerificationAttempts" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger">
 *               &lt;totalDigits value="3"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="otpVerificationRetryCounts" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger">
 *               &lt;totalDigits value="3"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="riskInformation" type="{http://vnts.visa.com/tpcas/v1}tRiskInformation" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tTokenDetail", propOrder = {
    "token",
    "panReferenceID",
    "tokenReferenceID",
    "tokenRequestorID",
    "tokenRequestorName",
    "walletAccountID",
    "walletEmailAddress",
    "tokenAssuranceLevel",
    "tokenExpiration",
    "tokenState",
    "tokenType",
    "deActivationDate",
    "lastTokenStatusUpdatedTime",
    "entityOfLastAction",
    "operatorID",
    "deviceInformation",
    "otpCodeIndicator",
    "otpCodeExpiration",
    "otpVerificationAttempts",
    "otpVerificationRetryCounts",
    "riskInformation"
})
public class TTokenDetail {

    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger token;
    protected String panReferenceID;
    protected String tokenReferenceID;
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger tokenRequestorID;
    protected String tokenRequestorName;
    protected String walletAccountID;
    @XmlElement(type = String.class)
    @XmlJavaTypeAdapter(HexBinaryAdapter.class)
    protected byte[] walletEmailAddress;
    protected String tokenAssuranceLevel;
    @XmlSchemaType(name = "gYearMonth")
    protected XMLGregorianCalendar tokenExpiration;
    protected String tokenState;
    protected String tokenType;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar deActivationDate;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastTokenStatusUpdatedTime;
    protected String entityOfLastAction;
    protected String operatorID;
    protected DeviceInformationWithSNo deviceInformation;
    protected String otpCodeIndicator;
    protected XMLGregorianCalendar otpCodeExpiration;
    protected BigInteger otpVerificationAttempts;
    protected BigInteger otpVerificationRetryCounts;
    protected TRiskInformation riskInformation;

    /**
     * Obtiene el valor de la propiedad token.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getToken() {
        return token;
    }

    /**
     * Define el valor de la propiedad token.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setToken(BigInteger value) {
        this.token = value;
    }

    /**
     * Obtiene el valor de la propiedad panReferenceID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanReferenceID() {
        return panReferenceID;
    }

    /**
     * Define el valor de la propiedad panReferenceID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanReferenceID(String value) {
        this.panReferenceID = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenReferenceID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTokenReferenceID() {
        return tokenReferenceID;
    }

    /**
     * Define el valor de la propiedad tokenReferenceID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenReferenceID(String value) {
        this.tokenReferenceID = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenRequestorID.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTokenRequestorID() {
        return tokenRequestorID;
    }

    /**
     * Define el valor de la propiedad tokenRequestorID.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTokenRequestorID(BigInteger value) {
        this.tokenRequestorID = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenRequestorName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTokenRequestorName() {
        return tokenRequestorName;
    }

    /**
     * Define el valor de la propiedad tokenRequestorName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenRequestorName(String value) {
        this.tokenRequestorName = value;
    }

    /**
     * Obtiene el valor de la propiedad walletAccountID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWalletAccountID() {
        return walletAccountID;
    }

    /**
     * Define el valor de la propiedad walletAccountID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWalletAccountID(String value) {
        this.walletAccountID = value;
    }

    /**
     * Obtiene el valor de la propiedad walletEmailAddress.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public byte[] getWalletEmailAddress() {
        return walletEmailAddress;
    }

    /**
     * Define el valor de la propiedad walletEmailAddress.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWalletEmailAddress(byte[] value) {
        this.walletEmailAddress = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenAssuranceLevel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTokenAssuranceLevel() {
        return tokenAssuranceLevel;
    }

    /**
     * Define el valor de la propiedad tokenAssuranceLevel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenAssuranceLevel(String value) {
        this.tokenAssuranceLevel = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenExpiration.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTokenExpiration() {
        return tokenExpiration;
    }

    /**
     * Define el valor de la propiedad tokenExpiration.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTokenExpiration(XMLGregorianCalendar value) {
        this.tokenExpiration = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenState.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTokenState() {
        return tokenState;
    }

    /**
     * Define el valor de la propiedad tokenState.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenState(String value) {
        this.tokenState = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTokenType() {
        return tokenType;
    }

    /**
     * Define el valor de la propiedad tokenType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenType(String value) {
        this.tokenType = value;
    }

    /**
     * Obtiene el valor de la propiedad deActivationDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDeActivationDate() {
        return deActivationDate;
    }

    /**
     * Define el valor de la propiedad deActivationDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDeActivationDate(XMLGregorianCalendar value) {
        this.deActivationDate = value;
    }

    /**
     * Obtiene el valor de la propiedad lastTokenStatusUpdatedTime.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastTokenStatusUpdatedTime() {
        return lastTokenStatusUpdatedTime;
    }

    /**
     * Define el valor de la propiedad lastTokenStatusUpdatedTime.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastTokenStatusUpdatedTime(XMLGregorianCalendar value) {
        this.lastTokenStatusUpdatedTime = value;
    }

    /**
     * Obtiene el valor de la propiedad entityOfLastAction.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEntityOfLastAction() {
        return entityOfLastAction;
    }

    /**
     * Define el valor de la propiedad entityOfLastAction.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEntityOfLastAction(String value) {
        this.entityOfLastAction = value;
    }

    /**
     * Obtiene el valor de la propiedad operatorID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperatorID() {
        return operatorID;
    }

    /**
     * Define el valor de la propiedad operatorID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatorID(String value) {
        this.operatorID = value;
    }

    /**
     * Obtiene el valor de la propiedad deviceInformation.
     * 
     * @return
     *     possible object is
     *     {@link DeviceInformationWithSNo }
     *     
     */
    public DeviceInformationWithSNo getDeviceInformation() {
        return deviceInformation;
    }

    /**
     * Define el valor de la propiedad deviceInformation.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceInformationWithSNo }
     *     
     */
    public void setDeviceInformation(DeviceInformationWithSNo value) {
        this.deviceInformation = value;
    }

    /**
     * Obtiene el valor de la propiedad otpCodeIndicator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtpCodeIndicator() {
        return otpCodeIndicator;
    }

    /**
     * Define el valor de la propiedad otpCodeIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtpCodeIndicator(String value) {
        this.otpCodeIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad otpCodeExpiration.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getOtpCodeExpiration() {
        return otpCodeExpiration;
    }

    /**
     * Define el valor de la propiedad otpCodeExpiration.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setOtpCodeExpiration(XMLGregorianCalendar value) {
        this.otpCodeExpiration = value;
    }

    /**
     * Obtiene el valor de la propiedad otpVerificationAttempts.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getOtpVerificationAttempts() {
        return otpVerificationAttempts;
    }

    /**
     * Define el valor de la propiedad otpVerificationAttempts.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setOtpVerificationAttempts(BigInteger value) {
        this.otpVerificationAttempts = value;
    }

    /**
     * Obtiene el valor de la propiedad otpVerificationRetryCounts.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getOtpVerificationRetryCounts() {
        return otpVerificationRetryCounts;
    }

    /**
     * Define el valor de la propiedad otpVerificationRetryCounts.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setOtpVerificationRetryCounts(BigInteger value) {
        this.otpVerificationRetryCounts = value;
    }

    /**
     * Obtiene el valor de la propiedad riskInformation.
     * 
     * @return
     *     possible object is
     *     {@link TRiskInformation }
     *     
     */
    public TRiskInformation getRiskInformation() {
        return riskInformation;
    }

    /**
     * Define el valor de la propiedad riskInformation.
     * 
     * @param value
     *     allowed object is
     *     {@link TRiskInformation }
     *     
     */
    public void setRiskInformation(TRiskInformation value) {
        this.riskInformation = value;
    }

}
