
package com.visa.vnts.tpcas.v1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.visa.vnts.tpcas.v1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DeviceNumber_QNAME = new QName("http://vnts.visa.com/tpcas/v1", "deviceNumber");
    private final static QName _DeviceName_QNAME = new QName("http://vnts.visa.com/tpcas/v1", "deviceName");
    private final static QName _SecureElementID_QNAME = new QName("http://vnts.visa.com/tpcas/v1", "secureElementID");
    private final static QName _DeviceType_QNAME = new QName("http://vnts.visa.com/tpcas/v1", "deviceType");
    private final static QName _SerialNumber_QNAME = new QName("http://vnts.visa.com/tpcas/v1", "serialNumber");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.visa.vnts.tpcas.v1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UpdateCardMetadataReq }
     * 
     */
    public UpdateCardMetadataReq createUpdateCardMetadataReq() {
        return new UpdateCardMetadataReq();
    }

    /**
     * Create an instance of {@link UpdateCardMetadataRes }
     * 
     */
    public UpdateCardMetadataRes createUpdateCardMetadataRes() {
        return new UpdateCardMetadataRes();
    }

    /**
     * Create an instance of {@link MessageServiceRes }
     * 
     */
    public MessageServiceRes createMessageServiceRes() {
        return new MessageServiceRes();
    }

    /**
     * Create an instance of {@link MessageServiceReq }
     * 
     */
    public MessageServiceReq createMessageServiceReq() {
        return new MessageServiceReq();
    }

    /**
     * Create an instance of {@link MessageServiceReq.RequestDetails }
     * 
     */
    public MessageServiceReq.RequestDetails createMessageServiceReqRequestDetails() {
        return new MessageServiceReq.RequestDetails();
    }

    /**
     * Create an instance of {@link TCardMetaData }
     * 
     */
    public TCardMetaData createTCardMetaData() {
        return new TCardMetaData();
    }

    /**
     * Create an instance of {@link GetCardHolderVerificationMethodsRes }
     * 
     */
    public GetCardHolderVerificationMethodsRes createGetCardHolderVerificationMethodsRes() {
        return new GetCardHolderVerificationMethodsRes();
    }

    /**
     * Create an instance of {@link TCardholderVerificationMethod }
     * 
     */
    public TCardholderVerificationMethod createTCardholderVerificationMethod() {
        return new TCardholderVerificationMethod();
    }

    /**
     * Create an instance of {@link TokenInquiryRes }
     * 
     */
    public TokenInquiryRes createTokenInquiryRes() {
        return new TokenInquiryRes();
    }

    /**
     * Create an instance of {@link TTokenDetail }
     * 
     */
    public TTokenDetail createTTokenDetail() {
        return new TTokenDetail();
    }

    /**
     * Create an instance of {@link GetCardHolderVerificationMethodsReq }
     * 
     */
    public GetCardHolderVerificationMethodsReq createGetCardHolderVerificationMethodsReq() {
        return new GetCardHolderVerificationMethodsReq();
    }

    /**
     * Create an instance of {@link TWalletProviderMsgTracingOpt }
     * 
     */
    public TWalletProviderMsgTracingOpt createTWalletProviderMsgTracingOpt() {
        return new TWalletProviderMsgTracingOpt();
    }

    /**
     * Create an instance of {@link DeviceInformation }
     * 
     */
    public DeviceInformation createDeviceInformation() {
        return new DeviceInformation();
    }

    /**
     * Create an instance of {@link TCardholderInfo }
     * 
     */
    public TCardholderInfo createTCardholderInfo() {
        return new TCardholderInfo();
    }

    /**
     * Create an instance of {@link TRiskInformationCommon }
     * 
     */
    public TRiskInformationCommon createTRiskInformationCommon() {
        return new TRiskInformationCommon();
    }

    /**
     * Create an instance of {@link TokenInquiryReq }
     * 
     */
    public TokenInquiryReq createTokenInquiryReq() {
        return new TokenInquiryReq();
    }

    /**
     * Create an instance of {@link PingRequest }
     * 
     */
    public PingRequest createPingRequest() {
        return new PingRequest();
    }

    /**
     * Create an instance of {@link SendPasscodeRes }
     * 
     */
    public SendPasscodeRes createSendPasscodeRes() {
        return new SendPasscodeRes();
    }

    /**
     * Create an instance of {@link SendPasscodeReq }
     * 
     */
    public SendPasscodeReq createSendPasscodeReq() {
        return new SendPasscodeReq();
    }

    /**
     * Create an instance of {@link SubmitLifeCycleCommandReq }
     * 
     */
    public SubmitLifeCycleCommandReq createSubmitLifeCycleCommandReq() {
        return new SubmitLifeCycleCommandReq();
    }

    /**
     * Create an instance of {@link CardMetadataUpdateNotification }
     * 
     */
    public CardMetadataUpdateNotification createCardMetadataUpdateNotification() {
        return new CardMetadataUpdateNotification();
    }

    /**
     * Create an instance of {@link SubmitLifeCycleCommandRes }
     * 
     */
    public SubmitLifeCycleCommandRes createSubmitLifeCycleCommandRes() {
        return new SubmitLifeCycleCommandRes();
    }

    /**
     * Create an instance of {@link MessageUpdateNotification }
     * 
     */
    public MessageUpdateNotification createMessageUpdateNotification() {
        return new MessageUpdateNotification();
    }

    /**
     * Create an instance of {@link CheckEligibilityRes }
     * 
     */
    public CheckEligibilityRes createCheckEligibilityRes() {
        return new CheckEligibilityRes();
    }

    /**
     * Create an instance of {@link CheckEligibilityReq }
     * 
     */
    public CheckEligibilityReq createCheckEligibilityReq() {
        return new CheckEligibilityReq();
    }

    /**
     * Create an instance of {@link TWalletProviderMsgTracing }
     * 
     */
    public TWalletProviderMsgTracing createTWalletProviderMsgTracing() {
        return new TWalletProviderMsgTracing();
    }

    /**
     * Create an instance of {@link DeviceInfo }
     * 
     */
    public DeviceInfo createDeviceInfo() {
        return new DeviceInfo();
    }

    /**
     * Create an instance of {@link UpdateCardMetadataReq.CardMetaData }
     * 
     */
    public UpdateCardMetadataReq.CardMetaData createUpdateCardMetadataReqCardMetaData() {
        return new UpdateCardMetadataReq.CardMetaData();
    }

    /**
     * Create an instance of {@link UpdateCardMetadataRes.TokenDetails }
     * 
     */
    public UpdateCardMetadataRes.TokenDetails createUpdateCardMetadataResTokenDetails() {
        return new UpdateCardMetadataRes.TokenDetails();
    }

    /**
     * Create an instance of {@link PingResponse }
     * 
     */
    public PingResponse createPingResponse() {
        return new PingResponse();
    }

    /**
     * Create an instance of {@link MessageServiceRes.ResponseDetails }
     * 
     */
    public MessageServiceRes.ResponseDetails createMessageServiceResResponseDetails() {
        return new MessageServiceRes.ResponseDetails();
    }

    /**
     * Create an instance of {@link TUCardholderInfo }
     * 
     */
    public TUCardholderInfo createTUCardholderInfo() {
        return new TUCardholderInfo();
    }

    /**
     * Create an instance of {@link DeviceInformationWithSNo }
     * 
     */
    public DeviceInformationWithSNo createDeviceInformationWithSNo() {
        return new DeviceInformationWithSNo();
    }

    /**
     * Create an instance of {@link TRiskInformation }
     * 
     */
    public TRiskInformation createTRiskInformation() {
        return new TRiskInformation();
    }

    /**
     * Create an instance of {@link MessageServiceReq.RequestDetails.ContentDetails }
     * 
     */
    public MessageServiceReq.RequestDetails.ContentDetails createMessageServiceReqRequestDetailsContentDetails() {
        return new MessageServiceReq.RequestDetails.ContentDetails();
    }

    /**
     * Create an instance of {@link TCardMetaData.CardArt }
     * 
     */
    public TCardMetaData.CardArt createTCardMetaDataCardArt() {
        return new TCardMetaData.CardArt();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vnts.visa.com/tpcas/v1", name = "deviceNumber")
    public JAXBElement<String> createDeviceNumber(String value) {
        return new JAXBElement<String>(_DeviceNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vnts.visa.com/tpcas/v1", name = "deviceName")
    public JAXBElement<String> createDeviceName(String value) {
        return new JAXBElement<String>(_DeviceName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vnts.visa.com/tpcas/v1", name = "secureElementID")
    public JAXBElement<String> createSecureElementID(String value) {
        return new JAXBElement<String>(_SecureElementID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vnts.visa.com/tpcas/v1", name = "deviceType")
    public JAXBElement<String> createDeviceType(String value) {
        return new JAXBElement<String>(_DeviceType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vnts.visa.com/tpcas/v1", name = "serialNumber")
    public JAXBElement<String> createSerialNumber(String value) {
        return new JAXBElement<String>(_SerialNumber_QNAME, String.class, null, value);
    }

}
