
package com.visa.vnts.tpcas.v1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="walletProviderMsgTracing" type="{http://vnts.visa.com/tpcas/v1}tWalletProviderMsgTracingOpt"/>
 *         &lt;element name="walletAccountID" type="{http://vnts.visa.com/tpcas/v1}tOptionalString32" minOccurs="0"/>
 *         &lt;element name="lifeCycleTraceID" type="{http://vnts.visa.com/tpcas/v1}tLifeCycleTraceID"/>
 *         &lt;element name="tokenReferenceID" type="{http://vnts.visa.com/tpcas/v1}tTokenReferenceID" minOccurs="0"/>
 *         &lt;element name="panReferenceID" type="{http://vnts.visa.com/tpcas/v1}tPanReferenceID" minOccurs="0"/>
 *         &lt;element name="token" type="{http://vnts.visa.com/tpcas/v1}tDPan" minOccurs="0"/>
 *         &lt;element name="deviceInfo" type="{http://vnts.visa.com/tpcas/v1}deviceInformation" minOccurs="0"/>
 *         &lt;element name="otpReason" type="{http://vnts.visa.com/tpcas/v1}tOTPReason"/>
 *         &lt;element name="otpMaxReached" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="cardholderInfo" type="{http://vnts.visa.com/tpcas/v1}tCardholderInfo" minOccurs="0"/>
 *         &lt;element name="riskInformation" type="{http://vnts.visa.com/tpcas/v1}tRiskInformationCommon" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "walletProviderMsgTracing",
    "walletAccountID",
    "lifeCycleTraceID",
    "tokenReferenceID",
    "panReferenceID",
    "token",
    "deviceInfo",
    "otpReason",
    "otpMaxReached",
    "cardholderInfo",
    "riskInformation"
})
@XmlRootElement(name = "getCardHolderVerificationMethodsReq")
public class GetCardHolderVerificationMethodsReq {

    @XmlElement(required = true)
    protected TWalletProviderMsgTracingOpt walletProviderMsgTracing;
    protected String walletAccountID;
    @XmlElement(required = true)
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger lifeCycleTraceID;
    protected String tokenReferenceID;
    protected String panReferenceID;
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger token;
    protected DeviceInformation deviceInfo;
    @XmlElement(required = true)
    protected String otpReason;
    protected Boolean otpMaxReached;
    protected TCardholderInfo cardholderInfo;
    protected TRiskInformationCommon riskInformation;

    /**
     * Obtiene el valor de la propiedad walletProviderMsgTracing.
     * 
     * @return
     *     possible object is
     *     {@link TWalletProviderMsgTracingOpt }
     *     
     */
    public TWalletProviderMsgTracingOpt getWalletProviderMsgTracing() {
        return walletProviderMsgTracing;
    }

    /**
     * Define el valor de la propiedad walletProviderMsgTracing.
     * 
     * @param value
     *     allowed object is
     *     {@link TWalletProviderMsgTracingOpt }
     *     
     */
    public void setWalletProviderMsgTracing(TWalletProviderMsgTracingOpt value) {
        this.walletProviderMsgTracing = value;
    }

    /**
     * Obtiene el valor de la propiedad walletAccountID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWalletAccountID() {
        return walletAccountID;
    }

    /**
     * Define el valor de la propiedad walletAccountID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWalletAccountID(String value) {
        this.walletAccountID = value;
    }

    /**
     * Obtiene el valor de la propiedad lifeCycleTraceID.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getLifeCycleTraceID() {
        return lifeCycleTraceID;
    }

    /**
     * Define el valor de la propiedad lifeCycleTraceID.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setLifeCycleTraceID(BigInteger value) {
        this.lifeCycleTraceID = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenReferenceID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTokenReferenceID() {
        return tokenReferenceID;
    }

    /**
     * Define el valor de la propiedad tokenReferenceID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenReferenceID(String value) {
        this.tokenReferenceID = value;
    }

    /**
     * Obtiene el valor de la propiedad panReferenceID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanReferenceID() {
        return panReferenceID;
    }

    /**
     * Define el valor de la propiedad panReferenceID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanReferenceID(String value) {
        this.panReferenceID = value;
    }

    /**
     * Obtiene el valor de la propiedad token.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getToken() {
        return token;
    }

    /**
     * Define el valor de la propiedad token.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setToken(BigInteger value) {
        this.token = value;
    }

    /**
     * Obtiene el valor de la propiedad deviceInfo.
     * 
     * @return
     *     possible object is
     *     {@link DeviceInformation }
     *     
     */
    public DeviceInformation getDeviceInfo() {
        return deviceInfo;
    }

    /**
     * Define el valor de la propiedad deviceInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceInformation }
     *     
     */
    public void setDeviceInfo(DeviceInformation value) {
        this.deviceInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad otpReason.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtpReason() {
        return otpReason;
    }

    /**
     * Define el valor de la propiedad otpReason.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtpReason(String value) {
        this.otpReason = value;
    }

    /**
     * Obtiene el valor de la propiedad otpMaxReached.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isOtpMaxReached() {
        return otpMaxReached;
    }

    /**
     * Define el valor de la propiedad otpMaxReached.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setOtpMaxReached(Boolean value) {
        this.otpMaxReached = value;
    }

    /**
     * Obtiene el valor de la propiedad cardholderInfo.
     * 
     * @return
     *     possible object is
     *     {@link TCardholderInfo }
     *     
     */
    public TCardholderInfo getCardholderInfo() {
        return cardholderInfo;
    }

    /**
     * Define el valor de la propiedad cardholderInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link TCardholderInfo }
     *     
     */
    public void setCardholderInfo(TCardholderInfo value) {
        this.cardholderInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad riskInformation.
     * 
     * @return
     *     possible object is
     *     {@link TRiskInformationCommon }
     *     
     */
    public TRiskInformationCommon getRiskInformation() {
        return riskInformation;
    }

    /**
     * Define el valor de la propiedad riskInformation.
     * 
     * @param value
     *     allowed object is
     *     {@link TRiskInformationCommon }
     *     
     */
    public void setRiskInformation(TRiskInformationCommon value) {
        this.riskInformation = value;
    }

}
