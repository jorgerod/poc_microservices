
package com.visa.vnts.tpcas.v1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para tWalletProviderMsgTracing complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="tWalletProviderMsgTracing">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="tokenRequestorID" type="{http://vnts.visa.com/tpcas/v1}tTokenRequestorID"/>
 *         &lt;element name="wpRequestId" type="{http://vnts.visa.com/tpcas/v1}tWPRequestId"/>
 *         &lt;element name="wpConversationId" type="{http://vnts.visa.com/tpcas/v1}tWPConversationId"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tWalletProviderMsgTracing", propOrder = {
    "tokenRequestorID",
    "wpRequestId",
    "wpConversationId"
})
public class TWalletProviderMsgTracing {

    @XmlElement(required = true)
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger tokenRequestorID;
    @XmlElement(required = true)
    protected String wpRequestId;
    @XmlElement(required = true)
    protected String wpConversationId;

    /**
     * Obtiene el valor de la propiedad tokenRequestorID.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTokenRequestorID() {
        return tokenRequestorID;
    }

    /**
     * Define el valor de la propiedad tokenRequestorID.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTokenRequestorID(BigInteger value) {
        this.tokenRequestorID = value;
    }

    /**
     * Obtiene el valor de la propiedad wpRequestId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWpRequestId() {
        return wpRequestId;
    }

    /**
     * Define el valor de la propiedad wpRequestId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWpRequestId(String value) {
        this.wpRequestId = value;
    }

    /**
     * Obtiene el valor de la propiedad wpConversationId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWpConversationId() {
        return wpConversationId;
    }

    /**
     * Define el valor de la propiedad wpConversationId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWpConversationId(String value) {
        this.wpConversationId = value;
    }

}
