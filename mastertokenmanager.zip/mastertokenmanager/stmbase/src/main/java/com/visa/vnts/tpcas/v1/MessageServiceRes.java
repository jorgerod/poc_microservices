
package com.visa.vnts.tpcas.v1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="requestID" type="{http://vnts.visa.com/tpcas/v1}tURequestID"/>
 *         &lt;element name="responseDetails" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="taskId" type="{http://vnts.visa.com/tpcas/v1}tURequestID"/>
 *                   &lt;element name="messageId" type="{http://vnts.visa.com/tpcas/v1}tMessageID"/>
 *                   &lt;element name="tokenReferenceID" type="{http://vnts.visa.com/tpcas/v1}tOptionalTokenReferenceID" minOccurs="0"/>
 *                   &lt;element name="tokenRequestorID" type="{http://vnts.visa.com/tpcas/v1}tTokenRequestorID" minOccurs="0"/>
 *                   &lt;element name="token" type="{http://vnts.visa.com/tpcas/v1}tDPan" minOccurs="0"/>
 *                   &lt;element name="tokenState" type="{http://vnts.visa.com/tpcas/v1}tTokenStatus" minOccurs="0"/>
 *                   &lt;element name="actionCode" type="{http://vnts.visa.com/tpcas/v1}tActionCodeC"/>
 *                   &lt;element name="errorCode" type="{http://vnts.visa.com/tpcas/v1}tErrorCode" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "requestID",
    "responseDetails"
})
@XmlRootElement(name = "messageServiceRes")
public class MessageServiceRes {

    @XmlElement(required = true)
    protected String requestID;
    protected MessageServiceRes.ResponseDetails responseDetails;

    /**
     * Obtiene el valor de la propiedad requestID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestID() {
        return requestID;
    }

    /**
     * Define el valor de la propiedad requestID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestID(String value) {
        this.requestID = value;
    }

    /**
     * Obtiene el valor de la propiedad responseDetails.
     * 
     * @return
     *     possible object is
     *     {@link MessageServiceRes.ResponseDetails }
     *     
     */
    public MessageServiceRes.ResponseDetails getResponseDetails() {
        return responseDetails;
    }

    /**
     * Define el valor de la propiedad responseDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageServiceRes.ResponseDetails }
     *     
     */
    public void setResponseDetails(MessageServiceRes.ResponseDetails value) {
        this.responseDetails = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="taskId" type="{http://vnts.visa.com/tpcas/v1}tURequestID"/>
     *         &lt;element name="messageId" type="{http://vnts.visa.com/tpcas/v1}tMessageID"/>
     *         &lt;element name="tokenReferenceID" type="{http://vnts.visa.com/tpcas/v1}tOptionalTokenReferenceID" minOccurs="0"/>
     *         &lt;element name="tokenRequestorID" type="{http://vnts.visa.com/tpcas/v1}tTokenRequestorID" minOccurs="0"/>
     *         &lt;element name="token" type="{http://vnts.visa.com/tpcas/v1}tDPan" minOccurs="0"/>
     *         &lt;element name="tokenState" type="{http://vnts.visa.com/tpcas/v1}tTokenStatus" minOccurs="0"/>
     *         &lt;element name="actionCode" type="{http://vnts.visa.com/tpcas/v1}tActionCodeC"/>
     *         &lt;element name="errorCode" type="{http://vnts.visa.com/tpcas/v1}tErrorCode" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "taskId",
        "messageId",
        "tokenReferenceID",
        "tokenRequestorID",
        "token",
        "tokenState",
        "actionCode",
        "errorCode"
    })
    public static class ResponseDetails {

        @XmlElement(required = true)
        protected String taskId;
        @XmlElement(required = true)
        protected String messageId;
        protected String tokenReferenceID;
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger tokenRequestorID;
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger token;
        protected String tokenState;
        @XmlElement(required = true)
        protected String actionCode;
        protected String errorCode;

        /**
         * Obtiene el valor de la propiedad taskId.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTaskId() {
            return taskId;
        }

        /**
         * Define el valor de la propiedad taskId.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTaskId(String value) {
            this.taskId = value;
        }

        /**
         * Obtiene el valor de la propiedad messageId.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMessageId() {
            return messageId;
        }

        /**
         * Define el valor de la propiedad messageId.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMessageId(String value) {
            this.messageId = value;
        }

        /**
         * Obtiene el valor de la propiedad tokenReferenceID.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTokenReferenceID() {
            return tokenReferenceID;
        }

        /**
         * Define el valor de la propiedad tokenReferenceID.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTokenReferenceID(String value) {
            this.tokenReferenceID = value;
        }

        /**
         * Obtiene el valor de la propiedad tokenRequestorID.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getTokenRequestorID() {
            return tokenRequestorID;
        }

        /**
         * Define el valor de la propiedad tokenRequestorID.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setTokenRequestorID(BigInteger value) {
            this.tokenRequestorID = value;
        }

        /**
         * Obtiene el valor de la propiedad token.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getToken() {
            return token;
        }

        /**
         * Define el valor de la propiedad token.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setToken(BigInteger value) {
            this.token = value;
        }

        /**
         * Obtiene el valor de la propiedad tokenState.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTokenState() {
            return tokenState;
        }

        /**
         * Define el valor de la propiedad tokenState.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTokenState(String value) {
            this.tokenState = value;
        }

        /**
         * Obtiene el valor de la propiedad actionCode.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getActionCode() {
            return actionCode;
        }

        /**
         * Define el valor de la propiedad actionCode.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setActionCode(String value) {
            this.actionCode = value;
        }

        /**
         * Obtiene el valor de la propiedad errorCode.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getErrorCode() {
            return errorCode;
        }

        /**
         * Define el valor de la propiedad errorCode.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setErrorCode(String value) {
            this.errorCode = value;
        }

    }

}
