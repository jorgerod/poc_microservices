
package com.visa.vnts.tpcas.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para tVerificationMethods.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="tVerificationMethods">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="cell_phone"/>
 *     &lt;enumeration value="email"/>
 *     &lt;enumeration value="bank_app"/>
 *     &lt;enumeration value="customer_service"/>
 *     &lt;enumeration value="outbound_call"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "tVerificationMethods")
@XmlEnum
public enum TVerificationMethods {

    @XmlEnumValue("cell_phone")
    CELL_PHONE("cell_phone"),
    @XmlEnumValue("email")
    EMAIL("email"),
    @XmlEnumValue("bank_app")
    BANK_APP("bank_app"),
    @XmlEnumValue("customer_service")
    CUSTOMER_SERVICE("customer_service"),
    @XmlEnumValue("outbound_call")
    OUTBOUND_CALL("outbound_call");
    private final String value;

    TVerificationMethods(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TVerificationMethods fromValue(String v) {
        for (TVerificationMethods c: TVerificationMethods.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
