
package com.visa.vnts.tpcas.v1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="walletProviderMsgTracing" type="{http://vnts.visa.com/tpcas/v1}tWalletProviderMsgTracing"/>
 *         &lt;element name="lifeCycleTraceID" type="{http://vnts.visa.com/tpcas/v1}tLifeCycleTraceID"/>
 *         &lt;element name="tokenReferenceID" type="{http://vnts.visa.com/tpcas/v1}tTokenReferenceID"/>
 *         &lt;element name="panReferenceID" type="{http://vnts.visa.com/tpcas/v1}tPanReferenceID" minOccurs="0"/>
 *         &lt;element name="panSource" type="{http://vnts.visa.com/tpcas/v1}tPanEntryMode"/>
 *         &lt;element name="riskAssessmentScore" type="{http://vnts.visa.com/tpcas/v1}tRiskAssessmentScore" minOccurs="0"/>
 *         &lt;element name="highValueCustomer" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="cardholderInfo" type="{http://vnts.visa.com/tpcas/v1}tCardholderInfo"/>
 *         &lt;element name="deviceInfo" type="{http://vnts.visa.com/tpcas/v1}deviceInfo"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "walletProviderMsgTracing",
    "lifeCycleTraceID",
    "tokenReferenceID",
    "panReferenceID",
    "panSource",
    "riskAssessmentScore",
    "highValueCustomer",
    "cardholderInfo",
    "deviceInfo"
})
@XmlRootElement(name = "checkEligibilityReq")
public class CheckEligibilityReq {

    @XmlElement(required = true)
    protected TWalletProviderMsgTracing walletProviderMsgTracing;
    @XmlElement(required = true)
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger lifeCycleTraceID;
    @XmlElement(required = true)
    protected String tokenReferenceID;
    protected String panReferenceID;
    @XmlElement(required = true)
    protected String panSource;
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger riskAssessmentScore;
    protected Boolean highValueCustomer;
    @XmlElement(required = true)
    protected TCardholderInfo cardholderInfo;
    @XmlElement(required = true)
    protected DeviceInfo deviceInfo;

    /**
     * Obtiene el valor de la propiedad walletProviderMsgTracing.
     * 
     * @return
     *     possible object is
     *     {@link TWalletProviderMsgTracing }
     *     
     */
    public TWalletProviderMsgTracing getWalletProviderMsgTracing() {
        return walletProviderMsgTracing;
    }

    /**
     * Define el valor de la propiedad walletProviderMsgTracing.
     * 
     * @param value
     *     allowed object is
     *     {@link TWalletProviderMsgTracing }
     *     
     */
    public void setWalletProviderMsgTracing(TWalletProviderMsgTracing value) {
        this.walletProviderMsgTracing = value;
    }

    /**
     * Obtiene el valor de la propiedad lifeCycleTraceID.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getLifeCycleTraceID() {
        return lifeCycleTraceID;
    }

    /**
     * Define el valor de la propiedad lifeCycleTraceID.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setLifeCycleTraceID(BigInteger value) {
        this.lifeCycleTraceID = value;
    }

    /**
     * Obtiene el valor de la propiedad tokenReferenceID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTokenReferenceID() {
        return tokenReferenceID;
    }

    /**
     * Define el valor de la propiedad tokenReferenceID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenReferenceID(String value) {
        this.tokenReferenceID = value;
    }

    /**
     * Obtiene el valor de la propiedad panReferenceID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanReferenceID() {
        return panReferenceID;
    }

    /**
     * Define el valor de la propiedad panReferenceID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanReferenceID(String value) {
        this.panReferenceID = value;
    }

    /**
     * Obtiene el valor de la propiedad panSource.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanSource() {
        return panSource;
    }

    /**
     * Define el valor de la propiedad panSource.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanSource(String value) {
        this.panSource = value;
    }

    /**
     * Obtiene el valor de la propiedad riskAssessmentScore.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRiskAssessmentScore() {
        return riskAssessmentScore;
    }

    /**
     * Define el valor de la propiedad riskAssessmentScore.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRiskAssessmentScore(BigInteger value) {
        this.riskAssessmentScore = value;
    }

    /**
     * Obtiene el valor de la propiedad highValueCustomer.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isHighValueCustomer() {
        return highValueCustomer;
    }

    /**
     * Define el valor de la propiedad highValueCustomer.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setHighValueCustomer(Boolean value) {
        this.highValueCustomer = value;
    }

    /**
     * Obtiene el valor de la propiedad cardholderInfo.
     * 
     * @return
     *     possible object is
     *     {@link TCardholderInfo }
     *     
     */
    public TCardholderInfo getCardholderInfo() {
        return cardholderInfo;
    }

    /**
     * Define el valor de la propiedad cardholderInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link TCardholderInfo }
     *     
     */
    public void setCardholderInfo(TCardholderInfo value) {
        this.cardholderInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad deviceInfo.
     * 
     * @return
     *     possible object is
     *     {@link DeviceInfo }
     *     
     */
    public DeviceInfo getDeviceInfo() {
        return deviceInfo;
    }

    /**
     * Define el valor de la propiedad deviceInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link DeviceInfo }
     *     
     */
    public void setDeviceInfo(DeviceInfo value) {
        this.deviceInfo = value;
    }

}
