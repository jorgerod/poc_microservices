
package com.visa.vnts.tpcas.v1;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="requestID" type="{http://vnts.visa.com/tpcas/v1}tURequestID"/>
 *         &lt;element name="responseURL" type="{http://vnts.visa.com/tpcas/v1}tResponseURL"/>
 *         &lt;element name="operatorID" type="{http://vnts.visa.com/tpcas/v1}tOperatorID" minOccurs="0"/>
 *         &lt;element name="requestDetails">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="messageId" type="{http://vnts.visa.com/tpcas/v1}tMessageID"/>
 *                   &lt;element name="tokenReferenceID" type="{http://vnts.visa.com/tpcas/v1}tOptionalTokenReferenceID" minOccurs="0"/>
 *                   &lt;element name="tokenRequestorID" type="{http://vnts.visa.com/tpcas/v1}tTokenRequestorID" minOccurs="0"/>
 *                   &lt;element name="token" type="{http://vnts.visa.com/tpcas/v1}tDPan" minOccurs="0"/>
 *                   &lt;element name="panReferenceID" type="{http://vnts.visa.com/tpcas/v1}tPanReferenceID" minOccurs="0"/>
 *                   &lt;element name="cardholderInfo" type="{http://vnts.visa.com/tpcas/v1}tCardholderInfo" minOccurs="0"/>
 *                   &lt;element name="messageCreationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *                   &lt;element name="messageExpirationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *                   &lt;element name="allowDeepLink" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *                   &lt;element name="contentDetails" maxOccurs="5">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="content" type="{http://vnts.visa.com/tpcas/v1}tString128"/>
 *                             &lt;element name="language">
 *                               &lt;simpleType>
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                                   &lt;minLength value="1"/>
 *                                   &lt;maxLength value="11"/>
 *                                 &lt;/restriction>
 *                               &lt;/simpleType>
 *                             &lt;/element>
 *                             &lt;element name="defaultIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "requestID",
    "responseURL",
    "operatorID",
    "requestDetails"
})
@XmlRootElement(name = "messageServiceReq")
public class MessageServiceReq {

    @XmlElement(required = true)
    protected String requestID;
    @XmlElement(required = true)
    protected String responseURL;
    protected String operatorID;
    @XmlElement(required = true)
    protected MessageServiceReq.RequestDetails requestDetails;

    /**
     * Obtiene el valor de la propiedad requestID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestID() {
        return requestID;
    }

    /**
     * Define el valor de la propiedad requestID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestID(String value) {
        this.requestID = value;
    }

    /**
     * Obtiene el valor de la propiedad responseURL.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseURL() {
        return responseURL;
    }

    /**
     * Define el valor de la propiedad responseURL.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseURL(String value) {
        this.responseURL = value;
    }

    /**
     * Obtiene el valor de la propiedad operatorID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperatorID() {
        return operatorID;
    }

    /**
     * Define el valor de la propiedad operatorID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatorID(String value) {
        this.operatorID = value;
    }

    /**
     * Obtiene el valor de la propiedad requestDetails.
     * 
     * @return
     *     possible object is
     *     {@link MessageServiceReq.RequestDetails }
     *     
     */
    public MessageServiceReq.RequestDetails getRequestDetails() {
        return requestDetails;
    }

    /**
     * Define el valor de la propiedad requestDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageServiceReq.RequestDetails }
     *     
     */
    public void setRequestDetails(MessageServiceReq.RequestDetails value) {
        this.requestDetails = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="messageId" type="{http://vnts.visa.com/tpcas/v1}tMessageID"/>
     *         &lt;element name="tokenReferenceID" type="{http://vnts.visa.com/tpcas/v1}tOptionalTokenReferenceID" minOccurs="0"/>
     *         &lt;element name="tokenRequestorID" type="{http://vnts.visa.com/tpcas/v1}tTokenRequestorID" minOccurs="0"/>
     *         &lt;element name="token" type="{http://vnts.visa.com/tpcas/v1}tDPan" minOccurs="0"/>
     *         &lt;element name="panReferenceID" type="{http://vnts.visa.com/tpcas/v1}tPanReferenceID" minOccurs="0"/>
     *         &lt;element name="cardholderInfo" type="{http://vnts.visa.com/tpcas/v1}tCardholderInfo" minOccurs="0"/>
     *         &lt;element name="messageCreationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
     *         &lt;element name="messageExpirationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
     *         &lt;element name="allowDeepLink" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
     *         &lt;element name="contentDetails" maxOccurs="5">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="content" type="{http://vnts.visa.com/tpcas/v1}tString128"/>
     *                   &lt;element name="language">
     *                     &lt;simpleType>
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *                         &lt;minLength value="1"/>
     *                         &lt;maxLength value="11"/>
     *                       &lt;/restriction>
     *                     &lt;/simpleType>
     *                   &lt;/element>
     *                   &lt;element name="defaultIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "messageId",
        "tokenReferenceID",
        "tokenRequestorID",
        "token",
        "panReferenceID",
        "cardholderInfo",
        "messageCreationDate",
        "messageExpirationDate",
        "allowDeepLink",
        "contentDetails"
    })
    public static class RequestDetails {

        @XmlElement(required = true)
        protected String messageId;
        protected String tokenReferenceID;
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger tokenRequestorID;
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger token;
        protected String panReferenceID;
        protected TCardholderInfo cardholderInfo;
        @XmlElement(required = true)
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar messageCreationDate;
        @XmlElement(required = true)
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar messageExpirationDate;
        protected boolean allowDeepLink;
        @XmlElement(required = true)
        protected List<MessageServiceReq.RequestDetails.ContentDetails> contentDetails;

        /**
         * Obtiene el valor de la propiedad messageId.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMessageId() {
            return messageId;
        }

        /**
         * Define el valor de la propiedad messageId.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMessageId(String value) {
            this.messageId = value;
        }

        /**
         * Obtiene el valor de la propiedad tokenReferenceID.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTokenReferenceID() {
            return tokenReferenceID;
        }

        /**
         * Define el valor de la propiedad tokenReferenceID.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTokenReferenceID(String value) {
            this.tokenReferenceID = value;
        }

        /**
         * Obtiene el valor de la propiedad tokenRequestorID.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getTokenRequestorID() {
            return tokenRequestorID;
        }

        /**
         * Define el valor de la propiedad tokenRequestorID.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setTokenRequestorID(BigInteger value) {
            this.tokenRequestorID = value;
        }

        /**
         * Obtiene el valor de la propiedad token.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getToken() {
            return token;
        }

        /**
         * Define el valor de la propiedad token.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setToken(BigInteger value) {
            this.token = value;
        }

        /**
         * Obtiene el valor de la propiedad panReferenceID.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPanReferenceID() {
            return panReferenceID;
        }

        /**
         * Define el valor de la propiedad panReferenceID.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPanReferenceID(String value) {
            this.panReferenceID = value;
        }

        /**
         * Obtiene el valor de la propiedad cardholderInfo.
         * 
         * @return
         *     possible object is
         *     {@link TCardholderInfo }
         *     
         */
        public TCardholderInfo getCardholderInfo() {
            return cardholderInfo;
        }

        /**
         * Define el valor de la propiedad cardholderInfo.
         * 
         * @param value
         *     allowed object is
         *     {@link TCardholderInfo }
         *     
         */
        public void setCardholderInfo(TCardholderInfo value) {
            this.cardholderInfo = value;
        }

        /**
         * Obtiene el valor de la propiedad messageCreationDate.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getMessageCreationDate() {
            return messageCreationDate;
        }

        /**
         * Define el valor de la propiedad messageCreationDate.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setMessageCreationDate(XMLGregorianCalendar value) {
            this.messageCreationDate = value;
        }

        /**
         * Obtiene el valor de la propiedad messageExpirationDate.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getMessageExpirationDate() {
            return messageExpirationDate;
        }

        /**
         * Define el valor de la propiedad messageExpirationDate.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setMessageExpirationDate(XMLGregorianCalendar value) {
            this.messageExpirationDate = value;
        }

        /**
         * Obtiene el valor de la propiedad allowDeepLink.
         * 
         */
        public boolean isAllowDeepLink() {
            return allowDeepLink;
        }

        /**
         * Define el valor de la propiedad allowDeepLink.
         * 
         */
        public void setAllowDeepLink(boolean value) {
            this.allowDeepLink = value;
        }

        /**
         * Gets the value of the contentDetails property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the contentDetails property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getContentDetails().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link MessageServiceReq.RequestDetails.ContentDetails }
         * 
         * 
         */
        public List<MessageServiceReq.RequestDetails.ContentDetails> getContentDetails() {
            if (contentDetails == null) {
                contentDetails = new ArrayList<MessageServiceReq.RequestDetails.ContentDetails>();
            }
            return this.contentDetails;
        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="content" type="{http://vnts.visa.com/tpcas/v1}tString128"/>
         *         &lt;element name="language">
         *           &lt;simpleType>
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
         *               &lt;minLength value="1"/>
         *               &lt;maxLength value="11"/>
         *             &lt;/restriction>
         *           &lt;/simpleType>
         *         &lt;/element>
         *         &lt;element name="defaultIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "content",
            "language",
            "defaultIndicator"
        })
        public static class ContentDetails {

            @XmlElement(required = true)
            protected String content;
            @XmlElement(required = true)
            protected String language;
            protected boolean defaultIndicator;

            /**
             * Obtiene el valor de la propiedad content.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getContent() {
                return content;
            }

            /**
             * Define el valor de la propiedad content.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setContent(String value) {
                this.content = value;
            }

            /**
             * Obtiene el valor de la propiedad language.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getLanguage() {
                return language;
            }

            /**
             * Define el valor de la propiedad language.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setLanguage(String value) {
                this.language = value;
            }

            /**
             * Obtiene el valor de la propiedad defaultIndicator.
             * 
             */
            public boolean isDefaultIndicator() {
                return defaultIndicator;
            }

            /**
             * Define el valor de la propiedad defaultIndicator.
             * 
             */
            public void setDefaultIndicator(boolean value) {
                this.defaultIndicator = value;
            }

        }

    }

}
