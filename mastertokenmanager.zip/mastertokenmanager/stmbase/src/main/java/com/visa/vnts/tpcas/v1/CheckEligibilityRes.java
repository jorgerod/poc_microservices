
package com.visa.vnts.tpcas.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="actionCode" type="{http://vnts.visa.com/tpcas/v1}tActionCode"/>
 *         &lt;element name="errorCode" type="{http://vnts.visa.com/tpcas/v1}tErrorCode" minOccurs="0"/>
 *         &lt;element name="cardMetadata" type="{http://vnts.visa.com/tpcas/v1}tCardMetaData" minOccurs="0"/>
 *         &lt;element name="cardHolderName" type="{http://vnts.visa.com/tpcas/v1}tCardholderInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "actionCode",
    "errorCode",
    "cardMetadata",
    "cardHolderName"
})
@XmlRootElement(name = "checkEligibilityRes")
public class CheckEligibilityRes {

    @XmlElement(required = true)
    protected String actionCode;
    protected String errorCode;
    protected TCardMetaData cardMetadata;
    protected TCardholderInfo cardHolderName;

    /**
     * Obtiene el valor de la propiedad actionCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionCode() {
        return actionCode;
    }

    /**
     * Define el valor de la propiedad actionCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionCode(String value) {
        this.actionCode = value;
    }

    /**
     * Obtiene el valor de la propiedad errorCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Define el valor de la propiedad errorCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorCode(String value) {
        this.errorCode = value;
    }

    /**
     * Obtiene el valor de la propiedad cardMetadata.
     * 
     * @return
     *     possible object is
     *     {@link TCardMetaData }
     *     
     */
    public TCardMetaData getCardMetadata() {
        return cardMetadata;
    }

    /**
     * Define el valor de la propiedad cardMetadata.
     * 
     * @param value
     *     allowed object is
     *     {@link TCardMetaData }
     *     
     */
    public void setCardMetadata(TCardMetaData value) {
        this.cardMetadata = value;
    }

    /**
     * Obtiene el valor de la propiedad cardHolderName.
     * 
     * @return
     *     possible object is
     *     {@link TCardholderInfo }
     *     
     */
    public TCardholderInfo getCardHolderName() {
        return cardHolderName;
    }

    /**
     * Define el valor de la propiedad cardHolderName.
     * 
     * @param value
     *     allowed object is
     *     {@link TCardholderInfo }
     *     
     */
    public void setCardHolderName(TCardholderInfo value) {
        this.cardHolderName = value;
    }

}
