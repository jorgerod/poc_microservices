
package es.isban.webservices.apcsop.servicioscripto_e.f_apcsop_servicioscripto_e.apcsopservicioscriptoe.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import es.isban.webservices.apcsop.servicioscripto_e.f_apcsop_servicioscripto_e.cbtypes.v1.ComIsbAlApcsopServicioscriptoEFCbEncriptarDesencriptarDatosEType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="entrada" type="{http://www.isban.es/webservices/APCSOP/Servicioscripto_e/F_apcsop_servicioscripto_e/cbTypes/v1}com.isb.al.apcsop.servicioscripto.e.f.cb.EncriptarDesencriptarDatos_E_Type"/>
 *       &lt;/sequence>
 *       &lt;attribute name="facade" type="{http://www.isban.es/webservices/TDCs}DESCRIPCION_GENERAL_Type" fixed="APCSOPServiciosCriptoE" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "entrada"
})
@XmlRootElement(name = "encriptarDesencriptarDatos")
public class EncriptarDesencriptarDatos {

    @XmlElement(required = true, nillable = true)
    protected ComIsbAlApcsopServicioscriptoEFCbEncriptarDesencriptarDatosEType entrada;
    @XmlAttribute(name = "facade")
    protected String facade;

    /**
     * Obtiene el valor de la propiedad entrada.
     * 
     * @return
     *     possible object is
     *     {@link ComIsbAlApcsopServicioscriptoEFCbEncriptarDesencriptarDatosEType }
     *     
     */
    public ComIsbAlApcsopServicioscriptoEFCbEncriptarDesencriptarDatosEType getEntrada() {
        return entrada;
    }

    /**
     * Define el valor de la propiedad entrada.
     * 
     * @param value
     *     allowed object is
     *     {@link ComIsbAlApcsopServicioscriptoEFCbEncriptarDesencriptarDatosEType }
     *     
     */
    public void setEntrada(ComIsbAlApcsopServicioscriptoEFCbEncriptarDesencriptarDatosEType value) {
        this.entrada = value;
    }

    /**
     * Obtiene el valor de la propiedad facade.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFacade() {
        if (facade == null) {
            return "APCSOPServiciosCriptoE";
        } else {
            return facade;
        }
    }

    /**
     * Define el valor de la propiedad facade.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFacade(String value) {
        this.facade = value;
    }

}
