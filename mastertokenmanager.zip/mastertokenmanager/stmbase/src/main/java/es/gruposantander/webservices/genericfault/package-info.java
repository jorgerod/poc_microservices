@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.gruposantander.es/webservices/genericFault")
package es.gruposantander.webservices.genericfault;
