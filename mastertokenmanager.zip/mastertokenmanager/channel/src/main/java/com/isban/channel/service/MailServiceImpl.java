package com.isban.channel.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;

@Service
public class MailServiceImpl implements MailService {
    
    
    
    private static final Map<String, String> typeMessageTask;
    static
    {
        typeMessageTask = new HashMap<>();
        typeMessageTask.put("000", "Registration Request from mobile application");
        typeMessageTask.put("001", "Activation Request from Call Center");
        typeMessageTask.put("002", "Activation from Call Center Confirmed");
        
        typeMessageTask.put("003", "Activation expired or invalidated");
        typeMessageTask.put("004", "Activation Code retries exceeded");
        typeMessageTask.put("005", "Activation code failed");
        
        typeMessageTask.put("006", "Temporary suspension of the token from mobile application");
        typeMessageTask.put("007", "Temporary suspension of the token from call center");
        
        typeMessageTask.put("008", "Resume suspended token from mobile application");
        typeMessageTask.put("009", "Resume suspended token from call center");
        
        typeMessageTask.put("010", "Cancellation token mobile application");
        typeMessageTask.put("011", "Cancellation token from call center");
        typeMessageTask.put("012", "Cancellation token from process batch");
    }
    

    //habria que sacar las propiedades a un properties, pero como es un simulador...
    @Override
    public void sendMail(String customerid, String issuerid, String pans, String messtype, String otp) {
        final String username = "tokenmanagertest@gmail.com";
        final String password = "tokenmanager01";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("tokenmanagertest@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("tokenmanagerclient@gmail.com")); // tmclient01
            

            String text = "Customer: " + customerid + "\n" + "Issuer: " + issuerid + "\n" + "Pans: " + pans + "\n"
                    + "Message: " + messtype;
            
            if (messtype != null && !messtype.isEmpty()) {
                text += "Message: " + messtype + "\n";
                message.setSubject("Customer: " + customerid + " " +typeMessageTask.get(messtype));
            }
            
            if (otp != null && !otp.isEmpty()) {
                text += "OTP: " + otp + "\n";
                message.setSubject("Send OTP: " + customerid.toUpperCase() + " OTP: " + otp);
            }
            
            message.setText(text);

            Transport.send(message);

            System.out.println("Done. Subject: " + message.getSubject());

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }

}
