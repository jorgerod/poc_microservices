package com.isban.channel.service;

public interface MailService {

    void sendMail(String customerid, String issuerid, String pans, String messtype, String otp);
}
