package com.isban.channel.service;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.csvreader.CsvReader;
import com.isban.channel.model.DeliveryMethodResponse;

@Service
public class FileLoadServiceImpl implements FileLoadService {

	public static final String FILE_CLIENT_VALID_CHANNEL= "CLIENT_VALID_CHANNEL_2.csv";
	
	@Override
	public List<DeliveryMethodResponse> loadFile() {
		return createClientValidChannel();
	}
		
	public List<DeliveryMethodResponse>  createClientValidChannel() {
        CsvReader reader = getReader(FILE_CLIENT_VALID_CHANNEL);
        List<DeliveryMethodResponse> medias= new ArrayList<>();
        try {

            while(reader.readRecord()) {
            	
            	DeliveryMethodResponse DeliveryMethodResponse = new DeliveryMethodResponse(
            			reader.get("TYPE").toString(),  
            			reader.get("VALUE").toString(),  
                		reader.get("CLIENT_ID").toString(),
                		reader.get("SUSPICIUS_FRAUD").toString());
                medias.add(DeliveryMethodResponse);
            }
            
            
            
            
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            reader.close();
        }
        return medias;
    }
	
		
	private CsvReader getReader(String fileName) {
		ClassPathResource res = new ClassPathResource("files/"+fileName);
		CsvReader reader = null;
		try {
			reader = new CsvReader(res.getInputStream(),';',Charset.forName("ISO-8859-1"));
			reader.setDelimiter(';');
			reader.readHeaders();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return reader;
	}
	
	

}
