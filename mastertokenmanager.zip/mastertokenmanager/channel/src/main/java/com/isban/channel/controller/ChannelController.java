package com.isban.channel.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.isban.channel.model.Constants;
import com.isban.channel.model.DeliveryMethodResponse;
import com.isban.channel.model.GetDeliveryMethodResponse;
import com.isban.channel.model.TMResult;
import com.isban.channel.service.FileLoadService;
import com.isban.channel.service.MailService;
import com.isban.tokenmanager.dto.CardLessEmailHttpRequest;
import com.isban.tokenmanager.dto.CardLessEmailResponse;
import com.isban.tokenmanager.dto.CardLessSMSHttpRequest;
import com.isban.tokenmanager.dto.CardLessSMSResponse;

@RestController
public class ChannelController {

    @Autowired
    FileLoadService fileLoad = null;

    @Autowired
    MailService mailService;

    @RequestMapping(value = "/api/sendotp", method = RequestMethod.GET)
    @Deprecated
    public @ResponseBody TMResult sendOtpToCustomer(
            @RequestParam(value = "issuerid") final String issuerid,
            @RequestParam(value = "customerid") final String customerid,
            @RequestParam(value = "pans") final String pans,
            @RequestParam(value = "devicetype") String devicetype,
            @RequestParam(value = "walletid") String wallet,
            @RequestParam(value = "otp") final String otp,
            @RequestParam(value = "expiry") String expiry,
            @RequestParam(value = "deliverymethodid") String deliverymethodid,
            @RequestParam(value = "channel") String channel) {
        System.out.println("Entrada /api/otp :: customerid = " + customerid
                + ", otp = " + otp + ", delivery_method = " + deliverymethodid);
        TMResult ret;
        if ((customerid != null && !customerid.isEmpty())
                && (otp != null && !otp.isEmpty())) {
            ret = new TMResult(Constants.OK_SEND_OTP_CODE,
                    Constants.OK_SEND_OTP_DESC);
             
            
            Thread mailThread = new Thread() {
                @Override
                public void run() {
                    super.run();
                    mailService.sendMail(customerid, issuerid, pans, null, otp);
                }
            };

            mailThread.start();
            
            
        } else {
            ret = new TMResult(Constants.KO_SEND_OTP_CODE,
                    Constants.KO_SEND_OTP_DESC);
        }
        System.out.println("Peticion /api/otp :: " + ret.toString());
        return ret;
    }

    /**
     * Para pruebas. En futuras versiones habra que quitarlo
     */
    @RequestMapping(value = "/api/sendnotification", method = RequestMethod.GET)
    @Deprecated
    public @ResponseBody// TODO Pendiente de defenir los parametros
    TMResult sendNotificationToCustomer(
            @RequestParam(value = "issuerid") final String issuerid,
            @RequestParam(value = "customerid") final String customerid,
            @RequestParam(value = "pans") final String pans,
            @RequestParam(value = "devicetype") String devicetype,
            @RequestParam(value = "walletid") String wallet,
            @RequestParam(value = "messageid") final String messageid,
            @RequestParam(value = "channel") String channel) {

        TMResult ret;
        if ((customerid != null && !customerid.isEmpty())
                && (messageid != null && !messageid.isEmpty())) {
            
            ret = new TMResult(Constants.OK_CODE, Constants.OK_DESC);

            Thread mailThread = new Thread() {
                @Override
                public void run() {
                    super.run();
                    mailService.sendMail(customerid, issuerid, pans, messageid,
                            null);
                }
            };

            mailThread.start();

            

        } else {
            ret = new TMResult(Constants.KO_CODE, Constants.KO_DESC);
        }
        System.out.println("Peticion /api/sendNotification :: "
                + ret.toString());
        return ret;
    }

    // private List<DeliveryMethodResponse> getDeliveryChannelByCustomer(String
    // customerid) {
    // List<DeliveryMethodResponse> ret = new
    // ArrayList<DeliveryMethodResponse>();
    // DeliveryMethodResponse oldDMR = new DeliveryMethodResponse();
    // for (DeliveryMethodResponse deliveryMethodResponse : fileLoad.loadFile())
    // {
    // if (customerid.equals(deliveryMethodResponse.getCustomer())) {
    // if (oldDMR.getType() == null ||
    // oldDMR.getType().equals(deliveryMethodResponse.getType())) {
    //
    // oldDMR.setCustomer(customerid);
    // oldDMR.setType(deliveryMethodResponse.getType());
    // if (oldDMR.getValues() == null)
    // oldDMR.setValues(new ArrayList<String>());
    // oldDMR.getValues().add(deliveryMethodResponse.getValues().get(0));
    // } else {
    // ret.add(oldDMR);
    // oldDMR = deliveryMethodResponse;
    // }
    //
    // }
    // }
    // if (oldDMR.getType() != null)
    // ret.add(oldDMR);
    // return ret;
    //
    // }

    @RequestMapping(value = "/api/getdeliverychannelbyclient", method = RequestMethod.GET)
    @Deprecated
    public @ResponseBody GetDeliveryMethodResponse getDeliveryChannelByClient(
            @RequestParam(value = "issuerid") String issuerid,
            @RequestParam(value = "customerid") String customerid,
            @RequestParam(value = "channel") String channel) {
        System.out
                .println("Entrada /api/getdeliverychannelbyclient :: customerid = "
                        + customerid);
        GetDeliveryMethodResponse ret = this.getDeliveryChannelByCustomer(
                issuerid, customerid, channel);
        System.out.println("Peticion /api/getdeliverychannelbyclient :: "
                + ret.toString());
        return ret;
    }

    private GetDeliveryMethodResponse getDeliveryChannelByCustomer(
            String issuerid, String customerid, String channel) {
        GetDeliveryMethodResponse ret = new GetDeliveryMethodResponse(
                Constants.OK_DELIVERY_METHOD_CODE,
                Constants.OK_DELIVERY_METHOD_DESC);
        List<DeliveryMethodResponse> allMedias = new ArrayList<>();
        List<DeliveryMethodResponse> medias = new ArrayList<>();
        DeliveryMethodResponse oldDMR = new DeliveryMethodResponse();

        allMedias = fileLoad.loadFile();
        System.out.println("/api/getdeliverychannelbyclient :: allMedias = "
                + allMedias);
        Boolean first = false;

        for (DeliveryMethodResponse deliveryMethodResponse : allMedias) {
            if (customerid.equals(deliveryMethodResponse.getCustomer())) {
                System.out
                        .println("/api/getdeliverychannelbyclient :: hay customer = "
                                + deliveryMethodResponse.getCustomer());
                if (oldDMR.getType() == null
                        || oldDMR.getType().equals(
                                deliveryMethodResponse.getType())) {
                    oldDMR.setCustomer(customerid);
                    oldDMR.setType(deliveryMethodResponse.getType());
                    oldDMR.setValue(deliveryMethodResponse.getValue());
                    oldDMR.setSuspiciusFraud(deliveryMethodResponse
                            .getSuspiciusFraud());
                    System.out.println("no add media");
                } else {
                    System.out.println("add media");
                    medias.add(oldDMR);
                    oldDMR = deliveryMethodResponse;
                }

                if (!first) {
                    ret.setSuspiciusFraud(Integer
                            .parseInt(deliveryMethodResponse
                                    .getSuspiciusFraud()));
                    first = true;
                }

            }
        }
        if (oldDMR.getType() != null)
            medias.add(oldDMR);

        if (medias.size() < 1) {
            ret.setCode(Constants.KO_DELIVERY_METHOD_NO_METHODS_CODE);
            ret.setDescription(Constants.KO_DELIVERY_METHOD_NO_METHODS_DESC);
        } else {
            ret.setMethods(medias);
        }
        return ret;

    }
    
    // METODOS PARA NOTIFICACIONES EN CARDLESS
    // /texts/{text_id}?lang&text_type&params
    // /notifications/mail
    
    @RequestMapping(value = "/texts/{text_id}", produces = MediaType.TEXT_PLAIN_VALUE, method = RequestMethod.GET)
    public @ResponseBody String buildMessages( 
            @PathVariable("text_id") String textid,
            @RequestParam(value="lang", required=false , defaultValue="es_ES") final String lang,
            @RequestParam(value="text_type",required=false) final String textType,
            @RequestParam(value="params",required=false) final String params) {
         System.out.println(textid);
         System.out.println(lang);
         System.out.println(textType);
         System.out.println(params);
         
         String text=null==(params)?"Menssaje Vacio de prueba":params;
         
         return text;

    }
    
    
    @RequestMapping(value = "notifications/sms", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public @ResponseBody CardLessSMSResponse sendSMS(@RequestBody CardLessSMSHttpRequest request) {
        
        CardLessSMSResponse response = new CardLessSMSResponse();
        System.out.println(request.toString());
        response.setCode(0);
        return response;
        
     }
    

    @RequestMapping(value = "notifications/mail", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public @ResponseBody CardLessEmailResponse sendEmail(@RequestBody CardLessEmailHttpRequest request) {
        
        CardLessEmailResponse response = new CardLessEmailResponse();
        System.out.println(request.toString());
        response.setCode(0);
        return response;
        
     }
    
    
    
}
