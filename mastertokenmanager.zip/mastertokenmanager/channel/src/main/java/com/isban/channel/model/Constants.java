package com.isban.channel.model;

/**
 * Created by Sergey Zlobin on 27/07/2015.
 */
public class Constants {

    public static final String OK_CODE = "000";
    public static final String OK_DESC = "Operation successfully completed";
    public static final String KO_CODE = "001";
    public static final String KO_DESC = "Could not complete this operation. An unknown error has occurred.";
    
    public static final String OK_DELIVERY_METHOD_CODE = "0000";
    public static final String OK_DELIVERY_METHOD_DESC = "OK (Operación realizada con éxito).";
    public static final String KO_DELIVERY_METHOD_CODE = "0001";
    public static final String KO_DELIVERY_METHOD_DESC = "KO (Error del sistema).";
    public static final String KO_DELIVERY_METHOD_ISSUER_CODE = "0002";
    public static final String KO_DELIVERY_METHOD_ISSUER_DESC = "KO (Emisor no existente)";
    public static final String KO_DELIVERY_METHOD_CLIENT_CODE = "0003";
    public static final String KO_DELIVERY_METHOD_CLIENT_DESC = "KO (Cliente no existente)";
    public static final String KO_DELIVERY_METHOD_NO_METHODS_CODE = "0004";
    public static final String KO_DELIVERY_METHOD_NO_METHODS_DESC = "KO (Cliente sin métodos de distribución)";
    
    public static final String OK_SEND_OTP_CODE = "0000";
    public static final String OK_SEND_OTP_DESC = "Operation successfully completed";
    public static final String KO_SEND_OTP_CODE = "0001";
    public static final String KO_SEND_OTP_DESC = "Could not complete this operation. An unknown error has occurred.";
}
