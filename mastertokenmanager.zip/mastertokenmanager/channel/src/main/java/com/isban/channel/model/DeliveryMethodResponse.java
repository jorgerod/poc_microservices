package com.isban.channel.model;


public class DeliveryMethodResponse {
	String type;
	String value;
	String customer;
	String suspiciusFraud;
	
	
	public DeliveryMethodResponse() {
		
	}
	public DeliveryMethodResponse(String type, String value, String customer, String suspiciusFraud) {
		super();
		this.type = type;
		this.value = value;
		this.customer = customer;
		this.suspiciusFraud = suspiciusFraud; 
	}
	

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "DeliveryMethodResponse [type=" + type + ", value=" + value + ", customer=" + customer + "]";
	}
    public String getSuspiciusFraud() {
        return suspiciusFraud;
    }
    public void setSuspiciusFraud(String suspiciusFraud) {
        this.suspiciusFraud = suspiciusFraud;
    }
}
