package com.isban.channel.service;

import java.util.List;

import com.isban.channel.model.DeliveryMethodResponse;

public interface FileLoadService {
	
	public List<DeliveryMethodResponse> loadFile();

}
