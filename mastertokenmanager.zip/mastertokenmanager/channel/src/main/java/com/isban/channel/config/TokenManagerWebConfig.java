package com.isban.channel.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = {"com.isban.channel.controller"})
public class TokenManagerWebConfig extends WebMvcConfigurerAdapter {

    @Bean
    public ViewResolver viewResolver() {
        // Solucionador de vistas
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        resolver.setPrefix("/WEB-INF/views/");
        resolver.setSuffix("");
        resolver.setExposeContextBeansAsAttributes(true);

        return resolver;
    }

    /**
     * Configuracion del procesamiento de contenido estático.
     *
     * @param configurer data
     */
    public void configureDefaultServletHndling(
            DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }
}
