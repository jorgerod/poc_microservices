
## channel

**Simulador channel**

Incorpora un servidor embebido jetty

Para lanzar el servidor:

`mvn -pl channel/ jetty:run`


Prueba desde curl

Comprobar si se puede mandar otp al cliente:
`curl "http://localhost:9094/channel/api/checkclient?customerid=000000001"`

Mandar otp al cliente:
`curl "http://localhost:9094/channel/api/sendotp?customerid=000000004&otp=234434344234234234"`

Devuelve lista de Medios de comunicacion de un cliente
`curl "http://localhost:9094/channel/api/getdeliverychannelbyclient?customerid=F000000002"`
