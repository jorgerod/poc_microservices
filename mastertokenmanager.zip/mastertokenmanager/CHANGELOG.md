## v.1.3.0
 - __Stm-Core__:
   - Actualización de las siguientes librerías:
     - Spring Boot: 1.4.1.RELEASE
     - Jackson: 2.8.4
     - Javamelody: 1.62.0
     - Hibernate: 5
     - Swagger: 2.6.0
     - Log4j2
   - Creación del módulo de TSP.
   - Configuración de Javamelody (por defecto, solo en local)
   - Ejecución de test unitarios.
   
 - __Cardless__:

## v.1.2.9
 - __Openbank__:
   - Corrección de incidente en la funcionalidad de criterios de elegibilidad.   
      
## v.1.2.8
 - __Openbank__:
   - Gestión de Card Art   

## v.1.2.7
 - __Openbank__:
   - Unificación del software
   - Servicio obtención de card art de todas las tarjetas de un cliente (sin aplicar elegibiliadd)

## v.1.2.6
 - __sTM Core__:
   - Adaptación a PAAS
   - Seguridad con token BKS
   - Nuevo módulo para la gestión de procesos Batch (sTM Batch)
   
 - __Openbank__:
   - Web Services elegibilidad de tarjetas
   - Web Services notificacion de digitalización de tarjeta
   - Web Services de baja de tarjeta desde sTM a Redsys
   - Servicios de integración entre sTM y la consola de sTM (tanto para la consola de operaciones como portal CIC)