package com.isban.ppaa.config;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;

@SuppressWarnings("serial")
public class JaxbJacksonObjectMapper extends ObjectMapper {

    /**
     * Annotation introspector to use for serialization process is configured
     * separately for serialization and deserialization purposes
     */
    public JaxbJacksonObjectMapper() {
        final AnnotationIntrospector introspector = new JacksonAnnotationIntrospector();
        super.getDeserializationConfig().with(introspector);
        super.getSerializationConfig().with(introspector);
        
        super.setSerializationInclusion(Include.NON_NULL);
    }
    
}
