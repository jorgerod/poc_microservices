package com.isban.ppaa.config;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.isban.tokenmanager.config.StmCryptoProperties;

@SpringBootApplication
@ComponentScan(basePackages = { "com.isban.tokenmanager", "com.isban.ppaa" } )
@EnableConfigurationProperties({ StmCryptoProperties.class })
public class Application {
    
    private static final Logger logger = Logger.getLogger(Application.class);
    
    public static void main(String[] args) {
        logger.info("***************************************************");
        logger.info("Starting PPAA");
        
        SpringApplication.run(Application.class, args);
        
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("");
        logger.info("Started PPAA");
        logger.info("");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
        logger.info("***************************************************");
    }
    
    @Bean
    public JaxbJacksonObjectMapper jaxbJacksonObjectMapper() {
        return new JaxbJacksonObjectMapper();
    }
}