package com.isban.ppaa.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.csvreader.CsvReader;
import com.isban.tokenmanager.integration.ppaa.CommonHttpResponse;
import com.isban.tokenmanager.integration.ppaa.RetentionHttpRequest;
import com.isban.tokenmanager.integration.ppaa.RetentionHttpResponse;
import com.isban.tokenmanager.util.FileLoadBase;

@RestController
@RequestMapping("api/accounts")
public class PpaaController {

    private static final String FILE_ACCOUNTS = "ACCOUNTS.csv";
    private static final String CODE_INTERNAL_SYSTEM_ERROR = "909";
    
   @RequestMapping(value = "{accountNumber}/withholding", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
   public @ResponseBody <T extends CommonHttpResponse> RetentionHttpResponse putRetention(@RequestBody RetentionHttpRequest request, @PathVariable("accountNumber") String accountNumber, @RequestHeader(value = "GS-AUTH-TOKEN", required = false) String tokenSec) {

// Comentado ya que temporalmente sno se envia token
//       if (tokenSec == null) {
//           return create403ErrorResponse();
//       }
//       if (!tokenSec.equals("eyJraWQiOiJzdG1fU0hBMXdpdGhSU0EiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ1aWQ6U1RNX1RFU1RfVVNFUiIsImF1ZCI6IlNUTV9BUFAiLCJuYmYiOjE0NzU0ODg1MjUsImlzcyI6InN0bSIsImV4cCI6Mzc0NzU0ODg1NjMsImlhdCI6MTQ3NTQ4ODUyNSwianRpIjoiZmM4YzYxZDktNGFkMS00MGUyLWIyMGItMDMxYWRkZjA1MjYzIn0.i8GFXGICPu5Uf6SeBcHrASw2oli8eFOHu25ZirtiAL0hWB5zFveAK_JzjYqHs7DnHCEAaBjjLU9WRbkx7RNYP4YV2TGFqfTw3sXo760IpXg2oMqhyt8m_JKNGnqemnKaXM98Rrm54eaIfh1uEtWdZHOkH4OseK9-oXDGLI-jypnDi1qaPsmLx7oqyZpBJyPolaHp7anu_48SjSb6RLkXfXurmGlUldmcj6ssf9bkalIfkyUUO_ZJkw9rm8ESKVcvSrkvcQ8sMKeiOZZRk0p0n83n3A389n4AZbdUf3lQv6S8gk7pfZxsz1HwO8xqP6sniNauIjpXgzPs60EnplCmmg")) {
//           return create401ErrorResponse();
//       }
       if (request.getAmount().isEmpty() || request.getCurrency().isEmpty() || request.getDescription().isEmpty()) {
           return create400ErrorResponse();
       }
       
       String contract = accountNumber;
       return doSomething(contract, null);
    }

   @RequestMapping(value = "{accountNumber}/withholding/{withholdingId}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
   public @ResponseBody CommonHttpResponse releaseRetention(@PathVariable("accountNumber") String accountNumber, @PathVariable("withholdingId") String withholdingId, @RequestHeader(value = "GS-AUTH-TOKEN", required = false) String tokenSec) {
       if (tokenSec == null) {
           return create403ErrorResponse();
       }
       if (!tokenSec.equals("eyJraWQiOiJzdG1fU0hBMXdpdGhSU0EiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ1aWQ6U1RNX1RFU1RfVVNFUiIsImF1ZCI6IlNUTV9BUFAiLCJuYmYiOjE0NzU0ODg1MjUsImlzcyI6InN0bSIsImV4cCI6Mzc0NzU0ODg1NjMsImlhdCI6MTQ3NTQ4ODUyNSwianRpIjoiZmM4YzYxZDktNGFkMS00MGUyLWIyMGItMDMxYWRkZjA1MjYzIn0.i8GFXGICPu5Uf6SeBcHrASw2oli8eFOHu25ZirtiAL0hWB5zFveAK_JzjYqHs7DnHCEAaBjjLU9WRbkx7RNYP4YV2TGFqfTw3sXo760IpXg2oMqhyt8m_JKNGnqemnKaXM98Rrm54eaIfh1uEtWdZHOkH4OseK9-oXDGLI-jypnDi1qaPsmLx7oqyZpBJyPolaHp7anu_48SjSb6RLkXfXurmGlUldmcj6ssf9bkalIfkyUUO_ZJkw9rm8ESKVcvSrkvcQ8sMKeiOZZRk0p0n83n3A389n4AZbdUf3lQv6S8gk7pfZxsz1HwO8xqP6sniNauIjpXgzPs60EnplCmmg")) {
           return create401ErrorResponse();
       }

        String contract = accountNumber;
        String retentionId = withholdingId;
        return doSomething(contract, retentionId);
    }

    private RetentionHttpResponse doSomething(String contract, String retentionId) {
        RetentionHttpResponse response = create404ErrorResponse();
        
        FileLoadBase fileLoad = new FileLoadBase();
        CsvReader reader = fileLoad.getReader(FILE_ACCOUNTS);
        try
        {
            while (reader.readRecord()) {
                String account = reader.get("AccountNumber").toString();
                if(account.equals(contract))
                {
//                    response.setCode(CODE_OK);
                    response = new RetentionHttpResponse();
                    if(retentionId == null)
                    {
                        SimpleDateFormat sdfDate = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSSSSS");
                        response.setRetentionId(sdfDate.format(new Date()));
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            response.setCode(CODE_INTERNAL_SYSTEM_ERROR);
        } catch (Exception e) {
            response.setCode(CODE_INTERNAL_SYSTEM_ERROR);
            e.printStackTrace();
        } finally {
            reader.close();
        }
        return response;
    }

    private RetentionHttpResponse create400ErrorResponse() {
        return createErrorResponse("400", "Some of the input data was filled incorrectly or it was not filled");
    }

    private RetentionHttpResponse create401ErrorResponse() {
        return createErrorResponse("401", "The BKS token authentication was invalid or it didn't exist");
    }

    private RetentionHttpResponse create403ErrorResponse() {
        return createErrorResponse("403", "The user has no rights to create the withholding");
    }

    private RetentionHttpResponse create404ErrorResponse() {
        return createErrorResponse("404", "The withholding doesn't exist or the account number doesn't exist");
    }
    
    private RetentionHttpResponse createErrorResponse(String statusCode, String message) {
        RetentionHttpResponse response = new RetentionHttpResponse();
        response.setStatus(statusCode);
        response.setCode("0000");
        response.setDescription(message);
        return response;
    }
}
