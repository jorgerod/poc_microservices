mastertokenmanager
===
* Proyecto multi-modulo maven
* Para instalarlo ::
1. hacer clone del repositorio git
1. importar proyectos maven que estan en el codigo clonado con eclipse
1. situacion de los workspaces
```
/op/dev
/opt/devjs
```
1. usando java8
1. primera construccion y ejecucion
```
cd /opt/dev/mastertokenmanager
mvn clean install
java -jar tokenmanager/target/tokenmanager-1.2.0-SNAPSHOT.jar --spring.profiles.active=locapolo1
```

algunas otras ejecuciones
```
java -jar cms/target/cms-1.2.0-SNAPSHOT.jar
java -jar tsp/target/tsp-1.2.0-SNAPSHOT.jar
java -jar tokenmanager/target/tokenmanager-1.2.0-SNAPSHOT.jar --spring.profiles.active=locapolo1
java -jar stmbatch/target/stmbatch-1.2.0-SNAPSHOT.war --spring.profiles.active=locapolo1
```
algunas otras ejecuciones, trabajando con java8, opciones de memoria
```
java -jar -XX:MaXMeTasPaceSize=64M  -Xms256M  -Xmx448M  cms/target/cms-1.2.0-SNAPSHOT.jar
java -jar -XX:MaXMeTasPaceSize=64M  -Xms256M  -Xmx448M  tsp/target/tsp-1.2.0-SNAPSHOT.jar
java -jar -XX:MaxMetaspaceSize=128M -Xms1536M -Xmx1920M tokenmanager/target/tokenmanager-1.2.0-SNAPSHOT.jar --spring.profiles.active=locapolo1
java -jar -XX:MaXMeTasPaceSize=64M  -Xms512M  -Xmx960M  stmbatch/target/stmbatch-1.2.0-SNAPSHOT.war --spring.profiles.active=locapolo1
```



preparacion de la ddbb
===
* INSTALL :: postgresql  ,,,,
    http://enchufado.com/post.php?ID=192
    http://www.tutorialspoint.com/postgresql/postgresql_create_database.htm
    http://www.postgresql.org/docs/9.5/static/sql-createdatabase.html
    http://tecadmin.net/list-all-databases-and-tables-in-postgresql
http://www.juancarlosmoral.es/postgresql-hardware-tunning/   !!!!!!!!!!!!!!!!!!!!!!
http://www.postgresql.org.es/node/219
```
sudo apt-get install postgresql
```
conectandose a la ddbb base
```
jdbc:postgresql://localhost:5432/postgres
postgres
root
```
... usando psql o squirrelsql ...
```
SELECT pg_terminate_backend(pg_stat_activity.pid)
FROM pg_stat_activity
WHERE pg_stat_activity.datname = 'tokenmanager'
  AND pid <> pg_backend_pid();
```
```
drop database tokenmanager;
create database tokenmanager;
ALTER USER postgres WITH PASSWORD 'root';
```  
listando las ddbbs
```
sudo -u postgres psql
  \l
  \q
```
conectandose a la ddbb base
```
jdbc:postgresql://localhost:5432/tokenmanager
postgres
root
```
FILL DDBB :: visitar 
```
http://localhost:8081/tokenmanager/api/dataloadob
```



tomcat 8, instalacion, construccion de WARs, depliegue y uso
===
notas javamelody
    http://localhost:8081/tokenmanager/admin/monitoring






maven, uso de sistema multiproyecto y reactor
===
como :: un proyecto y sus dependencias
---
```
cd /opt/dev/mastertokenmanager
mvn install --projects tokenmanager
```

como :: varios proyectos y sus dependencias
---
```
cd /opt/dev/mastertokenmanager
mvn install --projects tokenmanager,stmbatch
```

notas para jenkins
---
```
mvn clean test install --projects tokenmanager
mvn install --projects tokenmanager
```



maven, uso de sistema de profiles para diferentes construcciones jar/war
===
trabajando para generar JARs, trabajo de linea de comandos simple
```
//mvn clean install --activate-profiles buildJar
mvn clean install
mvn clean install --projects stmbatch
mvn clean install --projects tokenmanager
```

trabajando para generar WARs, trabajo de linea de comandos usando --activate-profiles
```
mvn clean install --activate-profiles buildWar
mvn clean install --projects stmbatch --activate-profiles buildWar
mvn clean install --projects tokenmanager --activate-profiles buildWar
```



repositorio maven de oracle como configurarlo para acceder
===
aqui hay instrucciones ... basicamente hay que darse de alta en oracle, encriptar tu password y adjuntarla en los settings en .m2. Tambien hay que indicar que implica una conf de repositorios.
  http://docs.oracle.com/middleware/1213/core/MAVEN/config_maven_repo.htm#MAVEN9012
    y
  https://blogs.oracle.com/dev2dev/entry/how_to_get_oracle_jdbc#settings



despues de obtener los drivers desde repositorio maven de oracle, TENEMOS UN jarHELL !!!!, depencias de implementaciones xerces lo hacen directamente incompatible con las utilidades de spring boot :: SOLUCION
===
la idea es usar solo el jar del driver, para esto vamos crear una entrada para solo este jar, esta entrada en los pom.xml sera la siguiente y sustituira a cualquier otra de oracle
```
        <dependency>
            <groupId>com.oracle</groupId>
            <artifactId>ojdbc6</artifactId>
            <version>11.2.0.4</version>
        </dependency>
```
para instalarlo en nuestro repositorio .m2
```
mvn install:install-file -Dfile=./ojdbc6-11.2.0.4.jar  -DgroupId=com.oracle -DartifactId=ojdbc6 -Dversion=11.2.0.4 -Dpackaging=jar
```



doc, links, utilidad
===






Moneda/decimales:
---
    https://en.wikipedia.org/wiki/ISO_4217

(S)FTP en local**
---
Descargarse freeSSHd.exe de http://www.freesshd.com/?ctt=download e instalarselo (cuando pregunte sobre la generacion de claves elegimos que si).
```
 - En la pestania SFTP aniadir ruta para carpeta en local.

 - En pestania Users aniadir un usuario:
            - login: usuario de bitbucket
            - authorization: Password stored as SHA1 hash
            - contrasenia: 123456
            - Darle permisos de SFTP.
   
 - Pestania Server Status arrancar SSH.
 
 Ejemplo: https://github.com/spring-projects/spring-integration-samples/tree/master/advanced/dynamic-ftp/src/main/java/org/springframework/integration/samples/ftp
```



Mastercard_Api
---
* OJO!!! CAMBIAR jrodriguezma POR NUESTRO USUARIO (a no ser que seais jrodriguezma)
* En /c/opt/dev/mastertokenmanager:
```
git clone https://jrodriguezma@bitbucket.org/lechonceteteam/mastercardservices.git

cd /c/opt/dev/mastertokenmanager/mastercardservices:
    
git remote rm origin
git remote add origin https://github.com/MasterCard/mastercard-api-java.git
git remote add lechonceteteam https://jrodriguezma@bitbucket.org/lechonceteteam/mastercardservices.git
    
mvn package -Dmaven.test.skip=true
```
* Crear repositorio local:
```
mvn org.apache.maven.plugins:maven-install-plugin:2.3.1:install-file   -Dfile=/c/opt/dev/mastertokenmanager/mastercardservices/target/mcapi-1.0-RELEASE.jar -DgroupId=com.mastercard.api -DartifactId=mcapi -Dversion=1.0-RELEASE -Dpackaging=jar -DlocalRepositoryPath=/c/opt/dev/mastertokenmanager/mastercardservices/target
        
https://github.com/MasterCard/mastercard-api-java
```
* Install mastercarservices en repositorio local **
```
cd /c/opt/dev/mastertokenmanager/mastercardservices
mvn clean package -Dmaven.test.skip=true

cd /c/opt/dev/mastertokenmanager/tokenmanager
mvn install:install-file -DgroupId=com.mastercard.api -DartifactId=mcapi -Dversion=1.0-RELEASE -Dpackaging=jar -Dfile=/C/opt/dev/mastertokenmanager/mastercardservices/target/mcapi-1.0-RELEASE.jar
```
* with sources:
```
mvn install:install-file -DgroupId=com.mastercard.api -DartifactId=mcapi -Dversion=1.0-RELEASE -Dpackaging=jar -Dsources=/C/opt/dev/mastertokenmanager/mastercardservices/target/mcapi-1.0-RELEASE-sources.jar -Dfile=/C/opt/dev/mastertokenmanager/mastercardservices/target/mcapi-1.0-RELEASE.jar
```






WSDLs modo servidor
===
servidor real
---
http://localhost:8081/tokenmanager/ws/stmhce.wsdl



nuestras simulaciones de servidores de terceros
---
http://localhost:9092/cms/ws/cms?wsdl    //OLD,000 ... http://localhost:9091/cms/ws/cms.wsdl
http://localhost:9093/tsp/ws/tsp?wsdl



WSDLs modo somos cliente
===
**TEMPORALesNUESTRAsimulacion** http://localhost:9092/cms/ws/cms?wsdl    //OLD,000 ... http://localhost:9091/cms/ws/cms.wsdl
**TEMPORALesNUESTRAsimulacion** http://localhost:9093/tsp/ws/tsp?wsdl
**POSIBLEtercero** http://www.isban.es/webservices/MPMWES/Titulares_e/F_mpmwes_titulares_e/ACMPMWESTitulares/v1/consultaTjtTokenRedsys?wsdl
**TERCERO,DEV** https://desextranet.isban.dev.corp/MPMWES_ENS_OPB/ws/MPMWES_Def_Listener


SWAGGER
===
 - Documentacion Swagger (springfox)
 	- https://springfox.github.io/springfox/docs/current/
 	
 - Editor de swagger:
	 - http://editor.swagger.io/#/
 - Url de apis stm:
	 - http://localhost:28081/tokenmanager/swagger-ui.html
 		
 - Apis stm json:
	 - http://localhost:28081/tokenmanager/v2/api-docs?group=api-stm
	 
 - Url Configuracion de swagger
 	- http://localhost:28081/tokenmanager/swagger-resources/configuration/ui

 - Swagger2Markup
 	- https://jhipster.github.io/tips/008_tips_static_swagger_docs.html
 	
---
 - Anotaciones
	 - Controladores:
		 - A nivel de clase:
			 - @Api(value = "STM Cards API", description = "STM Cards API", produces = "application/json")
		 - A nivel de metodo:
			 - @ApiOperation(value = "Get cards", notes = "Returns all cards eligibilities from a client")
     		 - @ApiResponses({ @ApiResponse(code = 200, message = "Exits one info at least") })
			 - @ApiParam
	 - Dto
		 - A nivel de clase:
			 - @ApiModel(description = "")
		 - A nivel de atributo:
			 - @ApiModelProperty(value = "", required= false)
---

SEGURIDAD
===
Url's utiles
---
- http://serenity.gs.corp/web/devstack/blog/detalle/-/blogs/new-devstack-starter-and-security-release?_33_redirect=%2Fweb%2Fdevstack%2Fblog
- https://docs-devstack-platform-dev.appls.boae.paas.gsnetcloud.corp/serenity-devstack-security/src/main/asciidoc/reference-manual.html
- Ejemplos: https://docs-devstack-platform-dev.appls.boae.paas.gsnetcloud.corp/serenity-devstack-security/serenity-devstack-security-samples/README.html

---
Test
---
- **Generar token jwt: **
	JWTTokenGeneratorTest.java
- **Validador jwt: **
	JWTTokenValidatorTest.java
- **Generador token BKS: **
	BKSTokenGeneratorTest.java
- **Validador Token BKS: **
	BKSTokenValidatorTest.java
	


ANEXO
---
Java8
---
 - https://github.com/2nis6mon/dojo-java8-singleproject
```
 - http://www.java8.org/introduction-to-java-8-lambda-expressions.html
```


